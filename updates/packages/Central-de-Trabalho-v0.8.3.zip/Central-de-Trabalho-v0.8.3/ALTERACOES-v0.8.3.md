﻿# Central de Trabalho v0.8.3

Data: 09/09/2026

## Objetivo

Fechar o ciclo real de atualização/restauração corrigindo a reabertura automática da Central após a troca de versão.

## Atualizador

- A Central agora é iniciada com a pasta principal definida explicitamente como diretório de trabalho.
- O relançamento usa `UseShellExecute = true`, mais compatível com o Windows e com os launchers do pacote.
- Após iniciar, o Atualizador confirma por alguns segundos se a Central realmente adquiriu seu mutex.
- Se o EXE não abrir, o launcher VBS é tentado automaticamente como segunda opção.
- Se nenhuma opção funcionar, aparece um aviso claro em vez de o Atualizador encerrar silenciosamente.
- Mantidas as correções anteriores de confirmação, SHA-256, backup e restauração.

## Módulos preservados

- Gerenciador: 3.4.0.
- Central de Manutenção: 0.5.0.
