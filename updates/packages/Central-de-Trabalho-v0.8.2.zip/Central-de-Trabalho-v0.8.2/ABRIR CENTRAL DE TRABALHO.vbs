Option Explicit

Dim shell, fileSystem, baseFolder, command
Set shell = CreateObject("WScript.Shell")
Set fileSystem = CreateObject("Scripting.FileSystemObject")

baseFolder = fileSystem.GetParentFolderName(WScript.ScriptFullName)
command = "powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File """ _
    & baseFolder & "\Central de Trabalho.ps1"""

' O zero mantem o PowerShell totalmente oculto. A interface grafica continua
' normal e os modulos sao abertos em processos separados pela Central.
shell.Run command, 0, False
