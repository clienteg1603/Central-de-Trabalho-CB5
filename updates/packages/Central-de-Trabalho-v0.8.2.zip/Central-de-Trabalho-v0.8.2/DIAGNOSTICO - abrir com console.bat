@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0Central de Trabalho.ps1"
if errorlevel 1 (
  echo.
  echo A Central encontrou um erro. Tire uma foto desta janela para o diagnostico.
  pause
)
endlocal
