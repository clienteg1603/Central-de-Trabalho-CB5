@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Testes-Atualizador.ps1"
echo.
pause
exit /b %errorlevel%
