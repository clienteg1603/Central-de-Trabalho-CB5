﻿Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$script:Passed = 0
$script:Failed = 0

function Assert-True {
    param([bool]$Condition, [string]$Name)
    if ($Condition) {
        $script:Passed++
        Write-Host "[OK] $Name" -ForegroundColor Green
    }
    else {
        $script:Failed++
        Write-Host "[FALHA] $Name" -ForegroundColor Red
    }
}

function Assert-Equal {
    param([object]$Expected, [object]$Actual, [string]$Name)
    Assert-True -Condition ([string]$Expected -eq [string]$Actual) -Name $Name
}

function Assert-Throws {
    param([scriptblock]$Action, [string]$Name)
    try {
        & $Action
        Assert-True -Condition $false -Name $Name
    }
    catch {
        Assert-True -Condition $true -Name $Name
    }
}

function Write-TestText {
    param([string]$Path, [string]$Value)
    $parent = [IO.Path]::GetDirectoryName($Path)
    if (-not [IO.Directory]::Exists($parent)) { [void][IO.Directory]::CreateDirectory($parent) }
    [IO.File]::WriteAllText($Path, $Value, [Text.UTF8Encoding]::new($true))
}

function Write-TestPackageManifest {
    param([string]$Root, [string]$Version)

    $rootPrefix = [IO.Path]::GetFullPath($Root).TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
    $files = @()
    foreach ($path in @([IO.Directory]::EnumerateFiles($Root, "*", [IO.SearchOption]::AllDirectories) | Sort-Object)) {
        if ([IO.Path]::GetFileName($path) -eq "PACOTE-MANIFESTO.json") { continue }
        $relative = $path.Substring($rootPrefix.Length).Replace([IO.Path]::DirectorySeparatorChar, '/')
        $files += ,[pscustomobject]@{
            Path = $relative
            Size = (Get-Item -LiteralPath $path).Length
            Sha256 = Get-UpdateFileSha256 -Path $path
        }
    }
    $manifest = [pscustomobject]@{
        SchemaVersion = 1
        AppId = "central-de-trabalho"
        Version = $Version
        Files = $files
    }
    Write-TestText -Path ([IO.Path]::Combine($Root, "PACOTE-MANIFESTO.json")) -Value ($manifest | ConvertTo-Json -Depth 8)
}

function New-TestPackage {
    param(
        [string]$Root,
        [string]$Version,
        [string]$Marker,
        [switch]$IncludeLegacy
    )

    if ([IO.Directory]::Exists($Root)) { [IO.Directory]::Delete($Root, $true) }
    [void][IO.Directory]::CreateDirectory($Root)
    $content = @{
        "Central de Trabalho.exe" = "exe-$Marker"
        "Central de Trabalho.ps1" = "central-$Marker"
        "Atualizador\Central de Trabalho Updater.exe" = "updater-exe-$Marker"
        "Atualizador\Central de Trabalho Updater.ps1" = "updater-$Marker"
        "Atualizador\Update.Core.ps1" = "core-$Marker"
        "Modulos\Gerador-de-Planilhas-CB5-TV5\Gerador Planilhas.ps1" = "gerador-$Marker"
        "Modulos\Central-de-Manutencao-CB5\Central Manutencao CB5.ps1" = "manutencao-$Marker"
    }
    if ($IncludeLegacy) { $content["arquivo-legado.txt"] = "legado" }
    foreach ($relative in $content.Keys) {
        $platformRelative = $relative.Replace('\', [IO.Path]::DirectorySeparatorChar)
        Write-TestText -Path ([IO.Path]::Combine($Root, $platformRelative)) -Value $content[$relative]
    }
    Write-TestPackageManifest -Root $Root -Version $Version
}

$corePath = [IO.Path]::GetFullPath([IO.Path]::Combine($PSScriptRoot, "..", "Update.Core.ps1"))
. $corePath

$testRoot = [IO.Path]::Combine([IO.Path]::GetTempPath(), "CentralUpdaterTests_" + [Guid]::NewGuid().ToString("N"))
$installRoot = [IO.Path]::Combine($testRoot, "instalado")
$payloadRoot = [IO.Path]::Combine($testRoot, "payload")
$stateRoot = [IO.Path]::Combine($testRoot, "estado-atualizador")
$dataRoot = [IO.Path]::Combine($testRoot, "dados-locais")
$script:CentralUpdateStateDirectoryOverride = $stateRoot
$script:CentralUpdateApplicationDataRootOverride = $dataRoot

try {
    [void][IO.Directory]::CreateDirectory($testRoot)

    $centralRoot = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
    foreach ($scriptFile in @(
        ([IO.Path]::Combine($centralRoot, "Central de Trabalho.ps1")),
        ([IO.Path]::Combine($centralRoot, "Atualizador", "Central de Trabalho Updater.ps1")),
        ([IO.Path]::Combine($centralRoot, "Atualizador", "Update.Core.ps1"))
    )) {
        $tokens = $null
        $parseErrors = $null
        [void][Management.Automation.Language.Parser]::ParseFile($scriptFile, [ref]$tokens, [ref]$parseErrors)
        Assert-Equal 0 $parseErrors.Count "Sintaxe válida: $([IO.Path]::GetFileName($scriptFile))"
    }
    Assert-True ([IO.File]::Exists([IO.Path]::Combine($centralRoot, "Central de Trabalho.exe"))) "Executável principal incluído"
    Assert-True ([IO.File]::Exists([IO.Path]::Combine($centralRoot, "Atualizador", "Central de Trabalho Updater.exe"))) "Executável do Atualizador incluído"

    $updaterUiText = Get-Content -LiteralPath ([IO.Path]::Combine($centralRoot, "Atualizador", "Central de Trabalho Updater.ps1")) -Raw -Encoding UTF8
    Assert-True $updaterUiText.Contains('$bodyHost.AutoScroll = $true') "Atualizador mantém conteúdo central rolável"
    Assert-True $updaterUiText.Contains('$footer.RowCount = 2') "Atualizador mantém status separado da barra de ações"
    Assert-True $updaterUiText.Contains('$buttonBar.ColumnCount = 3') "Atualizador mantém três ações principais fixas"
    Assert-True (-not $updaterUiText.Contains('$targetVersion?')) "Confirmação não trata ? como parte do nome da variável"
    Assert-True $updaterUiText.Contains('${targetVersion}?') "Confirmação delimita targetVersion antes do ponto de interrogação"

    Assert-Equal "0.8.0" (ConvertTo-UpdateVersion "v0.8.0") "Normaliza versão iniciada por v"
    Assert-True (Test-NewerUpdateVersion -CurrentVersion "0.8.0" -AvailableVersion "0.8.1") "Reconhece versão mais nova"
    Assert-True (-not (Test-NewerUpdateVersion -CurrentVersion "0.8.0" -AvailableVersion "0.8.0")) "Não reinstala a mesma versão"
    Assert-True (-not (Test-NewerUpdateVersion -CurrentVersion "0.8.0" -AvailableVersion "0.7.0")) "Não oferece versão anterior como nova"
    Assert-Throws { ConvertTo-UpdateVersion "versao-invalida" } "Bloqueia versão inválida"

    Assert-True (Test-SecureUpdateUri "https://exemplo.local/stable.json") "Aceita canal HTTPS"
    Assert-True (-not (Test-SecureUpdateUri "http://exemplo.local/stable.json")) "Bloqueia canal HTTP"
    Assert-True (-not (Test-SecureUpdateUri "stable.json")) "Bloqueia endereço relativo"

    $remote = [pscustomobject]@{
        SchemaVersion = 1
        AppId = "central-de-trabalho"
        Channel = "stable"
        Version = "0.8.1"
        MinimumUpdaterVersion = "1.0.0"
        PackageUrl = "https://exemplo.local/Central-de-Trabalho-v0.8.1.zip"
        PackageSha256 = (("A" * 64) -join "")
        PackageSize = 123
        PackageRoot = "Central-de-Trabalho-v0.8.1"
        ReleaseNotes = @("Teste")
    }
    Assert-True (Assert-RemoteUpdateManifest -Manifest $remote -ExpectedChannel "stable") "Aceita manifesto remoto íntegro"
    $remote.AppId = "outro-programa"
    Assert-Throws { Assert-RemoteUpdateManifest -Manifest $remote -ExpectedChannel "stable" } "Bloqueia manifesto de outro programa"
    $remote.AppId = "central-de-trabalho"
    $remote.Channel = "test"
    Assert-Throws { Assert-RemoteUpdateManifest -Manifest $remote -ExpectedChannel "stable" } "Bloqueia manifesto de outro canal"
    $remote.Channel = "stable"
    $remote.PackageSha256 = "123"
    Assert-Throws { Assert-RemoteUpdateManifest -Manifest $remote -ExpectedChannel "stable" } "Bloqueia SHA-256 remoto inválido"
    $remote.PackageSha256 = ("A" * 64) -join ""
    $remote.PackageRoot = "pasta/outra"
    Assert-Throws { Assert-RemoteUpdateManifest -Manifest $remote -ExpectedChannel "stable" } "Bloqueia raiz remota aninhada"

    New-TestPackage -Root $installRoot -Version "0.8.0" -Marker "antigo" -IncludeLegacy
    New-TestPackage -Root $payloadRoot -Version "0.8.1" -Marker "novo"
    Write-TestText -Path ([IO.Path]::Combine($installRoot, "arquivo-do-usuario.txt")) -Value "preservar"

    Assert-Equal $installRoot (Assert-CentralUpdateInstallRoot -InstallRoot $installRoot) "Reconhece pasta instalada válida"
    Assert-Throws { Assert-CentralUpdateInstallRoot -InstallRoot ([IO.Path]::GetPathRoot($installRoot)) } "Bloqueia raiz ampla como instalação"
    $nested = Resolve-SafeUpdateChildPath -Root $testRoot -RelativePath "seguro\arquivo.txt"
    Assert-True $nested.StartsWith([IO.Path]::GetFullPath($testRoot), [StringComparison]::OrdinalIgnoreCase) "Resolve caminho interno seguro"
    Assert-Throws { Resolve-SafeUpdateChildPath -Root $testRoot -RelativePath "..\fora.txt" } "Bloqueia caminho que sai da pasta"

    Assert-True (Test-UpdatePackagePayload -PackageRoot $payloadRoot -ExpectedVersion "0.8.1") "Valida pacote interno completo"
    Add-Content -LiteralPath ([IO.Path]::Combine($payloadRoot, "Central de Trabalho.ps1")) -Value "alterado"
    Assert-Throws { Test-UpdatePackagePayload -PackageRoot $payloadRoot -ExpectedVersion "0.8.1" } "Detecta arquivo adulterado"
    New-TestPackage -Root $payloadRoot -Version "0.8.1" -Marker "novo"
    Write-TestText -Path ([IO.Path]::Combine($payloadRoot, "extra.txt")) -Value "extra"
    Assert-Throws { Test-UpdatePackagePayload -PackageRoot $payloadRoot -ExpectedVersion "0.8.1" } "Bloqueia arquivo extra no pacote baixado"
    Assert-True (Test-UpdatePackagePayload -PackageRoot $payloadRoot -ExpectedVersion "0.8.1" -AllowExtraFiles) "Permite arquivo local extra só na instalação existente"
    [IO.File]::Delete([IO.Path]::Combine($payloadRoot, "extra.txt"))

    Add-Type -AssemblyName System.IO.Compression
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $unsafeZip = [IO.Path]::Combine($testRoot, "inseguro.zip")
    $zipStream = [IO.File]::Create($unsafeZip)
    $zip = New-Object IO.Compression.ZipArchive($zipStream, [IO.Compression.ZipArchiveMode]::Create)
    try {
        $entry = $zip.CreateEntry("../fora.txt")
        $writer = New-Object IO.StreamWriter($entry.Open())
        try { $writer.Write("não extrair") }
        finally { $writer.Dispose() }
    }
    finally {
        $zip.Dispose()
        $zipStream.Dispose()
    }
    Assert-Throws { Expand-UpdatePackageSafely -ArchivePath $unsafeZip -DestinationDirectory ([IO.Path]::Combine($testRoot, "extraido")) } "Bloqueia travessia de pasta no ZIP"
    Assert-True (-not [IO.File]::Exists([IO.Path]::Combine($testRoot, "fora.txt"))) "ZIP inseguro não grava fora do destino"

    $maintenanceData = [IO.Path]::Combine($dataRoot, "CentralDeTrabalho", "ManutencaoCB5", "base.json")
    $componentData = [IO.Path]::Combine($dataRoot, "GeradorPlanilhasCB5TV5", "componentes-a-faturar.json")
    Write-TestText -Path $maintenanceData -Value "historico-antigo"
    Write-TestText -Path $componentData -Value "saldo-antigo"

    $backup = Install-CentralUpdatePayload -PayloadRoot $payloadRoot -InstallRoot $installRoot -CurrentVersion "0.8.0" -TargetVersion "0.8.1"
    Assert-Equal "central-novo" (([IO.File]::ReadAllText([IO.Path]::Combine($installRoot, "Central de Trabalho.ps1"), [Text.Encoding]::UTF8)).Trim([char]0xFEFF)) "Instala os arquivos da nova versão"
    Assert-True (-not [IO.File]::Exists([IO.Path]::Combine($installRoot, "arquivo-legado.txt"))) "Remove arquivo administrado que saiu da versão"
    Assert-True ([IO.File]::Exists([IO.Path]::Combine($installRoot, "arquivo-do-usuario.txt")) ) "Preserva arquivo local não administrado"
    Assert-True ([IO.Directory]::Exists($backup.ProgramSnapshot)) "Cria cópia completa do programa"
    Assert-True ([IO.File]::Exists([IO.Path]::Combine($backup.DataSnapshot, "CentralDeTrabalho", "ManutencaoCB5", "base.json"))) "Copia o histórico da Manutenção"
    Assert-True ([IO.File]::Exists([IO.Path]::Combine($backup.DataSnapshot, "GeradorPlanilhasCB5TV5", "componentes-a-faturar.json"))) "Copia o saldo de componentes"
    Assert-Equal 1 @(Get-CentralUpdateBackups).Count "Lista o backup criado"

    Write-TestText -Path $maintenanceData -Value "historico-posterior"
    [void](Restore-CentralUpdateBackup -Backup $backup -InstallRoot $installRoot)
    Assert-Equal "central-antigo" (([IO.File]::ReadAllText([IO.Path]::Combine($installRoot, "Central de Trabalho.ps1"), [Text.Encoding]::UTF8)).Trim([char]0xFEFF)) "Restaura a versão anterior do programa"
    Assert-Equal "historico-posterior" (([IO.File]::ReadAllText($maintenanceData, [Text.Encoding]::UTF8)).Trim([char]0xFEFF)) "Restauração normal preserva dados mais recentes"

    Write-TestText -Path $maintenanceData -Value "historico-novo"
    [void](Restore-CentralUpdateBackup -Backup $backup -InstallRoot $installRoot -RestoreData)
    Assert-Equal "historico-antigo" (([IO.File]::ReadAllText($maintenanceData, [Text.Encoding]::UTF8)).Trim([char]0xFEFF)) "Restauração opcional recupera dados do backup"

    $settings = Get-UpdateUserSettings
    $settings.Channel = "test"
    $settings.TestUrl = "https://exemplo.local/test.json"
    Save-UpdateUserSettings -Settings $settings
    $reloaded = Get-UpdateUserSettings
    Assert-Equal "test" $reloaded.Channel "Preferência de canal persiste"
    Assert-Equal "https://exemplo.local/test.json" $reloaded.TestUrl "Endereço configurado persiste"
}
finally {
    $script:CentralUpdateStateDirectoryOverride = ""
    $script:CentralUpdateApplicationDataRootOverride = ""
    try {
        if ([IO.Directory]::Exists($testRoot)) { [IO.Directory]::Delete($testRoot, $true) }
    }
    catch {}
}

Write-Host ""
Write-Host "Resultado: $($script:Passed) aprovadas; $($script:Failed) falhas."
if ($script:Failed -gt 0) { exit 1 }
exit 0
