﻿Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$moduleRoot = Split-Path -Parent (Split-Path -Parent $PSCommandPath)
. ([IO.Path]::Combine($moduleRoot, "Manutencao.Core.ps1"))

$script:Passed = 0
$script:Failed = 0

function Assert-True {
    param([bool]$Condition, [string]$Name)
    if ($Condition) {
        $script:Passed++
        Write-Host "[OK] $Name" -ForegroundColor Green
    }
    else {
        $script:Failed++
        Write-Host "[FALHOU] $Name" -ForegroundColor Red
    }
}

function Assert-Equal {
    param([object]$Expected, [object]$Actual, [string]$Name)
    Assert-True -Condition ($Expected -eq $Actual) -Name "$Name (esperado: $Expected | atual: $Actual)"
}

$temporaryRoot = [IO.Path]::Combine([IO.Path]::GetTempPath(), "CB5-Core-Test-" + [Guid]::NewGuid().ToString("N"))
try {
    [void][IO.Directory]::CreateDirectory($temporaryRoot)

    $centralRoot = Split-Path -Parent (Split-Path -Parent $moduleRoot)
    foreach ($scriptFile in @(
        ([IO.Path]::Combine($centralRoot, "Central de Trabalho.ps1")),
        ([IO.Path]::Combine($moduleRoot, "Central Manutencao CB5.ps1")),
        ([IO.Path]::Combine($moduleRoot, "Manutencao.Core.ps1"))
    )) {
        $tokens = $null
        $parseErrors = $null
        [void][Management.Automation.Language.Parser]::ParseFile($scriptFile, [ref]$tokens, [ref]$parseErrors)
        Assert-Equal 0 $parseErrors.Count "Sintaxe válida: $([IO.Path]::GetFileName($scriptFile))"
    }

    $mainExecutablePath = [IO.Path]::Combine($centralRoot, "Central de Trabalho.exe")
    $hiddenLauncherPath = [IO.Path]::Combine($centralRoot, "ABRIR CENTRAL DE TRABALHO.vbs")
    $diagnosticLauncherPath = [IO.Path]::Combine($centralRoot, "DIAGNOSTICO - abrir com console.bat")
    Assert-True ([IO.File]::Exists($mainExecutablePath)) "O pacote possui o executável principal sem console"
    Assert-True ([IO.File]::Exists($hiddenLauncherPath)) "O iniciador VBS permanece como alternativa"
    $hiddenLauncherSource = [IO.File]::ReadAllText($hiddenLauncherPath)
    Assert-True ($hiddenLauncherSource -match 'shell\.Run command, 0, False') "O iniciador principal mantém a janela do PowerShell oculta"
    Assert-True ([IO.File]::Exists($diagnosticLauncherPath)) "O console fica disponível somente no iniciador de diagnóstico"

    $maintenanceUiPath = [IO.Path]::Combine($moduleRoot, "Central Manutencao CB5.ps1")
    $maintenanceUiSource = [IO.File]::ReadAllText($maintenanceUiPath)
    $centralUiSource = [IO.File]::ReadAllText(([IO.Path]::Combine($centralRoot, "Central de Trabalho.ps1")))
    Assert-True ($centralUiSource -match '\$script:AppVersion\s*=\s*"0\.8\.0"' -and $maintenanceUiSource -match '\$script:AppVersion\s*=\s*"0\.5\.0"') "As versões visuais da Central e da Manutenção estão integradas"
    Assert-True ($maintenanceUiSource -match 'AutoSizeColumnsMode\s*=\s*\[Windows\.Forms\.DataGridViewAutoSizeColumnsMode\]::None') "As tabelas da Manutenção não esticam todas as colunas"
    Assert-True ($maintenanceUiSource -match 'AllowUserToResizeColumns\s*=\s*\$true') "O ajuste manual das colunas continua disponível"
    Assert-True ($maintenanceUiSource -match '@\("Defeito", "Defeito reportado", 100, "Fill", 190\)') "Somente o defeito reportado usa o espaço restante no histórico"
    Assert-True ($maintenanceUiSource -match 'Add-GridColumn \$grid "Quantidade" "Quantidade" 105 "Fixed" 95') "As quantidades das estatísticas abrem compactas"
    Assert-True ($maintenanceUiSource -match '@\("Status", "Situação", 105, "Fixed", 90\)') "A nova situação automática usa uma coluna curta"
    Assert-True ($maintenanceUiSource -match '\$serialBox\s*=\s*New-Object Windows\.Forms\.TextBox') "A série usa um campo de texto comum, sem máscara visual vazia"
    Assert-True ($maintenanceUiSource -match '\$serialBox\.MaxLength\s*=\s*8') "O campo de série limita a entrada a 8 caracteres"
    Assert-True ($maintenanceUiSource -notmatch '\$statusCombo\s*=') "A passagem não exige escolher entre status manuais"
    Assert-True ($maintenanceUiSource -match 'EDITAR / CORRIGIR') "O Histórico oferece acesso claro à edição e correção"
    Assert-True ($maintenanceUiSource -match '\$seriesHistoryGroup\.Text\s*=\s*"Histórico automático da série"') "A passagem mostra o histórico automático da série"
    Assert-True ($maintenanceUiSource -match 'function Refresh-CurrentSeriesHistory') "A série possui uma atualização própria do histórico lateral"
    Assert-True ($maintenanceUiSource -match 'Refresh-CurrentSeriesHistory[\s\S]*?\$serialBox\.Add_KeyPress' -or $maintenanceUiSource -match '\$serialBox\.Add_TextChanged\([\s\S]*?Refresh-CurrentSeriesHistory') "O histórico lateral acompanha a digitação da série"
    Assert-True ($maintenanceUiSource -match '@\("Passagem", "Pass\.", 64, "Fixed", 58\)' -and $maintenanceUiSource -match '@\("Resumo", "Defeito", 100, "Fill", 130\)') "O histórico lateral usa colunas compactas e uma descrição flexível"
    Assert-True ($maintenanceUiSource -match 'function Open-CurrentSeriesHistory') "O painel lateral abre o histórico completo já filtrado"
    Assert-True ($maintenanceUiSource -notmatch '\$quickDiagnosisGroup\s*=') "As hipóteses não ocupam mais a rotina principal da passagem"
    Assert-True ($maintenanceUiSource -match 'New-SummaryCard "Em aberto"') "O painel usa a situação simples Em aberto"
    Assert-True ($maintenanceUiSource -match '\$mainTabs\.DrawMode\s*=\s*\[Windows\.Forms\.TabDrawMode\]::OwnerDrawFixed') "As abas principais acompanham o tema visual da Manutenção"
    Assert-True ($maintenanceUiSource -match '\$savePassageButton\.Tag\s*=\s*"Secondary"') "Salvar andamento não disputa destaque com Concluir passagem"
    Assert-True ($maintenanceUiSource -match '\$savePassageButton\.Text\s*=\s*"SALVAR CORREÇÃO"[\s\S]{0,160}\$savePassageButton\.Tag\s*=\s*"Primary"') "Salvar correção vira a ação principal quando concluir está bloqueado"

    Assert-True (Test-CB5Serial "12345678") "Série com 8 dígitos é aceita"
    Assert-True (-not (Test-CB5Serial "1234567")) "Série com 7 dígitos é rejeitada"
    Assert-True (-not (Test-CB5Serial "1234A678")) "Série alfanumérica é rejeitada"

    $versionCatalog = @(Get-CB5VersionCatalog)
    Assert-Equal 18 $versionCatalog.Count "Catálogo foi reduzido para 18 opções"
    Assert-True ($versionCatalog -contains "5.00/5.05") "Família 5.00 até 5.05 aparece agrupada"
    Assert-True ($versionCatalog -contains "5.10/5.11") "Família 5.10 e 5.11 aparece agrupada"
    Assert-True ($versionCatalog -contains "5.30/31/32") "Família 5.30, 5.31 e 5.32 aparece agrupada"
    Assert-True ($versionCatalog -contains "5.40/5.41") "Família 5.40 e 5.41 aparece agrupada"
    Assert-True (-not ($versionCatalog -contains "5.01")) "Versões individuais da família 5.00 não poluem a lista"

    Assert-True (Test-CB5WorkDate -Code "800" -Date ([datetime]"2026-08-31")) "Código 800 funciona após o dia 20"
    Assert-True (Test-CB5WorkDate -Code "850" -Date ([datetime]"2026-08-20")) "Código 850 funciona no dia 20"
    Assert-True (-not (Test-CB5WorkDate -Code "850" -Date ([datetime]"2026-08-21"))) "Código 850 é bloqueado após o dia 20"
    $codeCatalog = @(Get-CB5CodeCatalog)
    Assert-Equal 3 $codeCatalog.Count "A rotina possui somente os três códigos usados na manutenção"
    Assert-True (-not ($codeCatalog -contains "Garantia")) "Garantia foi retirada dos novos registros"

    $normalResults = @(Get-CB5FinalResultCatalog)
    Assert-Equal 2 $normalResults.Count "A rotina possui dois resultados finais"
    Assert-True ($normalResults -contains "Aprovado") "A rotina permite Aprovado"
    Assert-True ($normalResults -contains "PT") "A rotina permite PT"
    Assert-True (-not ($normalResults -contains "Defeito de fábrica")) "Defeito de fábrica foi retirado da rotina"

    $rule500 = Get-CB5UpdateRule -Version "5.00/5.05"
    Assert-Equal "5.06" $rule500.Destino "5.00/5.05 atualiza para 5.06"
    $rule530 = Get-CB5UpdateRule -Version "5.30/31/32"
    Assert-Equal "5.53" $rule530.Destino "5.30/31/32 atualiza para 5.53"
    $rule540 = Get-CB5UpdateRule -Version "5.40/5.41"
    Assert-Equal "5.54" $rule540.Destino "5.40/5.41 atualiza para 5.54"
    Assert-Equal "modem 4G + Bluetooth" $rule540.Componentes "5.40/5.41 exige modem e Bluetooth"
    Assert-Equal "5.40/5.41" (ConvertTo-CB5VersionFamily "5.40") "Registro antigo 5.40 é normalizado"

    $rule560Before = Get-CB5UpdateRule -Version "5.60" -ModemDefectConfirmed $false
    Assert-True (-not $rule560Before.AplicavelAgora) "5.60 não atualiza sem defeito no modem confirmado"
    $rule560After = Get-CB5UpdateRule -Version "5.60" -ModemDefectConfirmed $true
    Assert-Equal "5.62" $rule560After.Destino "5.60 atualiza para 5.62 quando o modem é confirmado"
    Assert-True $rule560After.AplicavelAgora "Regra condicional é liberada após confirmação"

    $databasePath = Initialize-CB5DataStore -DataDirectory $temporaryRoot
    $store = Read-CB5Store -Path $databasePath
    Assert-Equal 0 (@($store.Passagens).Count) "A base nova começa sem dados fictícios"

    $legacyStore = [pscustomobject]@{
        SchemaVersion = 1
        AppVersion = "0.2.0"
        CriadoEm = "2026-08-31T10:00:00"
        AtualizadoEm = "2026-08-31T10:00:00"
        Passagens = @([pscustomobject]@{ VersaoEntrada = "5.31"; VersaoSaida = "5.41" })
        Esquematicos = @([pscustomobject]@{ Versao = "5.03" })
    }
    $normalizedLegacyStore = Normalize-CB5Store $legacyStore
    Assert-Equal 4 $normalizedLegacyStore.SchemaVersion "Base anterior migra para o esquema 4"
    Assert-Equal "5.30/31/32" $normalizedLegacyStore.Passagens[0].VersaoEntrada "Passagem antiga é agrupada ao carregar"
    Assert-Equal "5.40/5.41" $normalizedLegacyStore.Passagens[0].VersaoSaida "Versão de saída antiga é agrupada ao carregar"
    Assert-Equal "" $normalizedLegacyStore.Passagens[0].ResultadoFinal "Base antiga recebe o novo campo Resultado final"
    Assert-Equal "Em aberto" $normalizedLegacyStore.Passagens[0].Status "Status manual antigo é convertido para situação automática"
    Assert-Equal "5.00/5.05" $normalizedLegacyStore.Esquematicos[0].Versao "Esquemático antigo é agrupado ao carregar"

    $values = @{
        Serie = "12345678"
        Codigo = "800"
        VersaoEntrada = "5.40/5.41"
        VersaoSaida = "5.54"
        DataEntrada = [datetime]"2026-08-10"
        DefeitoReportado = "sem comunicação bluetooth"
        DefeitoEncontrado = "falha no circuito bluetooth"
        OutrosDefeitos = ""
        ManutencaoRealizada = "reparo no circuito bluetooth"
        ResultadoFinal = "Aprovado"
        AtualizacaoIndicada = "5.40/5.41 → 5.54"
        ComponentesExternos = "modem 4G + Bluetooth"
        Observacoes = "caso de teste isolado"
    }

    $validation = Get-CB5ValidationResult -Values $values -ForCompletion $true
    Assert-True $validation.Valido "Aprovado é aceito sem registrar teste ou Ping"

    $missingResult = $values.Clone()
    $missingResult.ResultadoFinal = ""
    Assert-True (-not (Get-CB5ValidationResult -Values $missingResult -ForCompletion $true).Valido) "Conclusão exige um resultado final"

    $ptValues = $values.Clone()
    $ptValues.ResultadoFinal = "PT"
    $ptValues.ManutencaoRealizada = ""
    Assert-True (Get-CB5ValidationResult -Values $ptValues -ForCompletion $true).Valido "PT não exige manutenção realizada"

    $removedCode = $values.Clone()
    $removedCode.Codigo = "Garantia"
    Assert-True (-not (Get-CB5ValidationResult -Values $removedCode -ForCompletion $true).Valido) "Garantia é bloqueada em novos registros"

    $removedResult = $values.Clone()
    $removedResult.ResultadoFinal = "Defeito de fábrica"
    Assert-True (-not (Get-CB5ValidationResult -Values $removedResult -ForCompletion $true).Valido) "Defeito de fábrica é bloqueado na rotina atual"

    $first = New-CB5Passage -Store $store -Values $values
    [void](Complete-CB5Passage -Store $store -Id $first.Id -Values $values)
    Write-CB5Store -Store $store -Path $databasePath

    $reloaded = Read-CB5Store -Path $databasePath
    Assert-Equal 1 (@($reloaded.Passagens).Count) "Passagem continua na base após salvar e recarregar"
    Assert-True (ConvertTo-CB5Boolean $reloaded.Passagens[0].Concluida) "Passagem permanece concluída"
    Assert-Equal "Aprovado" $reloaded.Passagens[0].ResultadoFinal "Resultado final é preservado"
    Assert-Equal "Aprovado" $reloaded.Passagens[0].Status "Aprovado recebe uma situação final simples"

    $correctionValues = $values.Clone()
    $correctionValues.Codigo = "850"
    $corrected = Correct-CB5Passage -Store $reloaded -Id $reloaded.Passagens[0].Id -Values $correctionValues
    Assert-Equal "850" $corrected.Codigo "Código de uma passagem concluída pode ser corrigido"
    Assert-Equal "12345678" $corrected.Serie "A correção não altera a identidade da série"
    Assert-Equal "Aprovado" $corrected.Status "A correção preserva a situação final coerente"
    $correctionEvent = @($corrected.Eventos | Where-Object Tipo -eq "Correção" | Select-Object -Last 1)[0]
    Assert-True ($null -ne $correctionEvent) "A correção cria um evento próprio"
    Assert-True (@($correctionEvent.Alteracoes | Where-Object { $_.Campo -eq "Código" -and $_.Antes -eq "800" -and $_.Depois -eq "850" }).Count -eq 1) "O evento preserva o código anterior e o novo"

    $returnValues = $values.Clone()
    $returnValues.DefeitoReportado = "bluetooth sem comunicação novamente"
    $returnValues.ResultadoFinal = ""
    $second = New-CB5Passage -Store $reloaded -Values $returnValues
    Assert-Equal 2 $second.Passagem "Retorno recebe a passagem 2"
    Assert-True (ConvertTo-CB5Boolean $second.EhRetorno) "Passagem 2 é marcada como retorno"
    Assert-Equal "Em aberto" $second.Status "Nova passagem recebe situação automática Em aberto"
    Assert-Equal 1 (@((Get-CB5PassagesBySerial -Store $reloaded -Serial "12345678") | Where-Object { $_.Passagem -eq 1 }).Count) "Passagem antiga não é apagada"

    $suggestions = @(Get-CB5DiagnosticSuggestions -Store $reloaded -Version "5.40/5.41" -ReportedDefect "bluetooth sem comunicação")
    Assert-True ($suggestions.Count -ge 1) "Diagnóstico encontra hipótese em caso real concluído"
    Assert-Equal "HIPÓTESE" $suggestions[0].Tipo "Sugestão é identificada como hipótese"

    $emptySuggestions = @(Get-CB5DiagnosticSuggestions -Store (New-CB5Store) -Version "5.40/5.41" -ReportedDefect "qualquer")
    Assert-Equal 0 $emptySuggestions.Count "Base vazia não inventa sugestão"

    $resultStats = @(Get-CB5StatisticsRows -Store $reloaded -Field "ResultadoFinal")
    Assert-True (@($resultStats | Where-Object { $_.Item -eq "Aprovado" -and $_.Quantidade -eq 1 }).Count -eq 1) "Estatística contabiliza Aprovado"

    $schema = Add-CB5SchematicEntry -Store $reloaded -Version "5.40/5.41" -Designator "c40" -FilePath "C:\\Esquematicos\\CB5-540.pdf" -Page "12" -Area "Fonte" -Notes "Teste"
    Assert-Equal "C40" $schema.Designador "Designador é normalizado em maiúsculas"
    Assert-Equal 1 (@((Search-CB5SchematicEntries -Store $reloaded -Version "5.40/5.41" -Designator "C40")).Count) "Busca de designador localiza a referência"
}
finally {
    if ([IO.Directory]::Exists($temporaryRoot)) {
        [IO.Directory]::Delete($temporaryRoot, $true)
    }
}

Write-Host ""
Write-Host "Resultado: $($script:Passed) aprovado(s), $($script:Failed) falhou(aram)."
if ($script:Failed -gt 0) { exit 1 }
exit 0
