# Regras confirmadas — Central de Manutenção CB5 v0.5.0

## Escopo

- A Central auxilia a manutenção e não substitui o CQR.
- Ela registra somente as peças que chegam à manutenção.
- O posto do CQR em que o defeito apareceu não é um campo necessário.
- O histórico técnico verdadeiro pertence à série; a distribuição de reparos
  nas planilhas pertence ao faturamento e não deve ser usada como prova técnica.

## Identificação

- A série possui exatamente 8 dígitos numéricos.
- O campo visual é um texto comum, sem caracteres de máscara vazia.
- O código aparece antes da série e permanece selecionado para a próxima peça.
- Novos registros aceitam somente `800`, `850` e `100`.
- `800` não possui restrição de dia.
- `850` e `100` são permitidos do dia 1 ao dia 20.
- Garantia não faz parte da rotina do setor; registros antigos continuam
  preservados somente para consulta.

## Passagem e resultado

- Não existe seleção manual de `Em diagnóstico` ou `Em manutenção`.
- Uma passagem não concluída fica automaticamente `Em aberto`.
- Os resultados finais são `Aprovado` e `PT`.
- Aprovado exige defeito encontrado e manutenção realizada.
- PT exige defeito encontrado e pode ser concluído sem manutenção registrada.
- Teste e Ping não são solicitados pela Central.
- Aprovado significa que a peça deve retornar ao fluxo normal do CQR; não há
  transmissão automática para o outro sistema.

## Histórico, edição e correção

- Uma série pode possuir várias passagens numeradas.
- Ao completar os 8 números da série, as passagens existentes são exibidas
  automaticamente ao lado do formulário, com a mais recente primeiro.
- O painel lateral permite abrir detalhes ou acessar o Histórico completo já
  filtrado para a série.
- Apenas uma passagem da série pode permanecer aberta por vez.
- Um retorno cria uma nova passagem sem alterar as anteriores.
- Uma passagem aberta pode continuar sendo atualizada.
- Uma passagem concluída pode ser corrigida pelo Histórico.
- Série e número da passagem nunca mudam durante uma correção.
- Cada correção preserva campo, valor anterior, valor novo, data e tipo do
  evento. Nenhuma correção apaga silenciosamente o conteúdo anterior.

## Atualização externa de versão

| Origem | Destino previsto | Troca externa |
|---|---|---|
| 5.00/5.05 | 5.06 | modem 4G |
| 5.10/5.11 | 5.12 | modem 4G |
| 5.20 | 5.22 | modem 4G |
| 5.30/31/32 | 5.53 | modem 4G + Bluetooth + LoRa |
| 5.40/5.41 | 5.54 | modem 4G + Bluetooth |
| 5.50 | 5.52 | modem 4G |
| 5.60 | 5.62 | modem 4G, condicionado ao outro setor |
| 5.70 | 5.72 | modem 4G, condicionado ao outro setor |
| 5.80 | 5.82 | modem 4G, condicionado ao outro setor |

Essas relações são avisos informativos. A tela não exige encaminhamento, datas
de envio/retorno nem confirmação manual de defeito no modem.

## Diagnóstico e esquemáticos

- Sugestões usam somente passagens reais concluídas.
- As hipóteses permanecem na aba específica de diagnóstico; o painel lateral da
  passagem é reservado ao histórico real da série.
- Toda sugestão é rotulada como `HIPÓTESE`.
- O diagnóstico confirmado continua sendo decisão técnica do usuário.
- O índice de esquemáticos guarda versão, designador, arquivo, página, área e
  observação sem modificar o arquivo original.

## Limites atuais

- uso local;
- sem usuários em rede;
- sem cronômetro;
- sem integração automática com o CQR;
- sem registros fictícios pré-carregados.
