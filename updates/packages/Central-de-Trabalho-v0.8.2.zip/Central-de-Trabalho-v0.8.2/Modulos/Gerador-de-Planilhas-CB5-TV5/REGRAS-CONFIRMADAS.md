# Regras confirmadas — Gerenciador de Planilhas CB5 e TV5 v3.4.0

## Arquitetura

- Há um único programa com seleção de produto.
- CB5 e TV5 possuem regras internas separadas.
- A versão CB5 1.2.0 permanece preservada como pacote anterior.
- As planilhas mestres são lidas sem alteração quando nenhuma manutenção adicional é informada.
- Quando existe ao menos uma quantidade adicional maior que zero, somente a coluna `REPARO` da mestre é atualizada.
- Os arquivos gerados são salvos automaticamente na Área de Trabalho.
- Arquivos existentes são substituídos somente após confirmação.
- O programa não cria pastas permanentes de backup; a reversão usa somente arquivos temporários apagados ao final.

## Interface 3.4

- A interface foi redesenhada sem alterar as regras de transformação das planilhas.
- A ordem das abas é `Gerar planilhas`, `Manutenções adicionais`,
  `Componentes a faturar`, `Juntar lotes` e `Legenda de códigos`.
- A aba `Componentes a faturar` possui indicadores de componentes ativos, unidades
  pendentes e uniões processadas.
- As abas principais calculam sua largura pelo texto e exibem uma explicação ao
  passar o mouse.
- Áreas sem mestre, lotes ou resultados mostram uma orientação curta para o
  próximo passo.
- `Saldos`, `Movimentações` e `Uniões processadas` são abas internas, evitando
  duas grades apertadas na mesma tela.
- A pesquisa de componentes aceita designador, nome, código da planilha, texto
  do REPARO e apelidos; `U4` permanece diferente de `U40`.
- A aba final usa sempre o nome `Juntar lotes`; o produto continua identificado no seletor, nas instruções e no botão de geração.
- Os temas `Claro moderno`, `Escuro grafite` e `Alto contraste` usam a mesma funcionalidade.
- O CB5 usa destaque azul e o TV5 usa destaque verde; no alto contraste, ambos usam amarelo para máxima legibilidade.
- A aparência, o último produto e a última pasta selecionada são salvos
  localmente e recuperados na próxima abertura.
- A mestre selecionada, as manutenções e o efeito sobre a mestre aparecem no resumo visual antes da validação.
- Quantidades adicionais maiores que zero são destacadas na grade individual e na união.
- Antes de qualquer gravação, existe uma confirmação com produto, lote, peças, adicionais, arquivos e situação da mestre.
- O rodapé fixo contém progresso, versão, ação principal e botão para abrir a pasta de destino.
- O rodapé permanece encaixado no limite inferior da área interna, e seus botões são centralizados novamente após mudanças de tamanho ou escala.
- O botão principal e a área de resultado permanecem separados em janela mínima, normal e maximizada.
- A janela calcula o tamanho inicial pela área útil do monitor, respeita a escala de exibição do Windows e continua ajustável manualmente.
- Em telas pequenas, as abas usam rolagem interna para manter todos os controles acessíveis.
- O botão `Selecionar mestre...` mantém tamanho fixo em uma área própria; o caminho da mestre fica na linha inferior e não pode encobri-lo.
- O programa possui ícone próprio e uma tela curta de abertura.
- Os resultados da geração e da união possuem botão de cópia.
- Em `Juntar lotes`, todas as quantidades de uma linha podem ser copiadas e
  coladas em outra linha do mesmo produto.
- `Consumir saldo de componentes a faturar` abre marcado em `Juntar lotes` e
  pode ser desmarcado antes da conferência ou da geração.

## Conferir sem gravar

- A conferência individual abre a mestre somente para leitura, valida sua
  estrutura e mostra as séries cujo `REPARO` seria alterado.
- A conferência individual TV5 aceita NF vazia, mas informa que a geração final
  continua exigindo a NF.
- A conferência da união executa as mesmas validações de produto, NF, lote,
  série, ICCIDs do CB5 e manutenção. O saldo é consultado somente quando a
  opção de consumo está marcada.
- A previsão informa mestres que mudariam e os saldos anterior e posterior de
  cada baixa.
- Nenhuma conferência cria arquivo, atualiza mestre, registra união ou altera a
  base de componentes.

## Atualizar somente a mestre — CB5 e TV5

- O botão fica disponível nas abas `Gerar planilhas` e `Manutenções adicionais`.
- Ele exige ao menos uma quantidade adicional maior que zero.
- A mestre TV5 pode estar com a NF vazia no nome e nas colunas E e F.
- A mestre CB5 não precisa ter NF preenchida nesse caminho.
- Todas as demais validações da estrutura, lote, série, operadoras e ICCIDs
  continuam ativas conforme o produto.
- A operação altera somente as células da coluna `REPARO`, da linha 2 até a
  última peça; nenhum arquivo final é criado.
- Não ocorre baixa de componentes nessa etapa. A baixa pertence exclusivamente
  à conclusão bem-sucedida de `Juntar lotes`.
- A geração individual e a união continuam exigindo suas NFs normalmente.

## Componentes a faturar

- O saldo significa quantidade já usada e ainda pendente de faturamento, não
  quantidade disponível em estoque.
- A base inicial contém 8 componentes CB5 e 10 TV5, conforme a planilha enviada.
- `R25` é tratado como `RESISTOR`; `U40` permanece com nome não informado.
- Lançamentos manuais somam saldo, ajustes definem o saldo exato e ambos geram
  histórico com valor anterior e posterior.
- Novos componentes podem ser cadastrados sem apagar os anteriores.
- O reconhecimento usa produto, designador exato, texto principal e apelidos,
  com limite de palavra; por isso `U4` não é confundido com `U40`.
- Um componente sem código da TABELA pode ser controlado, mas uma mestre que o
  utilize não é gerada até o código ser informado.
- Componentes inativos não participam do reconhecimento nem da baixa.
- A persistência usa `componentes-a-faturar.json` em
  `%LOCALAPPDATA%\GeradorPlanilhasCB5TV5`.
- O backup manual exporta componentes, saldos, movimentações e uniões em JSON.
- A restauração mostra uma comparação da base atual com o arquivo escolhido e
  exige confirmação antes da substituição.
- A lista de uniões processadas mostra data, NF, lotes, total e detalhamento das
  baixas; operações sem componente também permanecem visíveis.

## União de lotes da mesma NF — CB5 e TV5

- A aba de união é separada da geração individual já existente e acompanha o produto escolhido.
- Podem ser selecionadas duas ou mais mestres do mesmo produto que possuam a mesma NF.
- A interface bloqueia a seleção de uma mestre TV5 no modo CB5 e de uma mestre CB5 no modo TV5.
- Cada mestre deve continuar contendo apenas um lote.
- Lotes repetidos, arquivos repetidos e séries repetidas entre lotes interrompem a geração.
- A NF do nome de todas as mestres deve ser a mesma e deve corresponder à coluna `NF DE SAÍDA`.
- A ordem escolhida na lista é preservada no arquivo final e pode ser alterada pelos botões `Subir` e `Descer`.
- As linhas dos lotes ficam contínuas em ORÇAMENTO e MANUTENÇÃO, sem repetir cabeçalho e sem linha vazia entre os lotes.
- A TABELA atual do programa é criada uma única vez; tabelas antigas não são importadas das mestres ou de arquivos de exemplo.
- As manutenções adicionais são informadas separadamente para cada lote e começam novamente na primeira peça daquele lote.
- O resultado mostra uma linha de faturamento separada para cada lote.
- O arquivo final usa o produto e a NF comum no nome, por exemplo `CB5 - NF 5.138.xlsx` ou `TV5 - NF 5.178.xlsx`.
- O botão de união permanece fixo no canto inferior direito, inclusive com a janela maximizada.
- A coluna REPARO já atualizada é a fonte da contagem automática dos componentes.
- Com o consumo marcado, a baixa é planejada e mostrada antes da confirmação,
  mas só é gravada depois da planilha final e de todas as mestres temporárias
  terem sido geradas.
- Com o consumo marcado, saldo insuficiente bloqueia a operação antes da
  confirmação de gravação.
- Com o consumo desmarcado, o programa não interpreta os reparos para saldo,
  não consulta quantidades e não cria movimentos de baixa.
- Uma união sem consumo é registrada como `Sem consumo por escolha` e mantém o
  saldo intacto.
- Saída, mestres atualizadas e base de componentes participam da mesma lista de
  substituições; uma falha restaura os arquivos já comprometidos.
- A chave de idempotência usa produto e o conjunto ordenado de lotes. A NF não
  integra essa chave, portanto renomear ou corrigir a NF não autoriza nova baixa.
- Toda união bem-sucedida recebe um registro próprio, inclusive quando não há
  componente a baixar ou quando o consumo foi desmarcado. Por isso os mesmos
  lotes não podem virar uma baixa automática posterior por engano.

### Resultado da união CB5

- A mestre CB5 usada na união possui dez colunas: as oito colunas operacionais do CB5, `NF DE ENTRADA` e `NF DE SAÍDA`.
- As duas colunas de NF são obrigatórias na união; a NF de saída deve corresponder à NF do nome do arquivo.
- O arquivo final possui as abas `ORÇAMENTO`, `MANUTENÇÃO` e `TABELA`.
- ORÇAMENTO reúne as dez colunas das mestres na ordem escolhida e inclui na coluna REPARO as manutenções adicionais informadas para cada lote.
- MANUTENÇÃO reúne SÉRIE e os códigos automáticos/adicionais, reiniciando cada quantidade adicional na primeira peça de cada lote.
- TABELA usa todos os códigos atuais do CB5, inclusive códigos que não apareçam em arquivos de exemplo antigos.
- Além de lote e série, ICCID1 e ICCID2 repetidos entre os lotes interrompem a geração.
- Operadoras diferentes entre lotes são permitidas; cada lote continua sendo validado internamente.

## CB5

As regras CB5 da versão 1.2.0 foram mantidas:

- A mestre possui SÉRIE, LOTE, VERSÃO, REPARO, OPERADORA1, ICCID1, OPERADORA2 e ICCID2.
- O programa gera Manutenção, Chip1 e Chip2.
- ASTEC, ASTEC 1, ASTEC 2 e ASTEC 3 continuam habilitados.
- A mestre também pode chegar com manutenções já escritas depois do ASTEC, separadas por vírgulas, por exemplo `ASTEC, TROCADO U20, RS232, CONECTOR USB`.
- São reconhecidos na coluna REPARO os componentes adicionais atuais do CB5: RS232, SICMA, MEMÓRIA FLASH, CAPACITOR, RS485, U20, PROCESSADOR e CONECTOR USB.
- As manutenções adicionais continuam sendo aplicadas às primeiras peças do lote.
- Quando houver várias manutenções adicionais, elas são ordenadas da maior quantidade para a menor antes de serem aplicadas.
- Os nomes de Chip1 e Chip2 continuam acompanhando lote e operadora.

### Nome das operadoras nos arquivos de chip

| Valor na mestre | Nome no arquivo |
|---|---|
| `onixsat.vivo.com.br` | `Vivo` |
| `onixsat.claro.com.br` | `Claro` |
| `onixsat.tim.br` | `Tim` |
| `trucks.v.quectel.br` | `Quectel` |
| `onixsat.vodafone.br` | `Arquia` |

## TV5 — mestre

A mestre TV5 possui seis colunas:

| Coluna | Cabeçalho |
|---|---|
| A | SÉRIE |
| B | LOTE |
| C | VERSÃO |
| D | REPARO |
| E | NF DE ENTRADA |
| F | NF DE SAÍDA |

- A ordem das peças é preservada.
- O lote deve ser único e a série não pode se repetir.
- A coluna D começa com `ASTEC TV5` e pode conter LCD e manutenções já escritas, separadas por vírgulas, por exemplo `ASTEC TV5, TROCADO LCD, BUZZER, RS485`.
- O nome da mestre contém a NF entre parênteses.
- Exemplo: `TV5 - Lote 0826982 (NF 5.225).xlsx`.

## TV5 — nome do arquivo gerado

- A NF é extraída do nome da mestre.
- Exemplo de saída: `TV5 - NF 5.225.xlsx`.

## TV5 — abas geradas

### ORÇAMENTO

- Copia integralmente as seis colunas da mestre.
- As manutenções adicionais alteram apenas a coluna D da cópia gerada.
- Sem manutenção adicional, a mestre original não é alterada.
- Com ao menos uma quantidade adicional maior que zero, a mesma coluna D também é gravada na mestre selecionada.
- A coluna D usa os nomes dos componentes, não os códigos.

Exemplos:

- `TBZ = 20`: `ASTEC TV5, TROCADO LCD` vira `ASTEC TV5, TROCADO LCD, BUZZER`.
- `TBZ = 20`: `ASTEC TV5` vira `ASTEC TV5, TROCADO BUZZER`.
- `TBZ = 20` e `TRS485 = 20`: pode ficar `ASTEC TV5, TROCADO LCD, BUZZER, RS485`.
- Sem LCD na mestre, o mesmo caso fica `ASTEC TV5, TROCADO BUZZER, RS485`.

### MANUTENÇÃO

- Coluna A: SÉRIE da coluna A da mestre.
- Coluna B: códigos de reparo.
- `ASTEC TV5, TROCADO LCD` gera `ATFW, TGBE, AT, TCB, TM, CXPP, TLCD`.
- `ASTEC TV5` gera `ATFW, TGBE, AT, TCB, TM, CXPP`.
- As manutenções adicionais entram como códigos, por exemplo `TBZ, TRS485`.

### TABELA

- Mantém os códigos, descrições e observações do modelo fornecido.
- Linhas 2 a 7: códigos automáticos.
- Linha 8 (`TLCD`): não é uma opção adicional; entra automaticamente quando o LCD estiver informado na mestre.
- Linhas 9 a 11: opções adicionais que usam no ORÇAMENTO o componente obtido da coluna B (`BUZZER`, `RS485`, `PROCESSADOR`).
- Da linha 12 em diante: opções adicionais que usam no ORÇAMENTO a indicação da coluna C (`CN1`, `CN2`, `CN5 CN6`, `CN8`, `D`, `U`, `R`, `L`, `X`, `C`).
- Na MANUTENÇÃO, todas as opções adicionais continuam usando o código da coluna A.
- A ordem, os códigos e as descrições não são renomeados.

## Quantidades adicionais TV5

- Cada código começa novamente na primeira peça do lote.
- Quantidades sobrepostas aplicam vários códigos à mesma peça.
- A ordem no ORÇAMENTO e na MANUTENÇÃO segue a quantidade decrescente; em empate, permanece a ordem da TABELA.
- Um código que já faz parte do reparo automático não é duplicado.
- No ORÇAMENTO, a primeira manutenção adicional de uma peça sem LCD começa com `TROCADO`; as seguintes acrescentam somente vírgula e o componente ou indicação.

## Atualização condicional das mestres — CB5 e TV5

- A atualização vale tanto para a geração individual quanto para a união de lotes.
- Se todas as quantidades estiverem vazias ou em zero, a mestre não é copiada, regravada nem substituída.
- Se alguma quantidade adicional for maior que zero, o programa cria uma versão temporária, altera somente a coluna `REPARO` e substitui a mestre selecionada.
- Na união, cada lote é tratado separadamente: somente as mestres cujas linhas possuem manutenção adicional são atualizadas.
- As manutenções já existentes são reconhecidas e não são duplicadas em uma nova execução.
- As bases automáticas (`ASTEC 1`, `ASTEC 2`, `ASTEC 3` e LCD do TV5) não contam como manutenção adicional e, sozinhas, não provocam a substituição da mestre.
- Se alguma gravação falhar, os arquivos já substituídos naquela operação são restaurados pelas cópias temporárias de reversão.
- As cópias temporárias de reversão são apagadas automaticamente e não deixam uma pasta de backup na Área de Trabalho.
- O botão `Atualizar somente a mestre` é uma exceção intencional à geração:
  nele a NF pode estar pendente, mas continua obrigatório informar uma
  manutenção adicional e confirmar a substituição da coluna REPARO.

## Resumo para faturamento

- A linha imediatamente abaixo de `CONCLUÍDO` é um resumo pronto para copiar.
- O resumo fica no alto do campo, sem depender de rolagem.
- O lote é exibido pelos três últimos caracteres e a quantidade corresponde ao total de peças da mestre.
- CB5 com versão final a partir de 5.52: `CB5 - Lote 885 - 50 pçs (5.40) (43 MODEM 4G + 31 BLUETOOTH)`.
- CB5 com versão final até 5.22: `CB5 - Lote 885 - 50 pçs (5.30) (43 MODEM 4G + 31 BLUETOOTH)`.
- TV5: `TV5 - Lote 982 - 100 pçs + MANUTENÇÃO`.
- A família de faturamento fica imediatamente depois da quantidade de peças.
- A versão é lida da coluna VERSÃO; blocos adicionais são aceitos, portanto `5.54.0` pertence à família `5.40`.
- Uma versão entre 5.23 e 5.51 bloqueia a geração e pede conferência, pois essa faixa ainda não possui família definida.
- Um lote que misture peças das famílias 5.30 e 5.40 também é bloqueado.
- No CB5, os parênteses mostram as quantidades automáticas de MODEM 4G, BLUETOOTH e, quando existir, LORA.
- Quando a manutenção automática estiver presente em todas as peças, sua quantidade é omitida: `MODEM 4G`, `BLUETOOTH` ou `LORA`.
- Quando faltar em pelo menos uma peça, a quantidade permanece explícita, por exemplo `49 MODEM 4G`.
- Essa verificação é feita separadamente para MODEM 4G, BLUETOOTH e LORA.
- O sufixo `+ MANUTENÇÃO` aparece somente quando pelo menos uma manutenção adicional foi informada.

## Validação inicial

- A mestre TV5 de 100 peças foi reproduzida sem extras e comparada linha a linha com o arquivo de referência.
- O teste `TBZ = 20` foi aplicado somente às primeiras 20 peças.
- O teste conjunto `TBZ = 20` e `TRS485 = 20` foi incluído.
- TLCD automático não foi duplicado.
- Manutenções adicionais sobrepostas preservaram a ordem da TABELA.
- As linhas 9 a 11 foram conferidas usando a coluna B, e as linhas 12 a 21 usando a coluna C.
- O nome `TV5 - NF 5.225.xlsx` foi extraído corretamente da mestre.
- Foram testadas cópias reais de mestres CB5 e TV5 com atualização da coluna D, preservação de estilo, limites de quantidade e segunda execução sem duplicidade.
- Foi testado o fluxo sem adicionais, no qual a condição de atualização permanece falsa e a mestre não entra na transação de gravação.
- A mestre TV5 enviada com 100 séries, lote 0826983 e NF vazia foi reconhecida;
  seus designadores CN1, R25, U4 e U15 foram validados separadamente.
- O fluxo de atualização sem NF foi exercitado para CB5 e TV5, mantendo a
  geração final bloqueada enquanto a NF estiver vazia.
- Foram testadas a gravação restrita a `D2:Dúltima linha`, a proteção U4/U40,
  saldo insuficiente, persistência do histórico e repetição dos mesmos lotes
  com uma NF diferente.
