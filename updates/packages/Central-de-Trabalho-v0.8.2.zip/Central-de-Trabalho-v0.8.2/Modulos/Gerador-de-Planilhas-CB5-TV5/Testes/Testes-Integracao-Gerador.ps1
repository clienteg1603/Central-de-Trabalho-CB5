﻿Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$moduleRoot = Split-Path -Parent (Split-Path -Parent $PSCommandPath)
$generatorPath = [IO.Path]::Combine($moduleRoot, "Gerador Planilhas.ps1")
. ([IO.Path]::Combine($moduleRoot, "Componentes.Core.ps1"))

$script:Passed = 0
$script:Failed = 0

function Assert-True {
    param([bool]$Condition, [string]$Name)
    if ($Condition) {
        $script:Passed++
        Write-Host "[OK] $Name" -ForegroundColor Green
    }
    else {
        $script:Failed++
        Write-Host "[FALHOU] $Name" -ForegroundColor Red
    }
}

function Assert-Equal {
    param([AllowNull()][object]$Expected, [AllowNull()][object]$Actual, [string]$Name)
    Assert-True -Condition ($Expected -eq $Actual) -Name "$Name (esperado: $Expected | atual: $Actual)"
}

function Assert-Throws {
    param([scriptblock]$Action, [string]$Name)
    $threw = $false
    try { & $Action }
    catch { $threw = $true }
    Assert-True $threw $Name
}

function Import-GeneratorFunctionsForTest {
    $needed = @(
        "Release-ComObject", "Normalize-Text", "Normalize-Header", "Get-LastRequiredRow",
        "Assert-GeneratedFile", "Get-OperatorDisplayName", "Get-MaintenanceCodes",
        "Get-RepairComponentKey", "Get-CB5RepairInfo", "Get-VivoVersion",
        "Assert-TextIdentifier", "Read-MasterWorkbook", "Get-TV5RepairInfo",
        "Read-TV5MasterWorkbook", "Save-UpdatedMasterCopy", "New-ObjectMatrix",
        "Apply-AdditionalMaintenance", "Apply-TV5AdditionalMaintenance",
        "Get-RepairSnapshot", "Get-RepairPreviewRows", "Get-LotSuffix",
        "Get-CB5BillingVersionFamily", "Get-BillingSummary"
    )
    $tokens = $null
    $parseErrors = $null
    $ast = [Management.Automation.Language.Parser]::ParseFile($generatorPath, [ref]$tokens, [ref]$parseErrors)
    if ($parseErrors.Count -gt 0) { throw "O Gerador possui erro de sintaxe e não pode ser testado." }
    $definitions = @($ast.FindAll({
        param($node)
        $node -is [Management.Automation.Language.FunctionDefinitionAst]
    }, $true) | Where-Object { $needed -contains $_.Name } | Sort-Object { $_.Extent.StartOffset })
    foreach ($name in $needed) {
        if (@($definitions | Where-Object Name -eq $name).Count -ne 1) { throw "Função de teste não encontrada no Gerador: $name" }
    }
    return @($definitions | ForEach-Object { $_.Extent.Text })
}

function New-OneBasedMatrix {
    param([int]$Rows, [int]$Columns)
    return ,([Array]::CreateInstance([object], [int[]]@($Rows, $Columns), [int[]]@(1, 1)))
}

function New-MockExcel {
    param([object]$Matrix, [int]$LastRow)
    $global:BillingTestMockRange = [pscustomobject]@{ Value2 = $Matrix; NumberFormat = $null }
    $global:BillingTestLastRow = $LastRow
    $global:BillingTestRangeStart = ""
    $global:BillingTestRangeEnd = ""

    $global:BillingTestMockSheet = [pscustomobject]@{}
    $global:BillingTestMockSheet | Add-Member -MemberType ScriptMethod -Name Range -Value {
        param($startAddress, $endAddress)
        $global:BillingTestRangeStart = [string]$startAddress
        $global:BillingTestRangeEnd = [string]$endAddress
        return $global:BillingTestMockRange
    }

    $worksheets = [pscustomobject]@{}
    $worksheets | Add-Member -MemberType ScriptMethod -Name Item -Value {
        param($index)
        return $global:BillingTestMockSheet
    }

    $global:BillingTestMockWorkbook = [pscustomobject]@{ Worksheets = $worksheets }
    $global:BillingTestMockWorkbook | Add-Member -MemberType ScriptMethod -Name Close -Value { param($saveChanges) }
    $global:BillingTestMockWorkbook | Add-Member -MemberType ScriptMethod -Name Save -Value { }

    $workbooks = [pscustomobject]@{}
    $workbooks | Add-Member -MemberType ScriptMethod -Name Open -Value {
        param($path, $updateLinks, $readOnly)
        return $global:BillingTestMockWorkbook
    }
    return [pscustomobject]@{ Workbooks = $workbooks }
}

$generatorFunctionDefinitions = @(Import-GeneratorFunctionsForTest)
foreach ($definitionText in $generatorFunctionDefinitions) { . ([ScriptBlock]::Create($definitionText)) }

# Os mocks não são COM e a quantidade de linhas já é conhecida pela matriz.
function Release-ComObject { param($Object) }
function Get-LastRequiredRow { param($Sheet, [int]$FirstColumn, [int]$LastColumn) return $global:BillingTestLastRow }

$script:CB5MaintenanceDefinitions = @(
    [pscustomobject]@{ Code = "TC"; Level = 0; Description = "TROCA DE CHIP(S)" },
    [pscustomobject]@{ Code = "TRS232"; Level = $null; Description = "TROCADO RS232" },
    [pscustomobject]@{ Code = "TRCUS"; Level = $null; Description = "TROCADO CONECTOR USB" }
)
$script:MaintenanceDefinitions = $script:CB5MaintenanceDefinitions
$script:TV5MaintenanceDefinitions = @(
    [pscustomobject]@{ Code = "ATFW"; Additional = $false; BudgetAction = ""; BudgetComponent = "" },
    [pscustomobject]@{ Code = "TGBE"; Additional = $false; BudgetAction = ""; BudgetComponent = "" },
    [pscustomobject]@{ Code = "AT"; Additional = $false; BudgetAction = ""; BudgetComponent = "" },
    [pscustomobject]@{ Code = "TCB"; Additional = $false; BudgetAction = ""; BudgetComponent = "" },
    [pscustomobject]@{ Code = "TM"; Additional = $false; BudgetAction = ""; BudgetComponent = "" },
    [pscustomobject]@{ Code = "CXPP"; Additional = $false; BudgetAction = ""; BudgetComponent = "" },
    [pscustomobject]@{ Code = "TRCNL"; Additional = $true; BudgetAction = "TROCADO"; BudgetComponent = "CN1" },
    [pscustomobject]@{ Code = "TR"; Additional = $true; BudgetAction = "TROCADO"; BudgetComponent = "R" },
    [pscustomobject]@{ Code = "TPRC"; Additional = $true; BudgetAction = "TROCADO"; BudgetComponent = "PROCESSADOR" },
    [pscustomobject]@{ Code = "TCI"; Additional = $true; BudgetAction = "TROCADO"; BudgetComponent = "U" }
)
$script:BillingComponentStore = New-BillingComponentStore

$temporaryRoot = [IO.Path]::Combine([IO.Path]::GetTempPath(), "Gerador-Integracao-Test-" + [Guid]::NewGuid().ToString("N"))
try {
    [void][IO.Directory]::CreateDirectory($temporaryRoot)

    $tvMatrix = New-OneBasedMatrix 3 6
    @("SERIE", "LOTE", "VERSAO", "REPARO", "NF DE ENTRADA", "NF DE SAIDA") | ForEach-Object -Begin { $column = 1 } -Process {
        $tvMatrix[1, $column] = $_
        $column++
    }
    $tvRows = @(
        @("10000001", "0826983", "5.20", "ASTEC TV5, TROCADO CN1, R25, U4, U15", "", ""),
        @("10000002", "0826983", "5.20", "ASTEC TV5", "", "")
    )
    for ($row = 0; $row -lt $tvRows.Count; $row++) {
        for ($column = 0; $column -lt 6; $column++) { $tvMatrix[($row + 2), ($column + 1)] = $tvRows[$row][$column] }
    }
    $tvExcel = New-MockExcel $tvMatrix 3
    $tvData = Read-TV5MasterWorkbook $tvExcel "TV - Lote 0826983 (NF ).xlsx" -AllowBlankInvoices
    Assert-Equal 2 $tvData.Items.Count "A atualização TV5 aceita a mestre com NF vazia"
    Assert-Equal "0826983" $tvData.Lot "O lote TV5 é preservado"
    Assert-Throws { [void](Read-TV5MasterWorkbook $tvExcel "TV - Lote 0826983 (NF ).xlsx") } "A geração final TV5 continua bloqueando NF vazia"

    $tvOriginalRepairs = Get-RepairSnapshot -Items @($tvData.Items)
    $tvAdditional = [Collections.Generic.List[object]]::new()
    $tvAdditional.Add([pscustomobject]@{ Code = "TRCNL"; Quantity = 2 })
    Apply-TV5AdditionalMaintenance $tvData.Items $tvAdditional
    Assert-Equal "ASTEC TV5, TROCADO CN1, R25, U4, U15" $tvData.Items[0].Repair "Componente TV5 já existente não é duplicado"
    Assert-Equal "ASTEC TV5, TROCADO CN1" $tvData.Items[1].Repair "Componente TV5 é acrescentado somente à peça necessária"
    $tvPreviewRows = @(Get-RepairPreviewRows -Items @($tvData.Items) -OriginalRepairs $tvOriginalRepairs)
    Assert-Equal 1 $tvPreviewRows.Count "A conferência sem gravação lista somente as séries que mudariam"
    Assert-Equal "10000002" $tvPreviewRows[0].Serie "A conferência identifica a série alterada"
    Assert-Equal "ASTEC TV5" $tvPreviewRows[0].Antes "A conferência preserva o REPARO anterior"
    Assert-Equal "ASTEC TV5, TROCADO CN1" $tvPreviewRows[0].Depois "A conferência mostra o REPARO previsto"

    $cbMatrix = New-OneBasedMatrix 2 8
    @("SERIE", "LOTE", "VERSAO", "REPARO", "OPERADORA1", "ICCID1", "OPERADORA2", "ICCID2") | ForEach-Object -Begin { $column = 1 } -Process {
        $cbMatrix[1, $column] = $_
        $column++
    }
    $cbRow = @("20000001", "0900001", "5.54.0", "ASTEC", "onixsat.vivo.com.br", "89550000000000000001", "onixsat.claro.com.br", "89550000000000000002")
    for ($column = 0; $column -lt 8; $column++) { $cbMatrix[2, ($column + 1)] = $cbRow[$column] }
    $cbExcel = New-MockExcel $cbMatrix 2
    $cbData = Read-MasterWorkbook $cbExcel "CB5 - Lote 0900001 (NF ).xlsx"
    Assert-Equal 1 $cbData.Items.Count "A atualização CB5 aceita a mestre sem exigir NF"
    Assert-Equal "Vivo" $cbData.Operator1Name "As validações normais da mestre CB5 continuam ativas"

    $cbAdditional = [Collections.Generic.List[object]]::new()
    $cbAdditional.Add([pscustomobject]@{ Code = "TRCUS"; Quantity = 1 })
    Apply-AdditionalMaintenance $cbData.Items $cbAdditional
    Assert-Equal "ASTEC, TROCADO CONECTOR USB" $cbData.Items[0].Repair "Manutenção CB5 é acrescentada ao REPARO"

    $sourcePath = [IO.Path]::Combine($temporaryRoot, "mestre.xlsx")
    $destinationPath = [IO.Path]::Combine($temporaryRoot, "mestre-atualizada.xlsx")
    [IO.File]::WriteAllText($sourcePath, "conteudo de teste")
    $saveExcel = New-MockExcel $tvMatrix 3
    Save-UpdatedMasterCopy $saveExcel $sourcePath $tvData.Items $destinationPath
    Assert-Equal "D2" $global:BillingTestRangeStart "A gravação da mestre começa somente na coluna REPARO"
    Assert-Equal "D3" $global:BillingTestRangeEnd "A gravação da mestre termina na última linha de REPARO"
    Assert-Equal $tvData.Items[0].Repair $global:BillingTestMockRange.Value2[0, 0] "O primeiro REPARO atualizado é gravado"
    Assert-Equal $tvData.Items[1].Repair $global:BillingTestMockRange.Value2[1, 0] "O segundo REPARO atualizado é gravado"

    $deductionKey = Get-BillingOperationKey -Product "TV5" -Invoice "500" -Lots @("0826983", "0826984")
    $deductionPlan = Get-BillingDeductionPlan -Store $script:BillingComponentStore -Product "TV5" -Items $tvData.Items -OperationKey $deductionKey
    Assert-Equal 2 (@($deductionPlan.Linhas | Where-Object Componente -eq "CN1")[0].Quantidade) "A baixa conta CN1 uma vez em cada peça, sem duplicar o texto existente"
    Assert-Equal 1 (@($deductionPlan.Linhas | Where-Object Componente -eq "R25")[0].Quantidade) "R25 é reconhecido pelo designador exato da mestre enviada"
    Assert-Equal 1 (@($deductionPlan.Linhas | Where-Object Componente -eq "U4")[0].Quantidade) "U4 TV5 é reconhecido como processador"
    Assert-Equal 1 (@($deductionPlan.Linhas | Where-Object Componente -eq "U15")[0].Quantidade) "U15 TV5 é reconhecido como fonte"

    $emptyAdditional = [Collections.Generic.List[object]]::new()
    $billingItems40 = [Collections.Generic.List[object]]::new()
    for ($index = 1; $index -le 50; $index++) {
        $repairLevel = if ($index -le 31) { 2 } elseif ($index -le 43) { 1 } else { 0 }
        $fullVersion = if ($index -eq 1) { "5.52" } else { "5.54.0" }
        $billingItems40.Add([pscustomobject]@{ FullVersion = $fullVersion; RepairLevel = $repairLevel })
    }
    $billingData40 = [pscustomobject]@{ Lot = "0000885"; Items = $billingItems40 }
    Assert-Equal "5.40" (Get-CB5BillingVersionFamily $billingData40) "Versões finais a partir de 5.52 usam a família 5.40"
    Assert-Equal "CB5 - Lote 885 - 50 pçs (5.40) (43 MODEM 4G + 31 BLUETOOTH)" (Get-BillingSummary "CB5" $billingData40 $emptyAdditional) "O resumo CB5 mostra a família 5.40 antes das manutenções"

    $billingItems30 = [Collections.Generic.List[object]]::new()
    for ($index = 1; $index -le 50; $index++) {
        $repairLevel = if ($index -le 31) { 2 } elseif ($index -le 43) { 1 } else { 0 }
        $billingItems30.Add([pscustomobject]@{ FullVersion = "5.22"; RepairLevel = $repairLevel })
    }
    $billingData30 = [pscustomobject]@{ Lot = "0000885"; Items = $billingItems30 }
    Assert-Equal "5.30" (Get-CB5BillingVersionFamily $billingData30) "Versões finais até 5.22 usam a família 5.30"
    Assert-Equal "CB5 - Lote 885 - 50 pçs (5.30) (43 MODEM 4G + 31 BLUETOOTH)" (Get-BillingSummary "CB5" $billingData30 $emptyAdditional) "O resumo CB5 mostra a família 5.30 antes das manutenções"

    $billingUnknown = [pscustomobject]@{ Lot = "0000885"; Items = @([pscustomobject]@{ FullVersion = "5.23"; RepairLevel = 2 }) }
    Assert-Throws { [void](Get-BillingSummary "CB5" $billingUnknown $emptyAdditional) } "A faixa 5.23 a 5.51 não recebe família inventada"
    $billingMixed = [pscustomobject]@{
        Lot = "0000885"
        Items = @(
            [pscustomobject]@{ FullVersion = "5.22"; RepairLevel = 1 },
            [pscustomobject]@{ FullVersion = "5.52"; RepairLevel = 1 }
        )
    }
    Assert-Throws { [void](Get-BillingSummary "CB5" $billingMixed $emptyAdditional) } "Um lote com famílias 5.30 e 5.40 misturadas é bloqueado"

    $tvBillingData = [pscustomobject]@{ Lot = "0000982"; Items = @([pscustomobject]@{}) }
    Assert-Equal "TV5 - Lote 982 - 1 pçs" (Get-BillingSummary "TV5" $tvBillingData $emptyAdditional) "O resumo TV5 permanece sem família de versão"

    $generatorSource = [IO.File]::ReadAllText($generatorPath)
    Assert-True ($generatorSource -match '\$script:AppVersion\s*=\s*"3\.4\.0"') "O Gerenciador informa a versão visual 3.4.0"
    Assert-True ($generatorSource -match '\$tabExtra\.Text\s*=\s*"Manutenções adicionais"') "A aba de adicionais possui um nome específico"
    Assert-True ($generatorSource -match '\$tabComponents\.Text\s*=\s*"Componentes a faturar"') "A aba de saldo deixa clara sua finalidade"
    Assert-True ($generatorSource -match '\$tabDescriptions\.Text\s*=\s*"Legenda de códigos"') "A aba somente de consulta é identificada como legenda"
    Assert-True ($generatorSource -match '\$tabs\.SizeMode\s*=\s*\[Windows\.Forms\.TabSizeMode\]::Normal') "As abas principais ajustam a largura ao próprio texto"
    Assert-True ($generatorSource -match 'Selecione uma planilha mestre \$selectedProduct' -and $generatorSource -match 'Adicione pelo menos duas planilhas mestre \$Product') "As áreas vazias orientam o próximo passo"
    Assert-True ($generatorSource -match 'LastInputDirectory') "A última pasta selecionada fica registrada nas preferências"
    Assert-True ($generatorSource -match 'componentOperationsGrid') "A interface possui histórico visível de uniões processadas"
    Assert-True ($generatorSource -match 'previewMasterButton' -and $generatorSource -match 'previewCombineButton') "A interface possui conferência sem gravação nas duas rotinas"
    Assert-True ($generatorSource -match 'componentBackupButton' -and $generatorSource -match 'componentRestoreButton') "A interface possui exportação e restauração da base"
    Assert-True ($generatorSource -match 'combineCopyQuantitiesButton' -and $generatorSource -match 'combinePasteQuantitiesButton') "A interface permite copiar quantidades entre lotes"
    Assert-True ($generatorSource -match '\$combineConsumeBalanceCheck\.Checked\s*=\s*\$true') "O consumo do saldo abre marcado por padrão"
    Assert-True ($generatorSource -match 'Get-BillingNoDeductionPlan') "Juntar lotes possui um caminho explícito sem consulta nem baixa do saldo"
    Assert-True ($generatorSource -match 'Sem consumo por escolha|registrada como sem consumo') "A escolha de não consumir fica explicada no resultado"
    Assert-True ($generatorSource -match 'function Set-GridColumnWidth') "O Gerenciador possui uma rotina única para controlar as larguras"
    Assert-Equal 0 ([regex]::Matches($generatorSource, 'AutoSizeColumnsMode\s*=\s*"Fill"').Count) "Nenhuma tabela do Gerenciador estica todas as colunas"
    Assert-True ($generatorSource -match 'Set-GridColumnWidth \$extraGrid "Description" 100 "Fill" 260') "Somente a descrição aproveita o espaço livre na lista de manutenções"
    Assert-True ($generatorSource -match '\$combineGrid\.Columns\[\$columnIndex\]\.Width\s*=\s*70') "As colunas de quantidade em Juntar lotes abrem compactas"
}
finally {
    if ([IO.Directory]::Exists($temporaryRoot)) { [IO.Directory]::Delete($temporaryRoot, $true) }
    Remove-Variable -Name BillingTestMockRange, BillingTestLastRow, BillingTestRangeStart, BillingTestRangeEnd, BillingTestMockSheet, BillingTestMockWorkbook -Scope Global -ErrorAction SilentlyContinue
}

Write-Host ""
Write-Host "Resultado: $($script:Passed) aprovado(s), $($script:Failed) falhou(aram)."
if ($script:Failed -gt 0) { exit 1 }
exit 0
