﻿Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$moduleRoot = Split-Path -Parent (Split-Path -Parent $PSCommandPath)
. ([IO.Path]::Combine($moduleRoot, "Componentes.Core.ps1"))

$script:Passed = 0
$script:Failed = 0

function Assert-True {
    param([bool]$Condition, [string]$Name)
    if ($Condition) {
        $script:Passed++
        Write-Host "[OK] $Name" -ForegroundColor Green
    }
    else {
        $script:Failed++
        Write-Host "[FALHOU] $Name" -ForegroundColor Red
    }
}

function Assert-Equal {
    param([AllowNull()][object]$Expected, [AllowNull()][object]$Actual, [string]$Name)
    Assert-True -Condition ($Expected -eq $Actual) -Name "$Name (esperado: $Expected | atual: $Actual)"
}

function Assert-Throws {
    param([scriptblock]$Action, [string]$Name)
    $threw = $false
    try { & $Action }
    catch { $threw = $true }
    Assert-True $threw $Name
}

$temporaryRoot = [IO.Path]::Combine([IO.Path]::GetTempPath(), "Gerador-Componentes-Test-" + [Guid]::NewGuid().ToString("N"))
try {
    [void][IO.Directory]::CreateDirectory($temporaryRoot)

    foreach ($scriptFile in @(
        ([IO.Path]::Combine($moduleRoot, "Componentes.Core.ps1")),
        ([IO.Path]::Combine($moduleRoot, "Gerador Planilhas.ps1"))
    )) {
        $tokens = $null
        $parseErrors = $null
        [void][Management.Automation.Language.Parser]::ParseFile($scriptFile, [ref]$tokens, [ref]$parseErrors)
        Assert-Equal 0 $parseErrors.Count "Sintaxe válida: $([IO.Path]::GetFileName($scriptFile))"
    }

    $store = New-BillingComponentStore
    Assert-Equal 18 (@($store.Componentes).Count) "A base inicial contém os 18 componentes informados"
    Assert-Equal 8 (@(Get-BillingComponents $store "CB5").Count) "A base inicial contém 8 componentes CB5"
    Assert-Equal 10 (@(Get-BillingComponents $store "TV5").Count) "A base inicial contém 10 componentes TV5"
    Assert-Equal 10 (Get-BillingComponentById $store "cb5-cn3").Saldo "Saldo inicial CB5 CN3"
    Assert-Equal 50 (Get-BillingComponentById $store "tv5-cn8").Saldo "Saldo inicial TV5 CN8"
    Assert-Equal 13 (@($store.Movimentos | Where-Object Tipo -eq "Saldo inicial").Count) "Saldos importados ficam explicados no histórico"
    Assert-Equal "RESISTOR" (Get-BillingComponentById $store "tv5-r25").Nome "R25 foi corrigido para RESISTOR"
    Assert-Equal "NOME NÃO INFORMADO" (Get-BillingComponentById $store "cb5-u40").Nome "U40 permanece sem nome inventado"

    $u4Search = @(Get-BillingComponents $store "CB5" -IncludeInactive | Where-Object { Test-BillingComponentMatchesSearch $_ "U4" })
    Assert-Equal 1 $u4Search.Count "A pesquisa por U4 não confunde U4 com U40"
    Assert-Equal "cb5-u4" $u4Search[0].Id "A pesquisa exata retorna o componente correto"
    Assert-True (Test-BillingComponentMatchesSearch (Get-BillingComponentById $store "cb5-u4") "mem") "A pesquisa aceita o início de um nome conhecido"
    Assert-True (Test-BillingComponentMatchesSearch (Get-BillingComponentById $store "cb5-cn4") "con usb") "A pesquisa aceita mais de uma palavra"
    Assert-True (-not (Test-BillingComponentMatchesSearch (Get-BillingComponentById $store "cb5-cn4") "processador")) "A pesquisa não retorna componente sem relação"

    $initialDashboard = Get-BillingDashboardSummary $store "CB5"
    Assert-Equal 8 $initialDashboard.Ativos "O painel informa os componentes ativos do produto"
    Assert-Equal 139 $initialDashboard.UnidadesPendentes "O painel soma as unidades pendentes do CB5"
    Assert-Equal 0 $initialDashboard.UnioesProcessadas "O painel começa sem união processada"

    $cb5U4 = Get-BillingComponentById $store "cb5-u4"
    Assert-True (Test-BillingComponentInRepair $cb5U4 "ASTEC CB5, TROCADO U4") "U4 é reconhecido como componente exato"
    Assert-True (-not (Test-BillingComponentInRepair $cb5U4 "ASTEC CB5, TROCADO U40")) "U4 não é confundido com U40"
    Assert-True (Test-BillingComponentInRepair $cb5U4 "ASTEC CB5, TROCADO MEMORIA FLASH") "Acentos não impedem o reconhecimento"
    Assert-Equal "TPRC" (Get-BillingComponentForRepairPart $store "TV5" "TROCADO U4").CodigoPlanilha "Designador exato U4 resolve o código do processador TV5"
    Assert-Equal "TCI" (Get-BillingComponentForRepairPart $store "TV5" "U15").CodigoPlanilha "Designador exato U15 resolve o código da fonte TV5"
    Assert-Equal "TR" (Get-BillingComponentForRepairPart $store "TV5" "R25").CodigoPlanilha "Designador exato R25 resolve o código de resistor"
    Assert-Equal "TRCTL" (Get-BillingComponentForRepairPart $store "TV5" "TROCADO X").CodigoPlanilha "Indicação genérica X usa o componente X2 cadastrado"

    $key1 = Get-BillingOperationKey -Product "CB5" -Invoice "5.225" -Lots @("0826983", "0826982")
    $key2 = Get-BillingOperationKey -Product "CB5" -Invoice "5225" -Lots @("0826982", "0826983")
    Assert-Equal $key1 $key2 "A chave da união é estável com NF formatada e lotes em outra ordem"
    $key3 = Get-BillingOperationKey -Product "CB5" -Invoice "9999" -Lots @("0826982", "0826983")
    Assert-Equal $key1 $key3 "Trocar a NF não permite baixar novamente os mesmos lotes"

    $items = @(
        [pscustomobject]@{ Repair = "ASTEC CB5, TROCADO CONECTOR USB" },
        [pscustomobject]@{ Repair = "ASTEC CB5, TROCADO CONECTOR USB, RS232" },
        [pscustomobject]@{ Repair = "ASTEC CB5, TROCADO U40" }
    )
    $plan = Get-BillingDeductionPlan -Store $store -Product "CB5" -Items $items -OperationKey $key1
    Assert-True $plan.Valido "Plano com saldo suficiente é válido"
    Assert-Equal 3 (@($plan.Linhas).Count) "Plano identifica os três componentes usados"
    Assert-Equal 2 (@($plan.Linhas | Where-Object Componente -eq "CN4"))[0].Quantidade "Dois conectores USB são contabilizados"
    Assert-Equal 1 (@($plan.Linhas | Where-Object Componente -eq "U40"))[0].Quantidade "U40 é contabilizado separadamente"

    $duplicateTextItems = @([pscustomobject]@{ Repair = "ASTEC CB5, TROCADO CONECTOR USB, CONECTOR USB" })
    $duplicateTextKey = Get-BillingOperationKey -Product "CB5" -Invoice "10" -Lots @("D1", "D2")
    $duplicateTextPlan = Get-BillingDeductionPlan -Store $store -Product "CB5" -Items $duplicateTextItems -OperationKey $duplicateTextKey
    Assert-Equal 1 (@($duplicateTextPlan.Linhas | Where-Object Componente -eq "CN4"))[0].Quantidade "O mesmo componente escrito duas vezes conta uma vez por peça"

    $applied = Apply-BillingDeductionPlan -Store $store -Plan $plan -OperationKey $key1 -Invoice "5.225" -Lots @("0826982", "0826983")
    Assert-Equal 38 (Get-BillingComponentById $applied "cb5-cn4").Saldo "Baixa automática reduz o saldo exato"
    Assert-Equal 2 (Get-BillingComponentById $applied "cb5-u40").Saldo "Baixa automática reduz U40 uma vez"
    Assert-Equal 3 (@($applied.Movimentos | Where-Object Tipo -eq "Baixa automática").Count) "Histórico registra uma linha por componente"
    Assert-Equal 1 (@($applied.Operacoes).Count) "A união concluída possui um registro independente"
    $appliedDashboard = Get-BillingDashboardSummary $applied "CB5"
    Assert-Equal 135 $appliedDashboard.UnidadesPendentes "O painel reflete a baixa concluída"
    Assert-Equal 1 $appliedDashboard.UnioesProcessadas "O painel reflete a união concluída"
    $operationRows = @(Get-BillingOperationRows $applied "CB5" 10)
    Assert-Equal 1 $operationRows.Count "A consulta de uniões retorna a operação do produto"
    Assert-True ((Get-BillingOperationDetailText $operationRows[0]) -match "CN4: -2") "O histórico de uniões resume as baixas por componente"

    $repeatPlan = Get-BillingDeductionPlan -Store $applied -Product "CB5" -Items $items -OperationKey $key1
    Assert-True $repeatPlan.JaAplicada "A mesma união é reconhecida como já baixada"
    [void](Apply-BillingDeductionPlan -Store $applied -Plan $repeatPlan -OperationKey $key1 -Invoice "5.225" -Lots @("0826982", "0826983"))
    Assert-Equal 38 (Get-BillingComponentById $applied "cb5-cn4").Saldo "Repetir a união não baixa novamente"
    Assert-Equal 1 (@($applied.Operacoes).Count) "Repetir a união não duplica o registro da operação"

    $skipStore = New-BillingComponentStore
    $skipKey = Get-BillingOperationKey -Product "CB5" -Invoice "700" -Lots @("SEM1", "SEM2")
    $skipPlan = Get-BillingNoDeductionPlan -Store $skipStore -Product "CB5" -OperationKey $skipKey
    Assert-True $skipPlan.Valido "Plano sem consumo é sempre válido sem consultar o saldo"
    Assert-True (-not $skipPlan.ConsumirSaldo) "Plano desmarcado identifica que o saldo não deve ser consumido"
    $skipBalanceBefore = (Get-BillingComponentById $skipStore "cb5-cn4").Saldo
    [void](Apply-BillingDeductionPlan -Store $skipStore -Plan $skipPlan -OperationKey $skipKey -Invoice "700" -Lots @("SEM1", "SEM2"))
    Assert-Equal $skipBalanceBefore (Get-BillingComponentById $skipStore "cb5-cn4").Saldo "União sem consumo mantém o saldo intacto"
    Assert-Equal 0 (@($skipStore.Movimentos | Where-Object Tipo -eq "Baixa automática").Count) "União sem consumo não cria movimento de baixa"
    Assert-Equal 1 (@($skipStore.Operacoes).Count) "União sem consumo ainda é registrada contra repetição"
    Assert-True (-not (ConvertTo-BillingBoolean $skipStore.Operacoes[0].ConsumirSaldo)) "Histórico preserva a escolha de não consumir"
    Assert-Equal "Sem consumo por escolha" (Get-BillingOperationDetailText $skipStore.Operacoes[0]) "Histórico explica a união sem consumo"
    $guardStore = New-BillingComponentStore
    $guardKey = Get-BillingOperationKey -Product "CB5" -Invoice "701" -Lots @("GUARD1", "GUARD2")
    $guardPlan = [pscustomobject]@{ Produto = "CB5"; Valido = $true; JaAplicada = $false; ConsumirSaldo = $false; Linhas = @($plan.Linhas); Erros = @() }
    [void](Apply-BillingDeductionPlan -Store $guardStore -Plan $guardPlan -OperationKey $guardKey -Invoice "701" -Lots @("GUARD1", "GUARD2"))
    Assert-Equal 40 (Get-BillingComponentById $guardStore "cb5-cn4").Saldo "A marca sem consumo prevalece mesmo se um plano inválido trouxer linhas"
    Assert-Equal 0 $guardStore.Operacoes[0].QuantidadeTotal "Operação sem consumo nunca registra baixas escondidas"
    $lateDeductionPlan = Get-BillingDeductionPlan -Store $skipStore -Product "CB5" -Items $items -OperationKey $skipKey
    Assert-True $lateDeductionPlan.JaAplicada "A mesma união não vira uma baixa posterior acidental"
    [void](Apply-BillingDeductionPlan -Store $skipStore -Plan $lateDeductionPlan -OperationKey $skipKey -Invoice "700" -Lots @("SEM1", "SEM2"))
    Assert-Equal $skipBalanceBefore (Get-BillingComponentById $skipStore "cb5-cn4").Saldo "Tentativa posterior continua sem alterar o saldo"

    $emptyStore = New-BillingComponentStore
    foreach ($component in @($emptyStore.Componentes)) { $component.Ativo = $false }
    $emptyKey = Get-BillingOperationKey -Product "TV5" -Invoice "100" -Lots @("L1", "L2")
    $emptyPlan = Get-BillingDeductionPlan -Store $emptyStore -Product "TV5" -Items @([pscustomobject]@{ Repair = "ASTEC TV5" }) -OperationKey $emptyKey
    Assert-Equal 0 (@($emptyPlan.Linhas).Count) "Uma união sem componente reconhecido produz plano vazio"
    [void](Apply-BillingDeductionPlan -Store $emptyStore -Plan $emptyPlan -OperationKey $emptyKey -Invoice "100" -Lots @("L1", "L2"))
    Assert-True (Test-BillingOperationApplied $emptyStore $emptyKey) "Mesmo uma união sem baixa é marcada contra repetição futura"

    $lowStore = New-BillingComponentStore
    (Get-BillingComponentById $lowStore "tv5-x2").Saldo = 1
    $lowItems = @(
        [pscustomobject]@{ Repair = "ASTEC TV5, TROCADO X2" },
        [pscustomobject]@{ Repair = "ASTEC TV5, TROCADO X2" }
    )
    $lowKey = Get-BillingOperationKey -Product "TV5" -Invoice "900" -Lots @("1", "2")
    $lowPlan = Get-BillingDeductionPlan -Store $lowStore -Product "TV5" -Items $lowItems -OperationKey $lowKey
    Assert-True (-not $lowPlan.Valido) "Saldo insuficiente bloqueia o plano"
    Assert-True (@($lowPlan.Erros).Count -eq 1 -and $lowPlan.Erros[0] -match "X2") "O erro informa o componente sem saldo"

    $manualStore = New-BillingComponentStore
    [void](Add-BillingManualQuantity -Store $manualStore -Id "tv5-r25" -Quantity 7 -Observation "Usados antes do faturamento")
    Assert-Equal 7 (Get-BillingComponentById $manualStore "tv5-r25").Saldo "Lançamento manual soma ao saldo a faturar"
    [void](Set-BillingManualBalance -Store $manualStore -Id "tv5-r25" -NewBalance 5 -Observation "Conferência")
    Assert-Equal 5 (Get-BillingComponentById $manualStore "tv5-r25").Saldo "Ajuste manual define o saldo exato"
    Assert-Equal 2 (@($manualStore.Movimentos | Where-Object { $_.Tipo -in @("Lançamento manual", "Ajuste manual") }).Count) "Lançamento e ajuste ficam no histórico"

    $newComponent = Add-BillingComponent -Store $manualStore -Product "TV5" -Component "D99" -Name "DIODO ESPECIAL" -InitialBalance 3 -OutputCode "TRD" -RepairText "D99" -Aliases @("DIODO ESPECIAL")
    Assert-Equal 3 $newComponent.Saldo "Novo componente aceita saldo inicial"
    Assert-True (Test-BillingComponentInRepair $newComponent "ASTEC TV5, TROCADO D99") "Novo componente pode ser reconhecido na mestre"
    Assert-Throws { [void](Add-BillingComponent -Store $manualStore -Product "TV5" -Component "D99" -Name "DUPLICADO") } "Componente duplicado no mesmo produto é rejeitado"
    [void](Update-BillingComponent -Store $manualStore -Id ([string]$newComponent.Id) -Name "DIODO ESPECIAL" -OutputCode "TRD" -RepairText "D99" -Aliases @("DIODO ESPECIAL") -Active $false)
    Assert-True ($null -eq (Get-BillingComponents $manualStore "TV5" | Where-Object Id -eq $newComponent.Id | Select-Object -First 1)) "Componente inativo deixa de participar do reconhecimento"
    Assert-True ($null -ne (Get-BillingComponents $manualStore "TV5" -IncludeInactive | Where-Object Id -eq $newComponent.Id | Select-Object -First 1)) "Componente inativo permanece preservado no cadastro"
    [void](Add-BillingComponent -Store $manualStore -Product "TV5" -Component "R99" -Name "RESISTOR" -OutputCode "TR" -RepairText "R99" -Aliases @("RESISTOR"))
    Assert-Throws { [void](Get-BillingComponentForRepairPart $manualStore "TV5" "RESISTOR") } "Nome genérico ambíguo é bloqueado em vez de escolher um componente"

    $dataPath = Initialize-BillingComponentStore -DataDirectory $temporaryRoot
    Write-BillingComponentStore -Store $manualStore -Path $dataPath
    $reloaded = Read-BillingComponentStore -Path $dataPath
    Assert-Equal 20 (@($reloaded.Componentes).Count) "Cadastro persiste após salvar e recarregar"
    Assert-Equal 5 (Get-BillingComponentById $reloaded "tv5-r25").Saldo "Saldo persiste após salvar e recarregar"
    Assert-Equal 16 (@($reloaded.Movimentos).Count) "Histórico inicial e manual persiste após salvar e recarregar"

    $operationBackupPath = [IO.Path]::Combine($temporaryRoot, "backup-com-operacao.json")
    Write-BillingComponentStore -Store $applied -Path $operationBackupPath
    $operationBackup = Read-BillingComponentStore -Path $operationBackupPath
    Assert-Equal 1 (@($operationBackup.Operacoes).Count) "Backup e restauração preservam as uniões processadas"
    Assert-Equal 135 (Get-BillingDashboardSummary $operationBackup "CB5").UnidadesPendentes "Backup e restauração preservam os saldos"

    $legacyOperationStore = New-BillingComponentStore
    $legacyOperationStore.SchemaVersion = 2
    $legacyOperationStore.Operacoes = @([pscustomobject]@{
        Id = "antiga"; Em = "2026-01-01T10:00:00"; Produto = "CB5"; ChaveOperacao = "chave"
        NF = "1"; Lotes = @("1", "2"); Baixas = @(); QuantidadeTotal = 0
    })
    $normalizedOperationStore = Normalize-BillingComponentStore $legacyOperationStore
    Assert-Equal 3 $normalizedOperationStore.SchemaVersion "Base de componentes anterior migra para o esquema 3"
    Assert-True (ConvertTo-BillingBoolean $normalizedOperationStore.Operacoes[0].ConsumirSaldo) "União antiga mantém compatibilidade como consumo habilitado"
}
finally {
    if ([IO.Directory]::Exists($temporaryRoot)) {
        [IO.Directory]::Delete($temporaryRoot, $true)
    }
}

Write-Host ""
Write-Host "Resultado: $($script:Passed) aprovado(s), $($script:Failed) falhou(aram)."
if ($script:Failed -gt 0) { exit 1 }
exit 0
