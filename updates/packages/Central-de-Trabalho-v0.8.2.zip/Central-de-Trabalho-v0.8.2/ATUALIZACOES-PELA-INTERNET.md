﻿# Atualizações pela internet

A Central de Trabalho v0.8.2 ativa os endereços permanentes dos canais de
atualização. O mecanismo continua usando somente HTTPS, validação de identidade,
tamanho, SHA-256, manifesto interno do pacote, backup e restauração.

## Hospedagem oficial deste projeto

Os arquivos de atualização ficam em um repositório público separado da Central
Histórica do GP-H:

- projeto: `clienteg1603/Central-de-Trabalho-CB5`
- canal Estável: `https://raw.githubusercontent.com/clienteg1603/Central-de-Trabalho-CB5/main/updates/stable.json`
- canal Teste: `https://raw.githubusercontent.com/clienteg1603/Central-de-Trabalho-CB5/main/updates/test.json`

A separação é intencional para não misturar a Central de Trabalho/CB5 com o
projeto GP-H. Nenhuma senha ou token do GitHub é armazenado no programa. O
Atualizador só faz leitura dos arquivos públicos por HTTPS.

## Primeira ativação a partir da v0.8.1

A v0.8.1 foi distribuída com os canais vazios. Para o primeiro teste real, basta
configurar uma única vez o endereço do canal **Teste** com o endereço acima e
procurar atualização. A v0.8.2 já traz Estável e Teste configurados no próprio
`Atualizador/CANAIS.json`, portanto as versões seguintes não exigirão colar o
endereço novamente.

Uma preferência manual salva em `%LOCALAPPDATA%\CentralDeTrabalhoUpdater` tem
prioridade sobre o endereço empacotado. Isso permite trocar temporariamente um
canal sem editar arquivos do programa.

## Fluxo de atualização

1. O usuário escolhe o canal Estável ou Teste.
2. O programa baixa somente o manifesto daquele canal por HTTPS.
3. A tela mostra a versão e as novidades antes de qualquer instalação.
4. Depois da confirmação, o pacote é baixado para uma pasta temporária.
5. Tamanho, SHA-256, identidade, versão e lista interna de arquivos são
   conferidos.
6. Gerenciador e Manutenção precisam estar fechados.
7. A Central é fechada somente depois que o pacote já passou na validação.
8. É criado um backup completo do programa e das bases locais.
9. Os arquivos são substituídos e conferidos novamente.
10. A Central é reaberta. Se a instalação falhar, o backup é restaurado.

## Proteção dos dados

Antes da troca, o atualizador guarda uma cópia de:

- `%LOCALAPPDATA%\CentralDeTrabalho`;
- `%LOCALAPPDATA%\GeradorPlanilhasCB5TV5`;
- pasta completa da versão instalada.

Os backups ficam em `%LOCALAPPDATA%\CentralDeTrabalhoUpdater\Backups` e são
mantidos os cinco mais recentes.

Ao restaurar manualmente, a opção de voltar também os dados locais começa
desmarcada. Assim, uma volta de versão não apaga por padrão manutenções ou
movimentações criadas depois da atualização.

## Formato do manifesto remoto

```json
{
  "SchemaVersion": 1,
  "AppId": "central-de-trabalho",
  "Channel": "test",
  "Version": "0.8.2",
  "MinimumUpdaterVersion": "1.0.0",
  "PackageUrl": "https://raw.githubusercontent.com/clienteg1603/Central-de-Trabalho-CB5/main/updates/packages/Central-de-Trabalho-v0.8.2.zip",
  "PackageSha256": "SHA256_COM_64_CARACTERES",
  "PackageSize": 123456,
  "PackageRoot": "Central-de-Trabalho-v0.8.2",
  "ReleaseNotes": [
    "Teste real do fluxo de atualização pela internet.",
    "Canais Estável e Teste passam a vir configurados no pacote."
  ]
}
```

O ZIP contém `PACOTE-MANIFESTO.json`, que lista cada arquivo administrado, seu
tamanho e SHA-256. Arquivos extras, ausentes ou adulterados bloqueiam a
instalação.

## Política de publicação

Novas versões entram primeiro no canal **Teste**. Depois de confirmar download,
backup, instalação, reabertura e restauração no Windows real, o mesmo pacote
pode ser promovido para **Estável** apenas alterando `updates/stable.json`.

A verificação automática ao iniciar continua desativada nesta etapa. Ela só será
habilitada depois que o ciclo real v0.8.1 → v0.8.2 → restauração estiver
validado.
