﻿# Central de Trabalho v0.8.2

Data: 09/09/2026

## Objetivo desta versão

Esta é uma versão de validação controlada do **fluxo real de atualização pela internet**. Não altera as regras operacionais do Gerenciador de Planilhas nem da Central de Manutenção.

## Atualizador

- Canais **Estável** e **Teste** passam a trazer endereços permanentes no `Atualizador/CANAIS.json`.
- A hospedagem fica em repositório próprio da Central de Trabalho/CB5, separado do GP-H.
- Nenhum token, senha ou credencial do GitHub fica no programa.
- A política passa a ser: publicar primeiro em **Teste** e promover o mesmo pacote para **Estável** somente depois da validação no Windows real.
- O primeiro ciclo previsto é v0.8.1 → v0.8.2 pelo canal Teste, seguido de teste de **RESTAURAR ANTERIOR**.

## Preservado

- Correção de layout/DPI da janela Atualizações introduzida na v0.8.1.
- SHA-256 do ZIP e de todos os arquivos administrados.
- Proteção contra pacote adulterado, ZIP inseguro e caminhos fora da instalação.
- Backup completo antes da troca e restauração automática em caso de falha.
- Dados locais continuam fora da pasta do programa.
- Central e Atualizador continuam abrindo sem console.
- Gerenciador permanece v3.4.0.
- Central de Manutenção permanece v0.5.0.

## Próxima decisão

A verificação automática na abertura da Central permanece desativada. Só será considerada depois que atualização, backup, reabertura e restauração forem aprovados no computador real.
