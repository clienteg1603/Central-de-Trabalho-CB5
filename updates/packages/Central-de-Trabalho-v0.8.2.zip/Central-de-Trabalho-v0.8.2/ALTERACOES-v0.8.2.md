﻿# Central de Trabalho v0.8.2

Data: 09/09/2026

## Objetivo

Validação controlada do primeiro fluxo real de atualização pela internet, sem alterar as regras do Gerenciador ou da Central de Manutenção.

## Atualizador

- Canais Estável e Teste passam a trazer endereços permanentes no `CANAIS.json`.
- Corrigida a falha de interpolação na confirmação da instalação (`$targetVersion?` -> `${targetVersion}?`) encontrada no primeiro teste real no Windows.
- Incluídas duas verificações de regressão específicas para essa falha.
- Mantidos SHA-256, validação do pacote, backup completo, restauração automática e preservação dos dados locais.
- Central e Atualizador continuam sem console visível.

## Módulos preservados

- Gerenciador: 3.4.0.
- Central de Manutenção: 0.5.0.
