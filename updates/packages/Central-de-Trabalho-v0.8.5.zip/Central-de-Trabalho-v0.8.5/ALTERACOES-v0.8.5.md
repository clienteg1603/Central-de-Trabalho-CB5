﻿# Central de Trabalho v0.8.5

Data: 09/09/2026

## Consolidação aprovada em teste real no Windows

- `Central de Trabalho.exe` substituído pelo novo launcher nativo 64 bits que abriu corretamente por duplo clique no computador real.
- O launcher usa caminhos absolutos, chama o VBS interno confiável e mantém fallback direto para PowerShell.
- Sem janela preta de console no uso normal.
- Reabertura automática da Central após atualizar e após restaurar mantida.
- Atualizador mantém até 3 tentativas automáticas em falhas temporárias como HTTP 408, 429, 500, 502, 503 e 504.
- `CONFIGURAR ENDEREÇO` mostra o endereço efetivamente usado e a configuração permanece persistente.
- Backup, restauração, manifesto, validação de tamanho e SHA-256 preservados.
- Nenhuma regra funcional do Gerenciador de Planilhas ou da Central de Manutenção foi alterada.

## Módulos preservados

- Gerenciador: 3.4.0.
- Central de Manutenção: 0.5.0.
