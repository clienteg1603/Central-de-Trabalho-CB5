﻿# Central de Trabalho v0.8.5

## Estrutura

```text
Central-de-Trabalho-v0.8.5/
├── Central de Trabalho.exe
├── Central de Trabalho.ps1
├── ABRIR CENTRAL DE TRABALHO.vbs
├── DIAGNOSTICO - abrir com console.bat
├── PACOTE-MANIFESTO.json
├── LEIA-ME.txt
├── ALTERACOES-v0.8.5.md
├── VALIDACAO-v0.8.5.txt
├── ATUALIZACOES-PELA-INTERNET.md
├── PADRAO-VISUAL.md
├── ARQUITETURA.md
├── Atualizador/
│   ├── Central de Trabalho Updater.exe
│   ├── Central de Trabalho Updater.ps1
│   ├── Update.Core.ps1
│   ├── CANAIS.json
│   └── Testes/
└── Modulos/
    ├── Gerador-de-Planilhas-CB5-TV5/
    │   ├── Gerador Planilhas.ps1
    │   ├── Componentes.Core.ps1
    │   └── Testes/
    └── Central-de-Manutencao-CB5/
        ├── Central Manutencao CB5.ps1
        ├── Manutencao.Core.ps1
        └── Testes/
```

## Inicialização

`Central de Trabalho.exe` é um pequeno iniciador nativo PE32+ x64 com subsistema
gráfico. Ele localiza sua própria pasta e chama diretamente o Windows PowerShell
5.1 do sistema com `Central de Trabalho.ps1`, em modo STA e com a janela de
console oculta.

O EXE não incorpora os scripts. Essa separação mantém os módulos legíveis,
testáveis e substituíveis pelo Atualizador. O VBS continua como alternativa; o
BAT de diagnóstico é o único iniciador que exibe o console.

A Central abre Gerenciador, Manutenção e Atualizador em processos separados.
Cada módulo usa um mutex próprio para impedir duas instâncias concorrentes.

## Versões internas

- Central mestre: 0.8.5
- Gerenciador de Planilhas: 3.4.0
- Núcleo de componentes a faturar: 1.3.0, esquema 3
- Central de Manutenção CB5: 0.5.0
- Núcleo de manutenção: 0.4.0, esquema 4
- Atualizador: 1.0.0, esquema remoto 1

## Atualização

`Central de Trabalho Updater.ps1` contém a interface. `Update.Core.ps1`
concentra versões, canais, rede, validação, extração segura, backup, instalação,
restauração e travas.

O manifesto remoto informa versão, canal, URL, tamanho e SHA-256 do ZIP. Dentro
do ZIP, `PACOTE-MANIFESTO.json` lista cada arquivo administrado com tamanho e
SHA-256. O pacote é rejeitado se estiver incompleto, adulterado, tiver arquivos
extras ou tentar extrair conteúdo fora da pasta temporária.

Depois do download, a Central é fechada e o Atualizador adquire os mutexes dos
três aplicativos. A instalação cria um snapshot do programa e das bases locais,
copia o novo conteúdo e valida novamente. Qualquer exceção dispara a restauração
do snapshot anterior.

Arquivos locais não administrados pelo manifesto são preservados. Arquivos de
uma versão antiga que estavam no manifesto e deixaram de existir na nova versão
são removidos.

## Gerenciador de Planilhas

`Gerador Planilhas.ps1` contém interface, automação do Excel, leitura das mestres
e geração. `Componentes.Core.ps1` concentra catálogo, saldos, movimentos,
reconhecimento de reparos, planos de baixa e idempotência.

Na união existem planos distintos com e sem consumo. Os dois usam a chave de
produto e conjunto de lotes, impedindo que repetir a operação gere baixa dupla.

## Central de Manutenção

`Central Manutencao CB5.ps1` contém interface e navegação.
`Manutencao.Core.ps1` concentra validação, persistência, histórico, retornos,
correções, estatísticas, diagnóstico e esquemáticos.

Novos registros usam situação automática: `Em aberto`, `Aprovado` ou `PT`.
Correções preservam série, número da passagem e datas de identidade, criando um
evento com os valores anteriores e novos.

## Persistência

Os dados ficam fora da pasta instalada:

- manutenção: `%LOCALAPPDATA%\CentralDeTrabalho\ManutencaoCB5`;
- componentes: `%LOCALAPPDATA%\GeradorPlanilhasCB5TV5`;
- atualizador: `%LOCALAPPDATA%\CentralDeTrabalhoUpdater`.

Os JSONs usam gravação temporária e substituição controlada. O Atualizador
mantém no máximo cinco snapshots. A restauração manual não volta os dados sem
uma escolha explícita do usuário.

## Tabelas e escala

Dados curtos usam largura fixa: série, código, NF, data, quantidade, passagem e
página. Somente colunas descritivas usam preenchimento do espaço restante. As
janelas calculam o tamanho inicial pela área útil do monitor, aceitam
maximização e mantêm rolagem interna quando necessário.

## Limites intencionais

- uso local em um computador por vez;
- sem cadastro de usuários ou permissões;
- sem integração automática com CQR, e-mail ou setor seguinte;
- sem reprodução dos postos do CQR;
- sem esquemáticos incluídos no pacote;
- sem certificado comercial de assinatura digital nesta versão;
- sem canal permanente publicado até a escolha da hospedagem HTTPS;
- distribuição de reparos na planilha é faturamento, não prova da manutenção
  real daquela série.

O programa permanece compatível com Windows PowerShell 5.1 e só exige Microsoft
Excel para o Gerenciador de Planilhas.
