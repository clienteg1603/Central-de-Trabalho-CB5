﻿# Padrão visual da Central de Trabalho

Versão de referência: Central de Trabalho v0.8.5

Este documento registra o desenho aprovado para manter a Central, o
Gerenciador e a Manutenção coerentes nas próximas versões. Ele descreve a
interface; as regras operacionais continuam documentadas nos respectivos
arquivos `REGRAS-CONFIRMADAS.md`.

## Princípios

1. Mostrar primeiro o que o usuário precisa fazer agora.
2. Usar os mesmos termos em botões, cartões, filtros e resultados.
3. Evitar campos e controles que pertencem ao CQR.
4. Reservar espaço amplo somente para textos que realmente podem ser longos.
5. Explicar uma tela vazia com uma frase curta e uma próxima ação.
6. Nunca depender apenas de cor para comunicar sucesso, atenção ou erro.
7. Manter o fluxo utilizável em Windows 10 e 11, com escala de tela diferente.

## Identidade dos três níveis

### Central de Trabalho

A Central é um portal. Deve ter pouco texto, dois cartões de módulo e uma ação
clara em cada cartão. Não deve repetir formulários nem dados internos dos
módulos.

### Gerenciador de Planilhas

O Gerenciador é operacional e orientado por etapas. As abas usam nomes de ação
ou de conteúdo:

1. Gerar planilhas
2. Manutenções adicionais
3. Componentes a faturar
4. Juntar lotes
5. Legenda de códigos

### Central de Manutenção

A Manutenção é técnica e orientada pela série. Na tela principal, o formulário
fica à esquerda e o histórico automático da série fica à direita. Estatísticas,
diagnóstico e esquemáticos permanecem em suas próprias abas.

## Cores semânticas

| Uso | Cor | Significado |
|---|---|---|
| Seleção e ação principal | Azul | ação disponível ou área selecionada |
| Identidade da Manutenção | Petróleo | contexto técnico da Manutenção |
| Sucesso | Verde | aprovado ou operação concluída |
| Atenção | Laranja | retorno, aviso ou conferência necessária |
| Erro | Vermelho | falha, bloqueio ou PT |
| Neutro | Cinza | informação, ação secundária ou ausência de dados |

Todo uso de cor deve vir acompanhado de texto. Ícones podem reforçar uma
mensagem, mas não substituem o rótulo. O tema Alto contraste tem prioridade
sobre a identidade de cor de cada módulo.

## Botões e hierarquia

- Deve existir no máximo uma ação principal evidente por estado da tela.
- Ação principal: fundo destacado e texto curto no infinitivo.
- Ação secundária: contorno ou fundo neutro.
- Ação perigosa ou irreversível: vermelho e confirmação explícita.
- Ações indisponíveis ficam desativadas; não devem parecer clicáveis.
- No formulário de manutenção, `CONCLUIR PASSAGEM` é a ação principal.
- Durante uma correção, `SALVAR CORREÇÃO` passa a ser a ação principal.
- No Gerenciador, conferir deve aparecer antes de gravar ou substituir.

## Campos e formulários

- O rótulo fica próximo ao campo e usa o mesmo vocabulário do histórico.
- Código vem antes da série na Manutenção.
- Série aceita somente números e é validada com exatamente oito dígitos ao
  salvar.
- Campos de texto longo podem crescer; códigos, datas, versões e quantidades
  devem permanecer compactos.
- Valores lembrados entre peças precisam representar trabalho por lote, como o
  código selecionado. Dados próprios da peça devem ser limpos.
- Mensagens de validação devem dizer o problema e como corrigir.

## Tabelas e largura de colunas

- Série, código, NF, data, versão, passagem, quantidade e página usam largura
  fixa e curta.
- Situação e resultado usam apenas o espaço necessário para os valores reais.
- Uma coluna descritiva por tabela pode preencher o espaço restante.
- Quando houver mais de uma descrição longa, usar rolagem horizontal em vez de
  deixar todas as colunas excessivamente largas.
- O redimensionamento manual continua permitido, mas a abertura inicial deve
  estar pronta para uso sem ajuste.
- Novas tabelas precisam ser testadas com conteúdo vazio, curto e longo.

## Estados vazios, avisos e resultados

Uma área sem dados deve responder a duas perguntas:

1. Por que ainda não há conteúdo?
2. Qual ação cria ou carrega esse conteúdo?

Exemplos aprovados:

- `Selecione uma planilha mestre CB5 para conferir, atualizar ou gerar os arquivos.`
- `Adicione pelo menos duas planilhas mestre CB5 para conferir ou juntar os lotes.`
- `Série nova — nenhuma passagem anterior.`
- `Digite os 8 números da série para consultar o histórico automaticamente.`

Resultados de execução devem informar produto, lote, quantidade e consequência
da ação. Em CB5, o resumo de geração e união mantém a família `(5.30)` ou
`(5.40)` quando aplicável.

## Histórico automático da série

- A consulta começa somente depois de oito dígitos válidos.
- A passagem mais recente aparece primeiro.
- A lista mostra número, data, resultado e defeito sem substituir o Histórico
  completo.
- `VER DETALHES` abre o item selecionado.
- `ABRIR HISTÓRICO` navega para a consulta completa já filtrada pela série.
- A lista é somente leitura e não salva nem corrige registros.
- Hipóteses de diagnóstico não aparecem nesse painel; ficam na aba própria.

## Navegação por abas

- Abas usam apenas a largura necessária para o texto.
- A aba ativa precisa ter contraste visível em todos os temas.
- A ordem acompanha a frequência e o fluxo do trabalho.
- Uma função não deve aparecer duplicada em várias abas sem necessidade.
- Trocar de aba não pode apagar preenchimento sem confirmação.

## Janelas, escala e redimensionamento

- O tamanho inicial é calculado pela área útil do monitor.
- A janela deve poder maximizar.
- Conteúdo interno deve usar ancoragem, preenchimento e rolagem quando a escala
  do Windows reduzir o espaço disponível.
- Nenhum botão essencial pode depender de uma resolução específica.
- Antes de uma entrega final, conferir visualmente em Windows a escala, o foco,
  as larguras e os textos cortados.

## O que evitar

- colunas abertas com grandes áreas vazias;
- frases longas dentro de botões;
- várias ações com o mesmo destaque;
- cor usada sem texto explicativo;
- animações, efeitos ou ícones decorativos que não ajudam na tarefa;
- controles de Teste, Ping, posto do CQR, Garantia ou status manual na rotina da
  Manutenção;
- usar a distribuição de componentes nas linhas da planilha como histórico
  técnico de uma série;
- repetir o diagnóstico rápido no formulário e na aba de diagnóstico;
- alterar regras estáveis apenas para resolver um problema visual.

## Verificação para novas telas

Antes de incluir ou modificar uma tela, confirmar:

- a ação principal está evidente;
- os nomes correspondem ao fluxo real;
- as colunas abrem compactas;
- existe orientação quando não há dados;
- sucesso, atenção e erro possuem texto além da cor;
- a interface funciona sem conhecer todos os postos do CQR;
- nenhuma regra do Gerenciador ou do histórico foi alterada por acidente.
