﻿Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
[System.Windows.Forms.Application]::SetCompatibleTextRenderingDefault($false)

$script:AppVersion = "0.8.4"
$script:RootPath = $PSScriptRoot
$script:GeneratorVersion = "3.4.0"
$script:MaintenanceVersion = "0.5.0"
$script:UpdaterVersion = "1.0.0"
$script:GeneratorDirectory = [IO.Path]::Combine(
    $script:RootPath,
    "Modulos",
    "Gerador-de-Planilhas-CB5-TV5"
)
$script:GeneratorScript = [IO.Path]::Combine($script:GeneratorDirectory, "Gerador Planilhas.ps1")
$script:MaintenanceDirectory = [IO.Path]::Combine(
    $script:RootPath,
    "Modulos",
    "Central-de-Manutencao-CB5"
)
$script:MaintenanceScript = [IO.Path]::Combine($script:MaintenanceDirectory, "Central Manutencao CB5.ps1")
$script:UpdaterDirectory = [IO.Path]::Combine($script:RootPath, "Atualizador")
$script:UpdaterScript = [IO.Path]::Combine($script:UpdaterDirectory, "Central de Trabalho Updater.ps1")
$script:SettingsDirectory = [IO.Path]::Combine(
    [Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData),
    "CentralDeTrabalho"
)
$script:SettingsPath = [IO.Path]::Combine($script:SettingsDirectory, "preferencias.json")
$script:CurrentPalette = $null

$script:SingleInstanceMutex = $null
$script:OwnsSingleInstanceMutex = $false
$createdNewMutex = $false
try {
    $script:SingleInstanceMutex = [Threading.Mutex]::new($true, "CentralDeTrabalho_Central", ([ref]$createdNewMutex))
    $script:OwnsSingleInstanceMutex = $createdNewMutex
}
catch {}

if ($null -ne $script:SingleInstanceMutex -and -not $script:OwnsSingleInstanceMutex) {
    [Windows.Forms.MessageBox]::Show(
        "A Central de Trabalho já está aberta.",
        "Central de Trabalho",
        [Windows.Forms.MessageBoxButtons]::OK,
        [Windows.Forms.MessageBoxIcon]::Information
    ) | Out-Null
    $script:SingleInstanceMutex.Dispose()
    return
}

function Close-CentralSingleInstanceMutex {
    if ($null -eq $script:SingleInstanceMutex) { return }
    try {
        if ($script:OwnsSingleInstanceMutex) { $script:SingleInstanceMutex.ReleaseMutex() }
    }
    catch {}
    try { $script:SingleInstanceMutex.Dispose() }
    catch {}
    $script:SingleInstanceMutex = $null
    $script:OwnsSingleInstanceMutex = $false
}

function Get-AppSettings {
    $settings = [pscustomobject]@{ Theme = "Claro moderno" }
    try {
        if ([IO.File]::Exists($script:SettingsPath)) {
            $saved = Get-Content -LiteralPath $script:SettingsPath -Raw -Encoding UTF8 | ConvertFrom-Json
            if (@("Claro moderno", "Escuro grafite", "Alto contraste") -contains [string]$saved.Theme) {
                $settings.Theme = [string]$saved.Theme
            }
        }
    }
    catch {}
    return $settings
}

function Save-AppSettings {
    try {
        if (-not [IO.Directory]::Exists($script:SettingsDirectory)) {
            [void][IO.Directory]::CreateDirectory($script:SettingsDirectory)
        }
        [pscustomobject]@{
            Theme = [string]$themeCombo.SelectedItem
        } | ConvertTo-Json | Set-Content -LiteralPath $script:SettingsPath -Encoding UTF8
    }
    catch {}
}

function Get-ThemePalette {
    param([string]$Theme)

    switch ($Theme) {
        "Escuro grafite" {
            return [pscustomobject]@{
                Background = [Drawing.Color]::FromArgb(15, 23, 42)
                Surface = [Drawing.Color]::FromArgb(30, 41, 59)
                Card = [Drawing.Color]::FromArgb(23, 33, 52)
                Input = [Drawing.Color]::FromArgb(15, 23, 42)
                Text = [Drawing.Color]::FromArgb(248, 250, 252)
                Muted = [Drawing.Color]::FromArgb(203, 213, 225)
                Border = [Drawing.Color]::FromArgb(71, 85, 105)
                Accent = [Drawing.Color]::FromArgb(96, 165, 250)
                AccentStrong = [Drawing.Color]::FromArgb(37, 99, 235)
                AccentText = [Drawing.Color]::White
                Success = [Drawing.Color]::FromArgb(52, 211, 153)
                SuccessBack = [Drawing.Color]::FromArgb(6, 78, 59)
                Planned = [Drawing.Color]::FromArgb(251, 191, 36)
                PlannedBack = [Drawing.Color]::FromArgb(92, 62, 8)
                Footer = [Drawing.Color]::FromArgb(17, 27, 45)
            }
        }
        "Alto contraste" {
            return [pscustomobject]@{
                Background = [Drawing.Color]::Black
                Surface = [Drawing.Color]::Black
                Card = [Drawing.Color]::FromArgb(18, 18, 18)
                Input = [Drawing.Color]::Black
                Text = [Drawing.Color]::White
                Muted = [Drawing.Color]::White
                Border = [Drawing.Color]::White
                Accent = [Drawing.Color]::Yellow
                AccentStrong = [Drawing.Color]::Yellow
                AccentText = [Drawing.Color]::Black
                Success = [Drawing.Color]::Lime
                SuccessBack = [Drawing.Color]::Black
                Planned = [Drawing.Color]::Yellow
                PlannedBack = [Drawing.Color]::Black
                Footer = [Drawing.Color]::Black
            }
        }
        default {
            return [pscustomobject]@{
                Background = [Drawing.Color]::FromArgb(241, 245, 249)
                Surface = [Drawing.Color]::White
                Card = [Drawing.Color]::White
                Input = [Drawing.Color]::White
                Text = [Drawing.Color]::FromArgb(15, 23, 42)
                Muted = [Drawing.Color]::FromArgb(71, 85, 105)
                Border = [Drawing.Color]::FromArgb(203, 213, 225)
                Accent = [Drawing.Color]::FromArgb(37, 99, 235)
                AccentStrong = [Drawing.Color]::FromArgb(29, 78, 216)
                AccentText = [Drawing.Color]::White
                Success = [Drawing.Color]::FromArgb(4, 120, 87)
                SuccessBack = [Drawing.Color]::FromArgb(209, 250, 229)
                Planned = [Drawing.Color]::FromArgb(180, 83, 9)
                PlannedBack = [Drawing.Color]::FromArgb(254, 243, 199)
                Footer = [Drawing.Color]::FromArgb(226, 232, 240)
            }
        }
    }
}

function Set-PrimaryButtonStyle {
    param([Windows.Forms.Button]$Button)

    $Button.FlatStyle = [Windows.Forms.FlatStyle]::Flat
    $Button.FlatAppearance.BorderSize = 0
    $Button.BackColor = $script:CurrentPalette.AccentStrong
    $Button.ForeColor = $script:CurrentPalette.AccentText
    $Button.Cursor = [Windows.Forms.Cursors]::Hand
}

function Set-SecondaryButtonStyle {
    param([Windows.Forms.Button]$Button)

    $Button.FlatStyle = [Windows.Forms.FlatStyle]::Flat
    $Button.FlatAppearance.BorderSize = 1
    $Button.FlatAppearance.BorderColor = $script:CurrentPalette.Border
    $Button.BackColor = $script:CurrentPalette.Surface
    $Button.ForeColor = $script:CurrentPalette.Text
    $Button.Cursor = [Windows.Forms.Cursors]::Hand
}

function Set-StatusMessage {
    param(
        [string]$Message,
        [ValidateSet("Normal", "Success", "Warning", "Error")][string]$Kind = "Normal"
    )

    $footerStatus.Text = $Message
    switch ($Kind) {
        "Success" { $footerStatus.ForeColor = $script:CurrentPalette.Success }
        "Warning" { $footerStatus.ForeColor = $script:CurrentPalette.Planned }
        "Error" { $footerStatus.ForeColor = [Drawing.Color]::FromArgb(220, 38, 38) }
        default { $footerStatus.ForeColor = $script:CurrentPalette.Muted }
    }
}

function Apply-AppTheme {
    $selectedTheme = [string]$themeCombo.SelectedItem
    $script:CurrentPalette = Get-ThemePalette $selectedTheme

    $form.BackColor = $script:CurrentPalette.Background
    $rootLayout.BackColor = $script:CurrentPalette.Background
    $headerPanel.BackColor = $script:CurrentPalette.Surface
    $introPanel.BackColor = $script:CurrentPalette.Background
    $cardsHost.BackColor = $script:CurrentPalette.Background
    $cardsFlow.BackColor = $script:CurrentPalette.Background
    $footerPanel.BackColor = $script:CurrentPalette.Footer

    foreach ($label in @($appTitle, $generatorTitle, $maintenanceTitle)) {
        $label.ForeColor = $script:CurrentPalette.Text
    }
    foreach ($label in @(
        $appSubtitle,
        $themeLabel,
        $introText,
        $generatorDescription,
        $generatorDetail,
        $maintenanceDescription,
        $maintenanceDetail,
        $footerVersion
    )) {
        $label.ForeColor = $script:CurrentPalette.Muted
    }

    foreach ($card in @($generatorCard, $maintenanceCard)) {
        $card.BackColor = $script:CurrentPalette.Card
        $card.BorderStyle = [Windows.Forms.BorderStyle]::FixedSingle
    }
    foreach ($layout in @($generatorLayout, $maintenanceLayout)) {
        $layout.BackColor = $script:CurrentPalette.Card
    }

    $generatorStatus.BackColor = $script:CurrentPalette.SuccessBack
    $generatorStatus.ForeColor = $script:CurrentPalette.Success
    $maintenanceStatus.BackColor = $script:CurrentPalette.SuccessBack
    $maintenanceStatus.ForeColor = $script:CurrentPalette.Success

    $themeCombo.BackColor = $script:CurrentPalette.Input
    $themeCombo.ForeColor = $script:CurrentPalette.Text
    Set-PrimaryButtonStyle $openGeneratorButton
    Set-PrimaryButtonStyle $openMaintenanceButton
    Set-SecondaryButtonStyle $updatesButton
    Set-SecondaryButtonStyle $openFolderButton

    if ([IO.File]::Exists($script:GeneratorScript) -and [IO.File]::Exists($script:MaintenanceScript) -and [IO.File]::Exists($script:UpdaterScript)) {
        Set-StatusMessage "Pronto. Gerenciador v$($script:GeneratorVersion), Manutenção v$($script:MaintenanceVersion) e Atualizador v$($script:UpdaterVersion)." "Success"
    }
    elseif (-not [IO.File]::Exists($script:UpdaterScript)) {
        Set-StatusMessage "O Atualizador da Central de Trabalho não foi encontrado." "Error"
    }
    elseif (-not [IO.File]::Exists($script:MaintenanceScript)) {
        Set-StatusMessage "O módulo Central de Manutenção CB5 não foi encontrado." "Error"
    }
    else {
        Set-StatusMessage "O módulo Gerenciador de Planilhas não foi encontrado." "Error"
    }
    $form.Invalidate($true)
}

function Update-CardLayout {
    if ($null -eq $cardsFlow -or $cardsFlow.ClientSize.Width -le 0) { return }

    $availableWidth = $cardsFlow.ClientSize.Width - $cardsFlow.Padding.Horizontal - 34
    if ($availableWidth -lt 360) { $availableWidth = 360 }

    $cardWidth = $availableWidth
    if ($availableWidth -ge 850) {
        $cardWidth = [int](($availableWidth - 22) / 2)
    }

    foreach ($card in @($generatorCard, $maintenanceCard)) {
        $card.Width = $cardWidth
        $card.Height = 330
    }
}

function Start-GeneratorModule {
    if (-not [IO.File]::Exists($script:GeneratorScript)) {
        Set-StatusMessage "Não foi possível abrir: arquivo do gerenciador ausente." "Error"
        [Windows.Forms.MessageBox]::Show(
            "O arquivo do Gerenciador de Planilhas não foi encontrado.`r`n`r`n$($script:GeneratorScript)",
            "Central de Trabalho",
            [Windows.Forms.MessageBoxButtons]::OK,
            [Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
        return
    }

    try {
        $powershellPath = [IO.Path]::Combine(
            [Environment]::GetFolderPath([Environment+SpecialFolder]::Windows),
            "System32",
            "WindowsPowerShell",
            "v1.0",
            "powershell.exe"
        )
        if (-not [IO.File]::Exists($powershellPath)) { $powershellPath = "powershell.exe" }

        $startInfo = New-Object Diagnostics.ProcessStartInfo
        $startInfo.FileName = $powershellPath
        $startInfo.WorkingDirectory = $script:GeneratorDirectory
        $startInfo.Arguments = '-NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "' + $script:GeneratorScript + '"'
        $startInfo.UseShellExecute = $true
        [void][Diagnostics.Process]::Start($startInfo)
        Set-StatusMessage "Gerenciador de Planilhas aberto em uma nova janela." "Success"
    }
    catch {
        Set-StatusMessage "Falha ao iniciar o Gerenciador de Planilhas." "Error"
        [Windows.Forms.MessageBox]::Show(
            "Não foi possível iniciar o Gerenciador de Planilhas.`r`n`r`n$($_.Exception.Message)",
            "Central de Trabalho",
            [Windows.Forms.MessageBoxButtons]::OK,
            [Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    }
}

function Start-MaintenanceModule {
    if (-not [IO.File]::Exists($script:MaintenanceScript)) {
        Set-StatusMessage "Não foi possível abrir: arquivo da Manutenção CB5 ausente." "Error"
        [Windows.Forms.MessageBox]::Show(
            "O arquivo da Central de Manutenção CB5 não foi encontrado.`r`n`r`n$($script:MaintenanceScript)",
            "Central de Trabalho",
            [Windows.Forms.MessageBoxButtons]::OK,
            [Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
        return
    }

    try {
        $powershellPath = [IO.Path]::Combine(
            [Environment]::GetFolderPath([Environment+SpecialFolder]::Windows),
            "System32",
            "WindowsPowerShell",
            "v1.0",
            "powershell.exe"
        )
        if (-not [IO.File]::Exists($powershellPath)) { $powershellPath = "powershell.exe" }

        $startInfo = New-Object Diagnostics.ProcessStartInfo
        $startInfo.FileName = $powershellPath
        $startInfo.WorkingDirectory = $script:MaintenanceDirectory
        $startInfo.Arguments = '-NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "' + $script:MaintenanceScript + '"'
        $startInfo.UseShellExecute = $true
        [void][Diagnostics.Process]::Start($startInfo)
        Set-StatusMessage "Central de Manutenção CB5 aberta em uma nova janela." "Success"
    }
    catch {
        Set-StatusMessage "Falha ao iniciar a Central de Manutenção CB5." "Error"
        [Windows.Forms.MessageBox]::Show(
            "Não foi possível iniciar a Central de Manutenção CB5.`r`n`r`n$($_.Exception.Message)",
            "Central de Trabalho",
            [Windows.Forms.MessageBoxButtons]::OK,
            [Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    }
}

function Start-UpdaterModule {
    if (-not [IO.File]::Exists($script:UpdaterScript)) {
        Set-StatusMessage "Não foi possível abrir: arquivo do Atualizador ausente." "Error"
        [Windows.Forms.MessageBox]::Show(
            "O arquivo do Atualizador não foi encontrado.`r`n`r`n$($script:UpdaterScript)",
            "Central de Trabalho",
            [Windows.Forms.MessageBoxButtons]::OK,
            [Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
        return
    }

    try {
        $powershellPath = [IO.Path]::Combine(
            [Environment]::GetFolderPath([Environment+SpecialFolder]::Windows),
            "System32",
            "WindowsPowerShell",
            "v1.0",
            "powershell.exe"
        )
        if (-not [IO.File]::Exists($powershellPath)) { $powershellPath = "powershell.exe" }

        $startInfo = New-Object Diagnostics.ProcessStartInfo
        $startInfo.FileName = $powershellPath
        $startInfo.WorkingDirectory = $script:UpdaterDirectory
        $startInfo.Arguments = '-NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "' + $script:UpdaterScript + '" -InstallRoot "' + $script:RootPath + '" -CurrentVersion "' + $script:AppVersion + '" -ParentProcessId ' + $PID
        $startInfo.UseShellExecute = $true
        [void][Diagnostics.Process]::Start($startInfo)
        Set-StatusMessage "Tela de atualizações aberta em uma nova janela." "Success"
    }
    catch {
        Set-StatusMessage "Falha ao iniciar o Atualizador." "Error"
        [Windows.Forms.MessageBox]::Show(
            "Não foi possível iniciar o Atualizador.`r`n`r`n$($_.Exception.Message)",
            "Central de Trabalho",
            [Windows.Forms.MessageBoxButtons]::OK,
            [Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    }
}

$settings = Get-AppSettings

$form = New-Object Windows.Forms.Form
$form.Text = "Central de Trabalho"
$form.StartPosition = [Windows.Forms.FormStartPosition]::CenterScreen
$form.AutoScaleMode = [Windows.Forms.AutoScaleMode]::Dpi
$form.Font = [Drawing.Font]::new("Segoe UI", 9.5)
$form.MinimumSize = [Drawing.Size]::new(700, 520)
$form.MaximizeBox = $true
$form.MinimizeBox = $true
$form.SizeGripStyle = [Windows.Forms.SizeGripStyle]::Show

$workingArea = [Windows.Forms.Screen]::PrimaryScreen.WorkingArea
$targetWidth = [Math]::Min(1180, [Math]::Max(760, [int]($workingArea.Width * 0.78)))
$targetHeight = [Math]::Min(760, [Math]::Max(570, [int]($workingArea.Height * 0.82)))
$form.Size = [Drawing.Size]::new($targetWidth, $targetHeight)

$rootLayout = New-Object Windows.Forms.TableLayoutPanel
$rootLayout.Dock = [Windows.Forms.DockStyle]::Fill
$rootLayout.Margin = [Windows.Forms.Padding]::new(0)
$rootLayout.Padding = [Windows.Forms.Padding]::new(0)
$rootLayout.ColumnCount = 1
$rootLayout.RowCount = 4
[void]$rootLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Absolute, 105)))
[void]$rootLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Absolute, 92)))
[void]$rootLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Percent, 100)))
[void]$rootLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Absolute, 56)))
$form.Controls.Add($rootLayout)

$headerPanel = New-Object Windows.Forms.Panel
$headerPanel.Dock = [Windows.Forms.DockStyle]::Fill
$headerPanel.Padding = [Windows.Forms.Padding]::new(28, 18, 24, 14)
$rootLayout.Controls.Add($headerPanel, 0, 0)

$headerLayout = New-Object Windows.Forms.TableLayoutPanel
$headerLayout.Dock = [Windows.Forms.DockStyle]::Fill
$headerLayout.ColumnCount = 4
$headerLayout.RowCount = 1
[void]$headerLayout.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent, 100)))
[void]$headerLayout.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Absolute, 170)))
[void]$headerLayout.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Absolute, 155)))
[void]$headerLayout.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Absolute, 135)))
$headerPanel.Controls.Add($headerLayout)

$titlePanel = New-Object Windows.Forms.TableLayoutPanel
$titlePanel.Dock = [Windows.Forms.DockStyle]::Fill
$titlePanel.ColumnCount = 1
$titlePanel.RowCount = 2
[void]$titlePanel.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Percent, 58)))
[void]$titlePanel.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Percent, 42)))
$headerLayout.Controls.Add($titlePanel, 0, 0)

$appTitle = New-Object Windows.Forms.Label
$appTitle.Text = "Central de Trabalho"
$appTitle.Dock = [Windows.Forms.DockStyle]::Fill
$appTitle.TextAlign = [Drawing.ContentAlignment]::BottomLeft
$appTitle.Font = [Drawing.Font]::new("Segoe UI Semibold", 23)
$titlePanel.Controls.Add($appTitle, 0, 0)

$appSubtitle = New-Object Windows.Forms.Label
$appSubtitle.Text = "Seus programas reunidos em um único lugar"
$appSubtitle.Dock = [Windows.Forms.DockStyle]::Fill
$appSubtitle.TextAlign = [Drawing.ContentAlignment]::TopLeft
$appSubtitle.Font = [Drawing.Font]::new("Segoe UI", 10.5)
$titlePanel.Controls.Add($appSubtitle, 0, 1)

$themePanel = New-Object Windows.Forms.TableLayoutPanel
$themePanel.Dock = [Windows.Forms.DockStyle]::Fill
$themePanel.Padding = [Windows.Forms.Padding]::new(8, 5, 8, 4)
$themePanel.ColumnCount = 1
$themePanel.RowCount = 2
[void]$themePanel.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Absolute, 28)))
[void]$themePanel.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Absolute, 36)))
$headerLayout.Controls.Add($themePanel, 1, 0)

$themeLabel = New-Object Windows.Forms.Label
$themeLabel.Text = "Aparência"
$themeLabel.Dock = [Windows.Forms.DockStyle]::Fill
$themeLabel.TextAlign = [Drawing.ContentAlignment]::BottomLeft
$themePanel.Controls.Add($themeLabel, 0, 0)

$themeCombo = New-Object Windows.Forms.ComboBox
$themeCombo.Dock = [Windows.Forms.DockStyle]::Fill
$themeCombo.DropDownStyle = [Windows.Forms.ComboBoxStyle]::DropDownList
[void]$themeCombo.Items.AddRange(@("Claro moderno", "Escuro grafite", "Alto contraste"))
$themeCombo.SelectedItem = $settings.Theme
if ($themeCombo.SelectedIndex -lt 0) { $themeCombo.SelectedIndex = 0 }
$themePanel.Controls.Add($themeCombo, 0, 1)

$updatesPanel = New-Object Windows.Forms.Panel
$updatesPanel.Dock = [Windows.Forms.DockStyle]::Fill
$updatesPanel.Padding = [Windows.Forms.Padding]::new(8, 28, 0, 8)
$headerLayout.Controls.Add($updatesPanel, 2, 0)

$updatesButton = New-Object Windows.Forms.Button
$updatesButton.Text = "ATUALIZAÇÕES"
$updatesButton.Dock = [Windows.Forms.DockStyle]::Fill
$updatesButton.Font = [Drawing.Font]::new("Segoe UI Semibold", 9)
$updatesPanel.Controls.Add($updatesButton)

$folderPanel = New-Object Windows.Forms.Panel
$folderPanel.Dock = [Windows.Forms.DockStyle]::Fill
$folderPanel.Padding = [Windows.Forms.Padding]::new(8, 28, 0, 8)
$headerLayout.Controls.Add($folderPanel, 3, 0)

$openFolderButton = New-Object Windows.Forms.Button
$openFolderButton.Text = "ABRIR PASTA"
$openFolderButton.Dock = [Windows.Forms.DockStyle]::Fill
$openFolderButton.Font = [Drawing.Font]::new("Segoe UI Semibold", 9)
$folderPanel.Controls.Add($openFolderButton)

$introPanel = New-Object Windows.Forms.Panel
$introPanel.Dock = [Windows.Forms.DockStyle]::Fill
$introPanel.Padding = [Windows.Forms.Padding]::new(30, 18, 30, 10)
$rootLayout.Controls.Add($introPanel, 0, 1)

$introText = New-Object Windows.Forms.Label
$introText.Dock = [Windows.Forms.DockStyle]::Fill
$introText.Text = "Escolha o programa que deseja abrir. Cada módulo funciona em sua própria janela."
$introText.Font = [Drawing.Font]::new("Segoe UI", 11)
$introText.TextAlign = [Drawing.ContentAlignment]::MiddleLeft
$introPanel.Controls.Add($introText)

$cardsHost = New-Object Windows.Forms.Panel
$cardsHost.Dock = [Windows.Forms.DockStyle]::Fill
$cardsHost.Padding = [Windows.Forms.Padding]::new(18, 0, 18, 12)
$rootLayout.Controls.Add($cardsHost, 0, 2)

$cardsFlow = New-Object Windows.Forms.FlowLayoutPanel
$cardsFlow.Dock = [Windows.Forms.DockStyle]::Fill
$cardsFlow.AutoScroll = $true
$cardsFlow.WrapContents = $true
$cardsFlow.FlowDirection = [Windows.Forms.FlowDirection]::LeftToRight
$cardsFlow.Padding = [Windows.Forms.Padding]::new(10, 6, 10, 6)
$cardsHost.Controls.Add($cardsFlow)

$generatorCard = New-Object Windows.Forms.Panel
$generatorCard.Margin = [Windows.Forms.Padding]::new(10)
$generatorCard.Padding = [Windows.Forms.Padding]::new(22)
$cardsFlow.Controls.Add($generatorCard)

$generatorLayout = New-Object Windows.Forms.TableLayoutPanel
$generatorLayout.Dock = [Windows.Forms.DockStyle]::Fill
$generatorLayout.ColumnCount = 1
$generatorLayout.RowCount = 5
[void]$generatorLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Absolute, 34)))
[void]$generatorLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Absolute, 52)))
[void]$generatorLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Percent, 100)))
[void]$generatorLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Absolute, 40)))
[void]$generatorLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Absolute, 50)))
$generatorCard.Controls.Add($generatorLayout)

$generatorStatus = New-Object Windows.Forms.Label
$generatorStatus.Text = "  DISPONÍVEL  "
$generatorStatus.AutoSize = $true
$generatorStatus.Padding = [Windows.Forms.Padding]::new(5, 4, 5, 4)
$generatorStatus.Font = [Drawing.Font]::new("Segoe UI Semibold", 8.5)
$generatorStatus.Anchor = [Windows.Forms.AnchorStyles]::Left
$generatorLayout.Controls.Add($generatorStatus, 0, 0)

$generatorTitle = New-Object Windows.Forms.Label
$generatorTitle.Text = "Gerenciador de Planilhas"
$generatorTitle.Dock = [Windows.Forms.DockStyle]::Fill
$generatorTitle.TextAlign = [Drawing.ContentAlignment]::MiddleLeft
$generatorTitle.Font = [Drawing.Font]::new("Segoe UI Semibold", 17)
$generatorLayout.Controls.Add($generatorTitle, 0, 1)

$generatorDescription = New-Object Windows.Forms.Label
$generatorDescription.Text = "Prepara mestres CB5 e TV5, gera e junta planilhas, e controla componentes usados ainda pendentes de faturamento."
$generatorDescription.Dock = [Windows.Forms.DockStyle]::Fill
$generatorDescription.Font = [Drawing.Font]::new("Segoe UI", 10.5)
$generatorDescription.TextAlign = [Drawing.ContentAlignment]::TopLeft
$generatorLayout.Controls.Add($generatorDescription, 0, 2)

$generatorDetail = New-Object Windows.Forms.Label
$generatorDetail.Text = "Versão integrada: $($script:GeneratorVersion)  |  Requer Microsoft Excel"
$generatorDetail.Dock = [Windows.Forms.DockStyle]::Fill
$generatorDetail.TextAlign = [Drawing.ContentAlignment]::MiddleLeft
$generatorDetail.Font = [Drawing.Font]::new("Segoe UI", 9)
$generatorLayout.Controls.Add($generatorDetail, 0, 3)

$openGeneratorButton = New-Object Windows.Forms.Button
$openGeneratorButton.Text = "ABRIR GERENCIADOR"
$openGeneratorButton.Dock = [Windows.Forms.DockStyle]::Fill
$openGeneratorButton.Margin = [Windows.Forms.Padding]::new(0, 7, 0, 0)
$openGeneratorButton.Font = [Drawing.Font]::new("Segoe UI Semibold", 10)
$generatorLayout.Controls.Add($openGeneratorButton, 0, 4)

$maintenanceCard = New-Object Windows.Forms.Panel
$maintenanceCard.Margin = [Windows.Forms.Padding]::new(10)
$maintenanceCard.Padding = [Windows.Forms.Padding]::new(22)
$cardsFlow.Controls.Add($maintenanceCard)

$maintenanceLayout = New-Object Windows.Forms.TableLayoutPanel
$maintenanceLayout.Dock = [Windows.Forms.DockStyle]::Fill
$maintenanceLayout.ColumnCount = 1
$maintenanceLayout.RowCount = 5
[void]$maintenanceLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Absolute, 34)))
[void]$maintenanceLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Absolute, 52)))
[void]$maintenanceLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Percent, 100)))
[void]$maintenanceLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Absolute, 40)))
[void]$maintenanceLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Absolute, 50)))
$maintenanceCard.Controls.Add($maintenanceLayout)

$maintenanceStatus = New-Object Windows.Forms.Label
$maintenanceStatus.Text = "  DISPONÍVEL  "
$maintenanceStatus.AutoSize = $true
$maintenanceStatus.Padding = [Windows.Forms.Padding]::new(5, 4, 5, 4)
$maintenanceStatus.Font = [Drawing.Font]::new("Segoe UI Semibold", 8.5)
$maintenanceStatus.Anchor = [Windows.Forms.AnchorStyles]::Left
$maintenanceLayout.Controls.Add($maintenanceStatus, 0, 0)

$maintenanceTitle = New-Object Windows.Forms.Label
$maintenanceTitle.Text = "Central de Manutenção CB5"
$maintenanceTitle.Dock = [Windows.Forms.DockStyle]::Fill
$maintenanceTitle.TextAlign = [Drawing.ContentAlignment]::MiddleLeft
$maintenanceTitle.Font = [Drawing.Font]::new("Segoe UI Semibold", 17)
$maintenanceLayout.Controls.Add($maintenanceTitle, 0, 1)

$maintenanceDescription = New-Object Windows.Forms.Label
$maintenanceDescription.Text = "Cadastro de peças por código, histórico automático da série, correção auditada, relatórios e apoio ao diagnóstico."
$maintenanceDescription.Dock = [Windows.Forms.DockStyle]::Fill
$maintenanceDescription.Font = [Drawing.Font]::new("Segoe UI", 10.5)
$maintenanceDescription.TextAlign = [Drawing.ContentAlignment]::TopLeft
$maintenanceLayout.Controls.Add($maintenanceDescription, 0, 2)

$maintenanceDetail = New-Object Windows.Forms.Label
$maintenanceDetail.Text = "Versão integrada: $($script:MaintenanceVersion)  |  Histórico local por série"
$maintenanceDetail.Dock = [Windows.Forms.DockStyle]::Fill
$maintenanceDetail.TextAlign = [Drawing.ContentAlignment]::MiddleLeft
$maintenanceDetail.Font = [Drawing.Font]::new("Segoe UI", 9)
$maintenanceLayout.Controls.Add($maintenanceDetail, 0, 3)

$openMaintenanceButton = New-Object Windows.Forms.Button
$openMaintenanceButton.Text = "ABRIR MANUTENÇÃO"
$openMaintenanceButton.Dock = [Windows.Forms.DockStyle]::Fill
$openMaintenanceButton.Margin = [Windows.Forms.Padding]::new(0, 7, 0, 0)
$openMaintenanceButton.Font = [Drawing.Font]::new("Segoe UI Semibold", 10)
$maintenanceLayout.Controls.Add($openMaintenanceButton, 0, 4)

$footerPanel = New-Object Windows.Forms.Panel
$footerPanel.Dock = [Windows.Forms.DockStyle]::Fill
$footerPanel.Padding = [Windows.Forms.Padding]::new(28, 8, 28, 8)
$rootLayout.Controls.Add($footerPanel, 0, 3)

$footerLayout = New-Object Windows.Forms.TableLayoutPanel
$footerLayout.Dock = [Windows.Forms.DockStyle]::Fill
$footerLayout.ColumnCount = 2
$footerLayout.RowCount = 1
[void]$footerLayout.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent, 100)))
[void]$footerLayout.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::AutoSize)))
$footerPanel.Controls.Add($footerLayout)

$footerStatus = New-Object Windows.Forms.Label
$footerStatus.Dock = [Windows.Forms.DockStyle]::Fill
$footerStatus.TextAlign = [Drawing.ContentAlignment]::MiddleLeft
$footerStatus.AutoEllipsis = $true
$footerLayout.Controls.Add($footerStatus, 0, 0)

$footerVersion = New-Object Windows.Forms.Label
$footerVersion.Text = "Central v$($script:AppVersion)"
$footerVersion.AutoSize = $true
$footerVersion.Anchor = [Windows.Forms.AnchorStyles]::Right
$footerVersion.TextAlign = [Drawing.ContentAlignment]::MiddleRight
$footerLayout.Controls.Add($footerVersion, 1, 0)

$themeCombo.Add_SelectedIndexChanged({
    Apply-AppTheme
    Save-AppSettings
})
$openGeneratorButton.Add_Click({ Start-GeneratorModule })
$openMaintenanceButton.Add_Click({ Start-MaintenanceModule })
$updatesButton.Add_Click({ Start-UpdaterModule })
$openFolderButton.Add_Click({
    try {
        Start-Process -FilePath "explorer.exe" -ArgumentList ('"' + $script:RootPath + '"')
        Set-StatusMessage "Pasta da Central de Trabalho aberta." "Success"
    }
    catch {
        Set-StatusMessage "Não foi possível abrir a pasta do programa." "Error"
    }
})
$cardsFlow.Add_SizeChanged({ Update-CardLayout })
$form.Add_Shown({
    Update-CardLayout
    Apply-AppTheme
})
$form.Add_FormClosing({ Save-AppSettings })

Apply-AppTheme
try {
    [void]$form.ShowDialog()
}
finally {
    Save-AppSettings
    $form.Dispose()
    Close-CentralSingleInstanceMutex
}
