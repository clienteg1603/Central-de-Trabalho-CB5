﻿# Atualizações pela internet

A Central de Trabalho v0.8.4 ativa os endereços permanentes dos canais de atualização. O mecanismo usa somente HTTPS, validação de identidade, tamanho, SHA-256, manifesto interno do pacote, backup e restauração.

## Hospedagem oficial

- projeto: `clienteg1603/Central-de-Trabalho-CB5`
- canal Estável: `https://raw.githubusercontent.com/clienteg1603/Central-de-Trabalho-CB5/main/updates/stable.json`
- canal Teste: `https://raw.githubusercontent.com/clienteg1603/Central-de-Trabalho-CB5/main/updates/test.json`

A Central de Trabalho/CB5 fica separada do projeto GP-H. Nenhuma senha ou token do GitHub é armazenado no programa.

## Primeira ativação a partir da v0.8.1

A v0.8.1 precisa configurar uma única vez o endereço do canal **Teste**. A v0.8.4 já traz Estável e Teste no próprio `Atualizador/CANAIS.json`.

## Correção validada nesta publicação

O primeiro teste real encontrou uma falha de interpolação do PowerShell na pergunta de confirmação da instalação: `$targetVersion?` era interpretado como um nome de variável diferente sob `Set-StrictMode -Version Latest`. A v0.8.4 publicada corrige a expressão para `${targetVersion}?` e inclui uma checagem de regressão para impedir o retorno do problema.

## Fluxo

1. Escolher Estável ou Teste.
2. Baixar o manifesto por HTTPS.
3. Mostrar versão e novidades.
4. Confirmar a instalação.
5. Baixar ZIP para pasta temporária.
6. Validar tamanho, SHA-256, identidade e manifesto interno.
7. Exigir Gerenciador e Manutenção fechados.
8. Fechar a Central após o pacote já estar validado.
9. Criar backup completo do programa e bases locais.
10. Instalar e conferir novamente.
11. Reabrir a Central; em falha, restaurar automaticamente.

Os backups ficam em `%LOCALAPPDATA%\CentralDeTrabalhoUpdater\Backups` e os dados locais só voltam numa restauração manual quando a opção específica estiver marcada.
