﻿# Central de Trabalho v0.8.4

Data: 09/09/2026

## Correções desta versão

- Corrigido o `Central de Trabalho.exe` para funcionar por duplo clique no Windows, usando o launcher VBS interno que já se mostrou confiável no computador real.
- O EXE continua sem abrir console preto.
- O Atualizador tenta automaticamente até 3 vezes quando a internet/servidor responde com falhas temporárias como 408, 429, 500, 502, 503 e 504.
- O botão `CONFIGURAR ENDEREÇO` passa a mostrar o endereço que está realmente em uso, inclusive quando ele vem do `CANAIS.json` do pacote.
- Mantidas as correções de reabertura automática, backup, restauração e validação SHA-256.

## Módulos preservados

- Gerenciador: 3.4.0.
- Central de Manutenção: 0.5.0.
