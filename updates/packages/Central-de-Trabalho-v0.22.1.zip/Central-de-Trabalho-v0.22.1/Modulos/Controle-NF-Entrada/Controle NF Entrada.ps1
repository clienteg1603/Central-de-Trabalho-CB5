﻿param(
    [Int64]$EmbeddedParentHandle = 0,
    [switch]$HostedInCentral,
    [string]$HostTheme = "",
    [AllowNull()][object]$HostThemeContext = $null
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
if (-not $HostedInCentral) { [System.Windows.Forms.Application]::SetCompatibleTextRenderingDefault($false) }

$script:IsInProcessHosted = [bool]$HostedInCentral
$script:HostedFormExport = $null
$script:HostedControlExport = $null
$script:HostedThemeContext = $(if ($script:IsInProcessHosted) { $HostThemeContext } else { $null })
function Test-NFHostedLayoutRestoreGate {
    if (-not $script:IsInProcessHosted -or $null -eq $script:HostedThemeContext) { return $false }
    try { return [bool]$script:HostedThemeContext.LayoutRestoreActive } catch { return $false }
}

$script:HostedCentralTheme = $(if ($script:IsInProcessHosted -and -not [string]::IsNullOrWhiteSpace($HostTheme)) { [string]$HostTheme } else { "" })
$script:ModuleRoot = $PSScriptRoot
$script:ModuleVersion = "2.6.26"
$script:CorePath = [IO.Path]::Combine($script:ModuleRoot, "NFEntrada.Core.ps1")
$script:DataDirectory = ""
$script:DatabasePath = ""
$script:Store = $null
$script:CurrentPalette = $null
$script:NFComputerNavButton = $null
$script:NFKeyboardNavButton = $null
$script:NFMovementNavButton = $null
$script:NFHistoryNavButton = $null
$script:NFSecurityNavButton = $null
$script:NFSummaryNavButton = $null
$script:ComputerProduct = "COMPUTADOR DE BORDO V5"
$script:KeyboardProduct = "TECLADO V5"

if (-not [IO.File]::Exists($script:CorePath)) {
    $message = "O núcleo do Controle de NF de Entrada não foi encontrado.`r`n`r`n$($script:CorePath)"
    if ($script:IsInProcessHosted) { throw $message }
    [Windows.Forms.MessageBox]::Show(
        $message,
        "Controle de NF de Entrada",
        [Windows.Forms.MessageBoxButtons]::OK,
        [Windows.Forms.MessageBoxIcon]::Error
    ) | Out-Null
    return
}
. $script:CorePath
$script:DataDirectory = Get-NFEntradaDefaultDataDirectory

try {
    $script:DatabasePath = Initialize-NFEntradaDataStore -DataDirectory $script:DataDirectory
    $script:Store = Read-NFEntradaStore -Path $script:DatabasePath
}
catch {
    $message = "Não foi possível preparar a base do Controle de NF de Entrada.`r`n`r`n$($_.Exception.Message)"
    if ($script:IsInProcessHosted) { throw $message }
    [Windows.Forms.MessageBox]::Show(
        $message,
        "Controle de NF de Entrada — base preservada",
        [Windows.Forms.MessageBoxButtons]::OK,
        [Windows.Forms.MessageBoxIcon]::Error
    ) | Out-Null
    return
}

function Get-NFEntradaPalette {
    param([string]$Theme)
    switch ($Theme) {
        "Claro corporativo" {
            return [pscustomobject]@{
                Background = [Drawing.Color]::FromArgb(242, 246, 250)
                Surface = [Drawing.Color]::White
                Card = [Drawing.Color]::White
                Input = [Drawing.Color]::White
                Text = [Drawing.Color]::FromArgb(18, 32, 50)
                Muted = [Drawing.Color]::FromArgb(86, 104, 126)
                Border = [Drawing.Color]::FromArgb(210, 220, 231)
                Accent = [Drawing.Color]::FromArgb(47, 112, 230)
                AccentStrong = [Drawing.Color]::FromArgb(34, 93, 205)
                AccentText = [Drawing.Color]::White
                Success = [Drawing.Color]::FromArgb(21, 138, 96)
                SuccessBack = [Drawing.Color]::FromArgb(221, 247, 237)
                Warning = [Drawing.Color]::FromArgb(173, 105, 16)
                WarningBack = [Drawing.Color]::FromArgb(255, 244, 204)
                Danger = [Drawing.Color]::FromArgb(185, 28, 28)
                DangerBack = [Drawing.Color]::FromArgb(254, 226, 226)
            }
        }
        "Técnico industrial" {
            return [pscustomobject]@{
                Background = [Drawing.Color]::FromArgb(18, 23, 25)
                Surface = [Drawing.Color]::FromArgb(27, 35, 38)
                Card = [Drawing.Color]::FromArgb(34, 43, 46)
                Input = [Drawing.Color]::FromArgb(18, 23, 25)
                Text = [Drawing.Color]::FromArgb(242, 246, 245)
                Muted = [Drawing.Color]::FromArgb(174, 188, 186)
                Border = [Drawing.Color]::FromArgb(62, 77, 80)
                Accent = [Drawing.Color]::FromArgb(44, 189, 197)
                AccentStrong = [Drawing.Color]::FromArgb(44, 189, 197)
                AccentText = [Drawing.Color]::FromArgb(9, 24, 28)
                Action = [Drawing.Color]::FromArgb(244, 142, 40)
                ActionText = [Drawing.Color]::FromArgb(27, 24, 17)
                Success = [Drawing.Color]::FromArgb(72, 202, 143)
                SuccessBack = [Drawing.Color]::FromArgb(22, 72, 57)
                Warning = [Drawing.Color]::FromArgb(246, 186, 68)
                WarningBack = [Drawing.Color]::FromArgb(86, 59, 13)
                Danger = [Drawing.Color]::FromArgb(239, 108, 102)
                DangerBack = [Drawing.Color]::FromArgb(78, 28, 26)
            }
        }
        "Alto contraste" {
            return [pscustomobject]@{
                Background = [Drawing.Color]::Black
                Surface = [Drawing.Color]::Black
                Card = [Drawing.Color]::FromArgb(18, 18, 18)
                Input = [Drawing.Color]::Black
                Text = [Drawing.Color]::White
                Muted = [Drawing.Color]::White
                Border = [Drawing.Color]::White
                Accent = [Drawing.Color]::Yellow
                AccentStrong = [Drawing.Color]::Yellow
                AccentText = [Drawing.Color]::Black
                Success = [Drawing.Color]::Lime
                SuccessBack = [Drawing.Color]::Black
                Warning = [Drawing.Color]::Yellow
                WarningBack = [Drawing.Color]::Black
                Danger = [Drawing.Color]::Red
                DangerBack = [Drawing.Color]::Black
            }
        }
        default {
            return [pscustomobject]@{
                Background = [Drawing.Color]::FromArgb(13, 20, 34)
                Surface = [Drawing.Color]::FromArgb(17, 27, 44)
                Card = [Drawing.Color]::FromArgb(23, 34, 54)
                Input = [Drawing.Color]::FromArgb(14, 25, 41)
                Text = [Drawing.Color]::FromArgb(244, 247, 251)
                Muted = [Drawing.Color]::FromArgb(170, 182, 200)
                Border = [Drawing.Color]::FromArgb(41, 55, 80)
                Accent = [Drawing.Color]::FromArgb(39, 196, 125)
                AccentStrong = [Drawing.Color]::FromArgb(29, 166, 105)
                AccentText = [Drawing.Color]::White
                Success = [Drawing.Color]::FromArgb(52, 211, 153)
                SuccessBack = [Drawing.Color]::FromArgb(15, 72, 57)
                Warning = [Drawing.Color]::FromArgb(251, 191, 36)
                WarningBack = [Drawing.Color]::FromArgb(73, 48, 15)
                Danger = [Drawing.Color]::FromArgb(239, 100, 100)
                DangerBack = [Drawing.Color]::FromArgb(78, 26, 31)
            }
        }
    }
}

function Get-NFEntradaHostedCentralTheme {
    $theme = ""
    if ($script:IsInProcessHosted -and $null -ne $script:HostedThemeContext) {
        try {
            if ($script:HostedThemeContext.PSObject.Properties.Name -contains "Theme") {
                $theme = [string]$script:HostedThemeContext.Theme
            }
        } catch {}
    }
    if ([string]::IsNullOrWhiteSpace($theme)) { $theme = [string]$script:HostedCentralTheme }
    if (-not (@("Escuro profissional", "Técnico industrial", "Claro corporativo", "Alto contraste") -contains $theme)) {
        $theme = "Escuro profissional"
    }
    $script:HostedCentralTheme = $theme
    return $theme
}

function Set-NFStatus {
    param(
        [string]$Message,
        [ValidateSet("Normal", "Success", "Warning", "Error")][string]$Kind = "Normal"
    )
    if ($null -eq $footerStatus) { return }
    $footerStatus.Text = $Message
    switch ($Kind) {
        "Success" { $footerStatus.ForeColor = $script:CurrentPalette.Success }
        "Warning" { $footerStatus.ForeColor = $script:CurrentPalette.Warning }
        "Error" { $footerStatus.ForeColor = $script:CurrentPalette.Danger }
        default { $footerStatus.ForeColor = $script:CurrentPalette.Muted }
    }
}

function Set-NFRoundedRegion {
    param([Windows.Forms.Control]$Control, [int]$Radius = 7)
    if ($null -eq $Control -or $Control.Width -le 2 -or $Control.Height -le 2) { return }
    try {
        $diameter = [Math]::Max(2, $Radius * 2)
        $rect = [Drawing.Rectangle]::new(0, 0, $Control.Width - 1, $Control.Height - 1)
        $path = New-Object Drawing.Drawing2D.GraphicsPath
        $path.AddArc($rect.Left, $rect.Top, $diameter, $diameter, 180, 90)
        $path.AddArc($rect.Right - $diameter, $rect.Top, $diameter, $diameter, 270, 90)
        $path.AddArc($rect.Right - $diameter, $rect.Bottom - $diameter, $diameter, $diameter, 0, 90)
        $path.AddArc($rect.Left, $rect.Bottom - $diameter, $diameter, $diameter, 90, 90)
        $path.CloseFigure()
        $oldRegion = $Control.Region
        $Control.Region = New-Object Drawing.Region($path)
        $path.Dispose()
        if ($null -ne $oldRegion) { $oldRegion.Dispose() }
    } catch {}
}

function Set-NFButtonStyle {
    param([Windows.Forms.Button]$Button, [ValidateSet("Primary", "Action", "Secondary", "Danger")][string]$Kind = "Secondary")
    $Button.Tag = "Theme.Button.$Kind"
    $Button.FlatStyle = [Windows.Forms.FlatStyle]::Flat
    $Button.Cursor = [Windows.Forms.Cursors]::Hand
    $Button.Font = [Drawing.Font]::new("Segoe UI Semibold", 9)
    switch ($Kind) {
        "Primary" {
            $Button.BackColor = $script:CurrentPalette.AccentStrong
            $Button.ForeColor = $script:CurrentPalette.AccentText
            $Button.FlatAppearance.BorderSize = 0
        }
        "Action" {
            $actionBack = if ($script:CurrentPalette.PSObject.Properties.Name -contains "Action") { $script:CurrentPalette.Action } else { [Drawing.Color]::FromArgb(244, 142, 40) }
            $actionText = if ($script:CurrentPalette.PSObject.Properties.Name -contains "ActionText") { $script:CurrentPalette.ActionText } else { [Drawing.Color]::FromArgb(27, 24, 17) }
            $Button.BackColor = $actionBack
            $Button.ForeColor = $actionText
            $Button.FlatAppearance.BorderSize = 0
        }
        "Danger" {
            $Button.BackColor = $script:CurrentPalette.DangerBack
            $Button.ForeColor = $script:CurrentPalette.Danger
            $Button.FlatAppearance.BorderColor = $script:CurrentPalette.Danger
            $Button.FlatAppearance.BorderSize = 1
        }
        default {
            $Button.BackColor = $script:CurrentPalette.Card
            $Button.ForeColor = [Drawing.Color]::White
            $Button.FlatAppearance.BorderColor = $script:CurrentPalette.Border
            $Button.FlatAppearance.BorderSize = 1
        }
    }
    Set-NFRoundedRegion $Button 10
}

function Add-NFReadableDisabledText {
    param([Windows.Forms.Button]$Button)
    if ($null -eq $Button) { return }
    $Button.Add_Paint({
        param($sender, $eventArgs)
        if ($sender.Enabled) { return }
        $flags = [Windows.Forms.TextFormatFlags]::HorizontalCenter -bor
                 [Windows.Forms.TextFormatFlags]::VerticalCenter -bor
                 [Windows.Forms.TextFormatFlags]::SingleLine -bor
                 [Windows.Forms.TextFormatFlags]::NoPrefix
        [Windows.Forms.TextRenderer]::DrawText(
            $eventArgs.Graphics,
            [string]$sender.Text,
            $sender.Font,
            $sender.ClientRectangle,
            [Drawing.Color]::White,
            $flags
        )
    })
}

function New-NFGrid {
    $grid = New-Object Windows.Forms.DataGridView
    $grid.Dock = [Windows.Forms.DockStyle]::Fill
    $grid.AllowUserToAddRows = $false
    $grid.AllowUserToDeleteRows = $false
    $grid.AllowUserToOrderColumns = $false
    $grid.AllowUserToResizeRows = $false
    $grid.ReadOnly = $true
    $grid.MultiSelect = $false
    $grid.SelectionMode = [Windows.Forms.DataGridViewSelectionMode]::FullRowSelect
    $grid.RowHeadersVisible = $false
    $grid.AutoGenerateColumns = $false
    $grid.BorderStyle = if ($script:IsInProcessHosted) { [Windows.Forms.BorderStyle]::None } else { [Windows.Forms.BorderStyle]::FixedSingle }
    $grid.BackgroundColor = $script:CurrentPalette.Surface
    $grid.GridColor = $script:CurrentPalette.Border
    $grid.EnableHeadersVisualStyles = $false
    $grid.ColumnHeadersDefaultCellStyle.BackColor = $script:CurrentPalette.Card
    $grid.ColumnHeadersDefaultCellStyle.ForeColor = $script:CurrentPalette.Text
    $grid.ColumnHeadersDefaultCellStyle.Font = [Drawing.Font]::new("Segoe UI Semibold", 9)
    $grid.DefaultCellStyle.BackColor = $script:CurrentPalette.Surface
    $grid.DefaultCellStyle.ForeColor = $script:CurrentPalette.Text
    $grid.DefaultCellStyle.SelectionBackColor = $script:CurrentPalette.AccentStrong
    $grid.DefaultCellStyle.SelectionForeColor = $script:CurrentPalette.AccentText
    $grid.DefaultCellStyle.Font = [Drawing.Font]::new("Segoe UI", 9)
    $grid.RowTemplate.Height = 27
    $grid.ColumnHeadersHeight = 30
    return $grid
}

function Add-NFGridColumn {
    param($Grid, [string]$Name, [string]$Header, [int]$Width, [bool]$Fill = $false)
    $col = New-Object Windows.Forms.DataGridViewTextBoxColumn
    $col.Name = $Name
    $col.HeaderText = $Header
    $col.SortMode = [Windows.Forms.DataGridViewColumnSortMode]::NotSortable
    $col.MinimumWidth = [Math]::Min($Width, 70)
    if ($Fill) { $col.AutoSizeMode = [Windows.Forms.DataGridViewAutoSizeColumnMode]::Fill; $col.MinimumWidth = [Math]::Max(130, $Width) }
    else { $col.Width = $Width }
    [void]$Grid.Columns.Add($col)
}

function Save-NFStore {
    Write-NFEntradaStore -Store $script:Store -Path $script:DatabasePath
}

function Get-SelectedProduct {
    if ($mainTabs.SelectedTab -eq $computerTab) { return $script:ComputerProduct }
    if ($mainTabs.SelectedTab -eq $keyboardTab) { return $script:KeyboardProduct }
    return ""
}

function Get-SelectedRecordId {
    param([Windows.Forms.DataGridView]$Grid)
    if ($null -eq $Grid -or $Grid.SelectedRows.Count -eq 0) { return 0 }
    try { return [int]$Grid.SelectedRows[0].Cells["Id"].Value } catch { return 0 }
}

function Find-NFRecordById {
    param([string]$Product, [int]$Id)
    foreach ($r in Get-NFEntradaProductRecords -Store $script:Store -Product $Product) {
        if ([int]$r.Id -eq $Id) { return $r }
    }
    return $null
}

function Select-NFRecordInGrid {
    param([Windows.Forms.DataGridView]$Grid, [int]$Id)
    if ($null -eq $Grid -or $Id -le 0) { return $false }
    foreach ($row in @($Grid.Rows)) {
        try {
            if ([int]$row.Cells["Id"].Value -ne $Id) { continue }
            $Grid.ClearSelection()
            $row.Selected = $true
            if ($row.Cells["NFEntrada"].Visible) { $Grid.CurrentCell = $row.Cells["NFEntrada"] }
            try { $Grid.FirstDisplayedScrollingRowIndex = $row.Index } catch {}
            return $true
        } catch {}
    }
    return $false
}

function Clear-NFCurrentProductFilters {
    $product = Get-SelectedProduct
    if ([string]::IsNullOrWhiteSpace($product)) { return }
    if ($product -eq $script:ComputerProduct) {
        $computerFilter.Clear()
        $computerCodeFilter.SelectedIndex = 0
        $computerStatusFilter.SelectedItem = "Em estoque"
        $computerFilter.Focus()
    }
    else {
        $keyboardFilter.Clear()
        $keyboardCodeFilter.SelectedIndex = 0
        $keyboardStatusFilter.SelectedItem = "Em estoque"
        $keyboardFilter.Focus()
    }
    Set-NFStatus "Filtros restaurados para Em estoque e Todos os códigos." "Normal"
}

function Export-NFCurrentProductViewToCsv {
    $product = Get-SelectedProduct
    if ([string]::IsNullOrWhiteSpace($product)) { return }
    $grid = if ($product -eq $script:ComputerProduct) { $computerGrid } else { $keyboardGrid }
    $baseName = if ($product -eq $script:ComputerProduct) { "Estoque-CB5" } else { "Estoque-Teclado-V5" }
    $title = if ($product -eq $script:ComputerProduct) { "Lista de Computador de Bordo CB5" } else { "Lista de Teclado V5" }
    Export-NFGridViewToCsv -Grid $grid -BaseName $baseName -Title $title
}

function Format-NFDate {
    param([string]$Text)
    $date = [DateTime]::MinValue
    if ([DateTime]::TryParseExact($Text, "yyyy-MM-dd", [Globalization.CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::None, [ref]$date)) {
        return $date.ToString("dd/MM/yyyy")
    }
    return $Text
}

function Refresh-NFProductGrid {
    param(
        [string]$Product,
        [Windows.Forms.DataGridView]$Grid,
        [Windows.Forms.TextBox]$FilterBox,
        [Windows.Forms.ComboBox]$StatusFilter,
        [Windows.Forms.ComboBox]$CodeFilter,
        [Windows.Forms.Label]$CountLabel
    )
    $filter = if ($null -ne $FilterBox) { ([string]$FilterBox.Text).Trim().ToLowerInvariant() } else { "" }
    $selectedStatus = if ($null -ne $StatusFilter -and $StatusFilter.SelectedIndex -gt 0) { [string]$StatusFilter.SelectedItem } else { "Todos" }
    $selectedCode = if ($null -ne $CodeFilter -and $CodeFilter.SelectedIndex -gt 0) { [string]$CodeFilter.SelectedItem } else { "Todos" }
    $records = @(Get-NFEntradaProductRecords -Store $script:Store -Product $Product)
    $shown = 0
    $Grid.Rows.Clear()
    foreach ($record in $records) {
        $status = Get-NFEntradaRecordStatus -Record $record
        if ($selectedStatus -ne "Todos" -and $status -ne $selectedStatus) { continue }
        if ($selectedCode -ne "Todos" -and ([string]$record.Codigo) -ne $selectedCode) { continue }
        $search = (([string]$record.NFEntrada) + " " + ([string]$record.Codigo) + " " + ([string]$record.NFSaida) + " " + (Format-NFDate ([string]$record.Data)) + " " + $status).ToLowerInvariant()
        if (-not [string]::IsNullOrWhiteSpace($filter) -and -not $search.Contains($filter)) { continue }
        $index = $Grid.Rows.Add(
            [int]$record.Id,
            (Format-NFDate ([string]$record.Data)),
            [int]$record.QuantidadeNaNF,
            [string]$record.NFEntrada,
            [int]$record.QuantidadeSaldo,
            [string]$record.Codigo,
            $status,
            [string]$record.NFSaida
        )
        $shown++
        $row = $Grid.Rows[$index]
        switch ($status) {
            "Revisar" {
                $row.DefaultCellStyle.BackColor = $script:CurrentPalette.DangerBack
                $row.DefaultCellStyle.ForeColor = $script:CurrentPalette.Danger
            }
            "Encerrada" {
                $row.DefaultCellStyle.BackColor = $script:CurrentPalette.SuccessBack
                $row.DefaultCellStyle.ForeColor = $script:CurrentPalette.Success
            }
            default {
                $row.DefaultCellStyle.BackColor = $script:CurrentPalette.WarningBack
                $row.DefaultCellStyle.ForeColor = $script:CurrentPalette.Warning
            }
        }
    }
    if ($null -ne $CountLabel) { $CountLabel.Text = "$shown de $($records.Count)" }
    $Grid.ClearSelection()
}

function Format-NFHistoryDate {
    param([string]$Text)
    $date = [DateTime]::MinValue
    if ([DateTime]::TryParse($Text, [ref]$date)) { return $date.ToString("dd/MM/yyyy HH:mm:ss") }
    return $Text
}

function Refresh-NFMovements {
    if ($null -eq $movementGrid) { return }
    $filter = if ($null -ne $movementFilter) { ([string]$movementFilter.Text).Trim().ToLowerInvariant() } else { "" }
    $productFilter = if ($null -ne $movementProductFilter -and $movementProductFilter.SelectedIndex -gt 0) { [string]$movementProductFilter.SelectedItem } else { "Todos" }
    $periodFilter = if ($null -ne $movementPeriodFilter -and $movementPeriodFilter.SelectedIndex -gt 0) { [string]$movementPeriodFilter.SelectedItem } else { "Todos" }
    $items = @(Get-NFEntradaMovements -Store $script:Store)
    $movementGrid.Rows.Clear()
    $shown = 0
    $qtyShown = 0
    $reversedShown = 0
    $today = [DateTime]::Today
    foreach ($item in $items) {
        $when = [DateTime]::MinValue
        $hasDate = [DateTime]::TryParse([string]$item.DataHora, [ref]$when)
        if ($periodFilter -ne "Todos") {
            if (-not $hasDate) { continue }
            if ($periodFilter -eq "Hoje" -and $when -lt $today) { continue }
            if ($periodFilter -eq "Últimos 7 dias" -and $when -lt $today.AddDays(-6)) { continue }
            if ($periodFilter -eq "Últimos 30 dias" -and $when -lt $today.AddDays(-29)) { continue }
        }
        $displayProduct = Get-NFEntradaProductDisplayName ([string]$item.Produto)
        if ($productFilter -ne "Todos" -and $displayProduct -ne $productFilter) { continue }
        $status = Get-NFEntradaMovementStatus -Movement $item
        $search = (($displayProduct + " " + [string]$item.NFEntrada + " " + [string]$item.Referencia + " " + $status + " " + [string]$item.MotivoEstorno)).ToLowerInvariant()
        if (-not [string]::IsNullOrWhiteSpace($filter) -and -not $search.Contains($filter)) { continue }
        $rowIndex = $movementGrid.Rows.Add(
            [string]$item.Id,
            [string]$item.Produto,
            (Format-NFHistoryDate ([string]$item.DataHora)),
            $displayProduct,
            [string]$item.NFEntrada,
            [int]$item.Quantidade,
            [int]$item.SaldoAntes,
            [int]$item.SaldoDepois,
            $status,
            [string]$item.Referencia
        )
        $shown++
        if ($status -eq "Estornada") {
            $reversedShown++
            $row = $movementGrid.Rows[$rowIndex]
            $row.DefaultCellStyle.BackColor = $script:CurrentPalette.DangerBack
            $row.DefaultCellStyle.ForeColor = $script:CurrentPalette.Danger
        } else { $qtyShown += [int]$item.Quantidade }
    }
    $movementCountLabel.Text = "$shown movimentação(ões) • $qtyShown peça(s) ativas • $reversedShown estornada(s) • período: $periodFilter • Ctrl+Z estorna a selecionada"
    $movementGrid.ClearSelection()
    $movementOpenButton.Enabled = $false
    if ($null -ne $movementReverseButton) { $movementReverseButton.Enabled = $false }
}

function Open-NFFromMovement {
    if ($movementGrid.SelectedRows.Count -eq 0) { return }
    $row = $movementGrid.SelectedRows[0]
    $product = [string]$row.Cells["MovementProductKey"].Value
    $nf = [string]$row.Cells["MovementNF"].Value
    if ($product -eq $script:ComputerProduct) {
        $computerStatusFilter.SelectedIndex = 0
        $computerFilter.Text = $nf
        $mainTabs.SelectedTab = $computerTab
        $computerFilter.Focus()
    }
    elseif ($product -eq $script:KeyboardProduct) {
        $keyboardStatusFilter.SelectedIndex = 0
        $keyboardFilter.Text = $nf
        $mainTabs.SelectedTab = $keyboardTab
        $keyboardFilter.Focus()
    }
}

function Reverse-NFMovementFromUI {
    if ($movementGrid.SelectedRows.Count -eq 0) { return }
    $id = [string]$movementGrid.SelectedRows[0].Cells["MovementId"].Value
    $movement = Get-NFEntradaMovementById -Store $script:Store -MovementId $id
    if ($null -eq $movement) { return }
    if ((Get-NFEntradaMovementStatus -Movement $movement) -eq "Estornada") {
        [Windows.Forms.MessageBox]::Show("Esta saída já foi estornada e continua visível para auditoria.", "Controle de NF de Entrada", 0, 64) | Out-Null
        return
    }
    $answer = [Windows.Forms.MessageBox]::Show(
        "Estornar a saída de $([int]$movement.Quantidade) peça(s) da NF $([string]$movement.NFEntrada)?`r`n`r`nA quantidade voltará para o saldo. A movimentação original não será apagada e o estorno ficará registrado no Histórico.",
        "Confirmar estorno de saída",
        [Windows.Forms.MessageBoxButtons]::YesNo,
        [Windows.Forms.MessageBoxIcon]::Warning
    )
    if ($answer -ne [Windows.Forms.DialogResult]::Yes) { return }
    try {
        $result = Register-NFEntradaReversal -Store $script:Store -MovementId $id -Motivo "Correção operacional"
        Save-NFStore
        Refresh-NFAll
        Refresh-NFMovements
        Set-NFStatus ("Saída estornada. Saldo da NF " + [string]$result.Record.NFEntrada + ": " + [string]$result.Record.QuantidadeSaldo) "Warning"
    }
    catch { Set-NFStatus $_.Exception.Message "Error"; [Windows.Forms.MessageBox]::Show($_.Exception.Message, "Falha ao estornar saída", 0, 16) | Out-Null }
}

function ConvertTo-NFCsvField {
    param($Value)
    $text = if ($null -eq $Value) { "" } else { [string]$Value }
    return '"' + $text.Replace('"', '""') + '"'
}

function Export-NFGridViewToCsv {
    param(
        [Parameter(Mandatory = $true)][Windows.Forms.DataGridView]$Grid,
        [Parameter(Mandatory = $true)][string]$BaseName,
        [Parameter(Mandatory = $true)][string]$Title
    )
    if ($null -eq $Grid -or $Grid.Rows.Count -eq 0) {
        [Windows.Forms.MessageBox]::Show("Não há linhas visíveis para exportar.", "Controle de NF de Entrada", 0, 64) | Out-Null
        return
    }
    $columns = @($Grid.Columns | Where-Object { $_.Visible } | Sort-Object DisplayIndex)
    if ($columns.Count -eq 0) { return }

    $dialog = New-Object Windows.Forms.SaveFileDialog
    $dialog.Title = "Exportar $Title"
    $dialog.Filter = "Arquivo CSV (*.csv)|*.csv"
    $dialog.AddExtension = $true
    $dialog.DefaultExt = "csv"
    $dialog.FileName = $BaseName + "-" + [DateTime]::Now.ToString("yyyy-MM-dd-HHmm") + ".csv"
    try {
        if ($dialog.ShowDialog() -ne [Windows.Forms.DialogResult]::OK) { return }
        $lines = New-Object 'System.Collections.Generic.List[string]'
        $header = @($columns | ForEach-Object { ConvertTo-NFCsvField $_.HeaderText }) -join ";"
        [void]$lines.Add($header)
        foreach ($row in @($Grid.Rows)) {
            if ($row.IsNewRow) { continue }
            $values = foreach ($column in $columns) {
                ConvertTo-NFCsvField $row.Cells[$column.Index].Value
            }
            [void]$lines.Add((@($values) -join ";"))
        }
        $encoding = New-Object System.Text.UTF8Encoding($true)
        [IO.File]::WriteAllText($dialog.FileName, (($lines -join "`r`n") + "`r`n"), $encoding)
        Set-NFStatus ("$Title exportado(s) para " + $dialog.FileName) "Success"
        [Windows.Forms.MessageBox]::Show(
            "$Title exportado(s) com sucesso.`r`n`r`n$($dialog.FileName)`r`n`r`nForam exportadas apenas as linhas que estão visíveis com os filtros atuais.",
            "Exportação concluída",
            [Windows.Forms.MessageBoxButtons]::OK,
            [Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
    }
    catch {
        Set-NFStatus ("Falha ao exportar ${Title}: " + $_.Exception.Message) "Error"
        [Windows.Forms.MessageBox]::Show($_.Exception.Message, "Falha ao exportar CSV", 0, 16) | Out-Null
    }
    finally {
        $dialog.Dispose()
    }
}

function Get-NFHistoryEventById {
    param([string]$Id)
    foreach ($event in Get-NFEntradaHistory -Store $script:Store) {
        if ([string]$event.Id -eq $Id) { return $event }
    }
    return $null
}

function Convert-NFSnapshotToText {
    param($Snapshot)
    if ($null -eq $Snapshot) { return "—" }
    return @(
        "Data: " + (Format-NFDate ([string]$Snapshot.Data)),
        "Quantidade na NF: " + [string]$Snapshot.QuantidadeNaNF,
        "NF de Entrada: " + [string]$Snapshot.NFEntrada,
        "Saldo: " + [string]$Snapshot.QuantidadeSaldo,
        "Código: " + [string]$Snapshot.Codigo,
        "NF de Saída / movimentações: " + [string]$Snapshot.NFSaida
    ) -join "`r`n"
}

function Get-NFHistoryActionLabel {
    param([string]$Type)
    $label = switch ($Type) {
        "Adicao" { "Adição" }
        "Edicao" { "Edição" }
        "Exclusao" { "Exclusão" }
        "Importacao" { "Importação" }
        "RestauracaoBackup" { "Restauração" }
        "Saida" { "Saída" }
        "EstornoSaida" { "Estorno de saída" }
        "Exportacao" { "Exportação" }
        default { $Type }
    }
    return $label
}

function Refresh-NFHistory {
    if ($null -eq $historyGrid) { return }
    $filter = if ($null -ne $historyFilter) { ([string]$historyFilter.Text).Trim().ToLowerInvariant() } else { "" }
    $type = if ($null -ne $historyTypeFilter -and $historyTypeFilter.SelectedIndex -gt 0) { [string]$historyTypeFilter.SelectedItem } else { "Todos" }
    $period = if ($null -ne $historyPeriodFilter -and $historyPeriodFilter.SelectedIndex -gt 0) { [string]$historyPeriodFilter.SelectedItem } else { "Todos" }
    $events = @(Get-NFEntradaHistory -Store $script:Store)
    $shown = 0
    $today = [DateTime]::Today
    $historyGrid.Rows.Clear()
    foreach ($event in $events) {
        $when = [DateTime]::MinValue
        $hasDate = [DateTime]::TryParse([string]$event.DataHora, [ref]$when)
        if ($period -ne "Todos") {
            if (-not $hasDate) { continue }
            if ($period -eq "Hoje" -and $when -lt $today) { continue }
            if ($period -eq "Últimos 7 dias" -and $when -lt $today.AddDays(-6)) { continue }
            if ($period -eq "Últimos 30 dias" -and $when -lt $today.AddDays(-29)) { continue }
        }
        $label = Get-NFHistoryActionLabel ([string]$event.Tipo)
        if ($type -ne "Todos" -and $label -ne $type) { continue }
        $search = (($label + " " + (Get-NFEntradaProductDisplayName ([string]$event.Produto)) + " " + [string]$event.NFEntrada + " " + [string]$event.Detalhes)).ToLowerInvariant()
        if (-not [string]::IsNullOrWhiteSpace($filter) -and -not $search.Contains($filter)) { continue }
        [void]$historyGrid.Rows.Add([string]$event.Id, (Format-NFHistoryDate ([string]$event.DataHora)), $label, (Get-NFEntradaProductDisplayName ([string]$event.Produto)), [string]$event.NFEntrada, [string]$event.Detalhes)
        $shown++
    }
    $historyCountLabel.Text = "$shown de $($events.Count) • $period"
    $historyGrid.ClearSelection()
    $historyDetailsButton.Enabled = $false
}

function Show-NFHistoryDetails {
    if ($historyGrid.SelectedRows.Count -eq 0) { return }
    $id = [string]$historyGrid.SelectedRows[0].Cells["HistoryId"].Value
    $event = Get-NFHistoryEventById -Id $id
    if ($null -eq $event) { return }
    $dialog = New-Object Windows.Forms.Form
    $dialog.Text = "Detalhes do histórico"
    $dialog.StartPosition = [Windows.Forms.FormStartPosition]::CenterParent
    $dialog.Size = [Drawing.Size]::new(760, 590)
    $dialog.MinimumSize = [Drawing.Size]::new(680, 520)
    $dialog.BackColor = $script:CurrentPalette.Background
    $dialog.ForeColor = $script:CurrentPalette.Text
    $layout = New-Object Windows.Forms.TableLayoutPanel
    $layout.Dock = [Windows.Forms.DockStyle]::Fill
    $layout.Padding = [Windows.Forms.Padding]::new(18)
    $layout.RowCount = 4
    [void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Absolute, 74)))
    [void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Percent, 50)))
    [void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Percent, 50)))
    [void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Absolute, 44)))
    $dialog.Controls.Add($layout)
    $headerText = New-Object Windows.Forms.Label
    $headerText.Text = (Format-NFHistoryDate ([string]$event.DataHora)) + "  •  " + (Get-NFHistoryActionLabel ([string]$event.Tipo)) + "`r`nNF: " + [string]$event.NFEntrada + "    Produto: " + (Get-NFEntradaProductDisplayName ([string]$event.Produto)) + $(if ([string]::IsNullOrWhiteSpace([string]$event.Detalhes)) { "" } else { "`r`n" + [string]$event.Detalhes })
    $headerText.Dock = [Windows.Forms.DockStyle]::Fill
    $headerText.ForeColor = $script:CurrentPalette.Text
    $layout.Controls.Add($headerText, 0, 0)
    foreach ($item in @(@("ANTES", $event.Antes), @("DEPOIS", $event.Depois))) {
        $box = New-Object Windows.Forms.GroupBox
        $box.Text = $item[0]
        $box.Dock = [Windows.Forms.DockStyle]::Fill
        $box.ForeColor = $script:CurrentPalette.Text
        $text = New-Object Windows.Forms.TextBox
        $text.Multiline = $true
        $text.ReadOnly = $true
        $text.ScrollBars = [Windows.Forms.ScrollBars]::Vertical
        $text.Dock = [Windows.Forms.DockStyle]::Fill
        $text.BackColor = $script:CurrentPalette.Input
        $text.ForeColor = $script:CurrentPalette.Text
        $text.Text = Convert-NFSnapshotToText $item[1]
        $box.Controls.Add($text)
        $layout.Controls.Add($box, 0, $(if ($item[0] -eq "ANTES") { 1 } else { 2 }))
    }
    $close = New-Object Windows.Forms.Button
    $close.Text = "FECHAR"
    $close.Width = 100
    $close.DialogResult = [Windows.Forms.DialogResult]::OK
    Set-NFButtonStyle $close "Secondary"
    $layout.Controls.Add($close, 0, 3)
    $dialog.AcceptButton = $close
    [void]$dialog.ShowDialog()
    $dialog.Dispose()
}

function Show-NFReviewIssues {
    $items = @(Get-NFEntradaReviewItems -Store $script:Store)
    if ($items.Count -eq 0) {
        [Windows.Forms.MessageBox]::Show(
            "Nenhuma pendência de conferência foi encontrada na base atual.",
            "Conferência do Controle de NF",
            [Windows.Forms.MessageBoxButtons]::OK,
            [Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
        return
    }

    $dialog = New-Object Windows.Forms.Form
    $dialog.Text = "Pendências de conferência"
    $dialog.StartPosition = [Windows.Forms.FormStartPosition]::CenterParent
    $dialog.Size = [Drawing.Size]::new(900, 540)
    $dialog.MinimumSize = [Drawing.Size]::new(760, 460)
    $dialog.BackColor = $script:CurrentPalette.Background
    $dialog.ForeColor = $script:CurrentPalette.Text

    $layout = New-Object Windows.Forms.TableLayoutPanel
    $layout.Dock = [Windows.Forms.DockStyle]::Fill
    $layout.Padding = [Windows.Forms.Padding]::new(14)
    $layout.RowCount = 3
    [void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Absolute, 48)))
    [void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Percent, 100)))
    [void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Absolute, 46)))
    $dialog.Controls.Add($layout)

    $info = New-Object Windows.Forms.Label
    $info.Text = "$($items.Count) registro(s) precisam de conferência. Selecione uma linha e use ABRIR NF para ir ao registro."
    $info.Dock = [Windows.Forms.DockStyle]::Fill
    $info.TextAlign = [Drawing.ContentAlignment]::MiddleLeft
    $info.ForeColor = $script:CurrentPalette.Muted
    $layout.Controls.Add($info, 0, 0)

    $reviewGrid = New-NFGrid
    $productKey = New-Object Windows.Forms.DataGridViewTextBoxColumn
    $productKey.Name = "ReviewProductKey"; $productKey.Visible = $false; [void]$reviewGrid.Columns.Add($productKey)
    $recordKey = New-Object Windows.Forms.DataGridViewTextBoxColumn
    $recordKey.Name = "ReviewRecordId"; $recordKey.Visible = $false; [void]$reviewGrid.Columns.Add($recordKey)
    Add-NFGridColumn $reviewGrid "ReviewProduct" "PRODUTO" 190
    Add-NFGridColumn $reviewGrid "ReviewNF" "NF DE ENTRADA" 120
    Add-NFGridColumn $reviewGrid "ReviewQty" "QTD. NA NF" 90
    Add-NFGridColumn $reviewGrid "ReviewBalance" "SALDO" 80
    Add-NFGridColumn $reviewGrid "ReviewCode" "CÓD." 70
    Add-NFGridColumn $reviewGrid "ReviewIssue" "PENDÊNCIA" 240 $true
    foreach ($item in $items) {
        [void]$reviewGrid.Rows.Add(
            [string]$item.Produto,
            [int]$item.RegistroId,
            (Get-NFEntradaProductDisplayName ([string]$item.Produto)),
            [string]$item.NFEntrada,
            [int]$item.QuantidadeNaNF,
            [int]$item.QuantidadeSaldo,
            [string]$item.Codigo,
            [string]$item.Problema
        )
    }
    $reviewGrid.ClearSelection()
    $layout.Controls.Add($reviewGrid, 0, 1)

    $buttons = New-Object Windows.Forms.FlowLayoutPanel
    $buttons.Dock = [Windows.Forms.DockStyle]::Fill
    $buttons.FlowDirection = [Windows.Forms.FlowDirection]::RightToLeft
    $close = New-Object Windows.Forms.Button
    $close.Text = "FECHAR"; $close.Width = 100; $close.Height = 32; $close.DialogResult = [Windows.Forms.DialogResult]::Cancel
    Set-NFButtonStyle $close "Secondary"
    $open = New-Object Windows.Forms.Button
    $open.Text = "ABRIR NF"; $open.Width = 110; $open.Height = 32; $open.Enabled = $false
    Set-NFButtonStyle $open "Primary"
    $buttons.Controls.Add($close); $buttons.Controls.Add($open)
    $layout.Controls.Add($buttons, 0, 2)
    $dialog.CancelButton = $close

    $reviewGrid.Add_SelectionChanged({ $open.Enabled = ($reviewGrid.SelectedRows.Count -gt 0) })
    $open.Add_Click({
        if ($reviewGrid.SelectedRows.Count -eq 0) { return }
        $dialog.Tag = [pscustomobject]@{
            Produto = [string]$reviewGrid.SelectedRows[0].Cells["ReviewProductKey"].Value
            NFEntrada = [string]$reviewGrid.SelectedRows[0].Cells["ReviewNF"].Value
        }
        $dialog.DialogResult = [Windows.Forms.DialogResult]::OK
        $dialog.Close()
    })
    $reviewGrid.Add_CellDoubleClick({
        if ($_.RowIndex -lt 0) { return }
        $dialog.Tag = [pscustomobject]@{
            Produto = [string]$reviewGrid.Rows[$_.RowIndex].Cells["ReviewProductKey"].Value
            NFEntrada = [string]$reviewGrid.Rows[$_.RowIndex].Cells["ReviewNF"].Value
        }
        $dialog.DialogResult = [Windows.Forms.DialogResult]::OK
        $dialog.Close()
    })

    $result = $dialog.ShowDialog()
    $target = $dialog.Tag
    $dialog.Dispose()
    if ($result -ne [Windows.Forms.DialogResult]::OK -or $null -eq $target) { return }

    if ([string]$target.Produto -eq $script:ComputerProduct) {
        $computerStatusFilter.SelectedIndex = 0
        $computerFilter.Text = [string]$target.NFEntrada
        $mainTabs.SelectedTab = $computerTab
        $computerFilter.Focus()
    }
    elseif ([string]$target.Produto -eq $script:KeyboardProduct) {
        $keyboardStatusFilter.SelectedIndex = 0
        $keyboardFilter.Text = [string]$target.NFEntrada
        $mainTabs.SelectedTab = $keyboardTab
        $keyboardFilter.Focus()
    }
}

function Show-NFExportReadiness {
    $state = Get-NFEntradaExportReadiness -Store $script:Store -DataDirectory $script:DataDirectory
    $model = if ($state.ModeloDisponivel) { "OK — modelo oficial disponível" } else { "AUSENTE — importe a planilha oficial novamente" }
    $statusText = switch ([string]$state.Situacao) {
        "PRONTO" { "A exportação está pronta. O modelo oficial comporta os registros atuais e não há pendências de conferência." }
        "REVISAR" { "A exportação pode ser feita, mas existem pendências de conferência. O programa pedirá confirmação antes de gerar o Excel." }
        default { "A exportação está bloqueada para não quebrar o formato oficial. Corrija o motivo indicado antes de tentar novamente." }
    }
    $details = @(
        "Situação: " + [string]$state.Situacao,
        "Modelo: " + $model,
        "Computador de bordo CB5: " + [string]$state.RegistrosComputador + " de " + [string]$state.CapacidadePorProduto + " registros (restam " + [string]$state.RestanteComputador + ")",
        "Teclado V5: " + [string]$state.RegistrosTeclado + " de " + [string]$state.CapacidadePorProduto + " registros (restam " + [string]$state.RestanteTeclado + ")",
        "Pendências para revisar: " + [string]$state.Pendencias,
        "",
        $statusText
    ) -join "`r`n"
    $icon = if ($state.Situacao -eq "PRONTO") { [Windows.Forms.MessageBoxIcon]::Information } elseif ($state.Situacao -eq "REVISAR") { [Windows.Forms.MessageBoxIcon]::Warning } else { [Windows.Forms.MessageBoxIcon]::Error }
    [Windows.Forms.MessageBox]::Show($details, "Conferir exportação", [Windows.Forms.MessageBoxButtons]::OK, $icon) | Out-Null
}

function Show-NFIntegrityReport {
    try {
        $report = Get-NFEntradaIntegrityReport -Store $script:Store -DataDirectory $script:DataDirectory
        $lines = [Collections.Generic.List[string]]::new()
        [void]$lines.Add("Situação: " + [string]$report.Situacao)
        [void]$lines.Add("Registros: " + [string]$report.Registros + " • Pendências: " + [string]$report.Pendencias + " • Duplicidades: " + [string]$report.Duplicidades)
        [void]$lines.Add("Backups: " + [string]$report.Backups + " • Automáticos: " + [string]$report.BackupsAutomaticos + " • Inválidos: " + [string]$report.BackupsInvalidos)
        [void]$lines.Add("")
        foreach ($error in @($report.Erros)) { [void]$lines.Add("ERRO • " + [string]$error) }
        foreach ($warning in @($report.Avisos)) { [void]$lines.Add("ATENÇÃO • " + [string]$warning) }
        if (@($report.Erros).Count -eq 0 -and @($report.Avisos).Count -eq 0) {
            [void]$lines.Add("Nenhuma inconsistência foi encontrada na base, no modelo e nos backups atuais.")
        }
        $icon = if ($report.Situacao -eq "ERRO") { [Windows.Forms.MessageBoxIcon]::Error } elseif ($report.Situacao -eq "ATENÇÃO") { [Windows.Forms.MessageBoxIcon]::Warning } else { [Windows.Forms.MessageBoxIcon]::Information }
        [Windows.Forms.MessageBox]::Show(($lines -join "`r`n"), "Verificação de integridade", [Windows.Forms.MessageBoxButtons]::OK, $icon) | Out-Null
        $statusKind = "Success"
        if ($report.Situacao -eq "ERRO") { $statusKind = "Error" }
        elseif ($report.Situacao -eq "ATENÇÃO") { $statusKind = "Warning" }
        Set-NFStatus ("Integridade: " + [string]$report.Situacao + " • " + [string]$report.Erros.Count + " erro(s) • " + [string]$report.Avisos.Count + " aviso(s)") $statusKind
    }
    catch {
        Set-NFStatus $_.Exception.Message "Error"
        [Windows.Forms.MessageBox]::Show($_.Exception.Message, "Falha na verificação de integridade", 0, 16) | Out-Null
    }
}

function Refresh-NFBackups {
    if ($null -eq $backupGrid) { return }
    $items = @(Get-NFEntradaSafetyBackups -DataDirectory $script:DataDirectory)
    $backupGrid.Rows.Clear()
    foreach ($item in $items) {
        $content = if ($item.TemBase -and $item.TemModelo) { "Base + modelo" } elseif ($item.TemBase) { "Somente base" } else { "Incompleto" }
        [void]$backupGrid.Rows.Add([string]$item.Directory, $item.DataHora.ToString("dd/MM/yyyy HH:mm:ss"), [string]$item.Motivo, [int]$item.Registros, $content, [string]$item.Situacao)
    }
    $backupCountLabel.Text = "$($items.Count) backup(s) disponível(is)"
    $backupGrid.ClearSelection()
    $restoreBackupButton.Enabled = $false
}

function New-NFManualBackupFromUI {
    try {
        $backup = New-NFEntradaSafetyBackup -DataDirectory $script:DataDirectory -Reason "Manual"
        if ($null -eq $backup) { throw "Ainda não há base ou modelo para criar backup." }
        Refresh-NFBackups
        Set-NFStatus "Backup manual criado com sucesso." "Success"
        [Windows.Forms.MessageBox]::Show("Backup criado com sucesso.`r`n`r`nA base e o modelo atual foram preservados em uma cópia de segurança interna.", "Controle de NF de Entrada", 0, 64) | Out-Null
    }
    catch { Set-NFStatus $_.Exception.Message "Error"; [Windows.Forms.MessageBox]::Show($_.Exception.Message, "Falha ao criar backup", 0, 16) | Out-Null }
}

function Restore-NFBackupFromUI {
    if ($backupGrid.SelectedRows.Count -eq 0) { return }
    $directory = [string]$backupGrid.SelectedRows[0].Cells["BackupDirectory"].Value
    $dateText = [string]$backupGrid.SelectedRows[0].Cells["BackupDate"].Value
    $answer = [Windows.Forms.MessageBox]::Show(
        "Restaurar o backup de $dateText?`r`n`r`nO estado atual será copiado automaticamente para um novo backup antes da restauração. Depois da confirmação, a base ativa e o modelo Excel passarão a refletir o backup selecionado.",
        "Confirmar restauração de backup",
        [Windows.Forms.MessageBoxButtons]::YesNo,
        [Windows.Forms.MessageBoxIcon]::Warning
    )
    if ($answer -ne [Windows.Forms.DialogResult]::Yes) { return }
    try {
        Set-NFStatus "Restaurando backup e protegendo o estado atual..." "Warning"
        $result = Restore-NFEntradaBackupSet -BackupDirectory $directory -DataDirectory $script:DataDirectory
        $script:DatabasePath = [string]$result.StorePath
        $script:Store = $result.Store
        Refresh-NFAll
        Set-NFStatus "Backup restaurado com sucesso; estado anterior também foi preservado." "Success"
        [Windows.Forms.MessageBox]::Show("Backup restaurado com sucesso.`r`n`r`nO estado que estava ativo antes da restauração também foi salvo automaticamente, permitindo recuperação caso seja necessário.", "Controle de NF de Entrada", 0, 64) | Out-Null
    }
    catch { Set-NFStatus $_.Exception.Message "Error"; [Windows.Forms.MessageBox]::Show($_.Exception.Message, "Falha ao restaurar backup", 0, 16) | Out-Null }
}

function Refresh-NFSummary {
    $summary = Get-NFEntradaSummary -Store $script:Store
    $operational = Get-NFEntradaOperationalMetrics -Store $script:Store
    $exportState = Get-NFEntradaExportReadiness -Store $script:Store -DataDirectory $script:DataDirectory
    $saldoTotalValue.Text = ([int]$summary.SaldoTotal).ToString("N0")
    $computerBalanceValue.Text = ([int]$summary.Produtos[$script:ComputerProduct].Saldo).ToString("N0")
    $keyboardBalanceValue.Text = ([int]$summary.Produtos[$script:KeyboardProduct].Saldo).ToString("N0")
    $openNFsValue.Text = ([int]$summary.NFsAbertas).ToString("N0")
    $movementTodayValue.Text = ([int]$operational.MovimentacoesHoje).ToString("N0")
    $piecesTodayValue.Text = ([int]$operational.PecasSaidaHoje).ToString("N0")
    $piecesSevenValue.Text = ([int]$operational.PecasSaida7Dias).ToString("N0")
    $reviewIssuesValue.Text = ([int]$operational.Pendencias).ToString("N0")
    $reviewIssuesValue.ForeColor = if ([int]$operational.Pendencias -eq 0) { $script:CurrentPalette.Success } else { $script:CurrentPalette.Danger }
    $reviewIssuesButton.Enabled = ([int]$operational.Pendencias -gt 0)
    $exportStatusValue.Text = [string]$exportState.Situacao
    $exportStatusValue.ForeColor = if ($exportState.Situacao -eq "PRONTO") { $script:CurrentPalette.Success } elseif ($exportState.Situacao -eq "REVISAR") { $script:CurrentPalette.Warning } else { $script:CurrentPalette.Danger }
    if ($null -ne $operational.UltimaMovimentacaoEm) {
        $lastMovementValue.Text = ([DateTime]$operational.UltimaMovimentacaoEm).ToString("dd/MM HH:mm") + " • NF " + [string]$operational.UltimaMovimentacaoNF
    }
    else {
        $lastMovementValue.Text = "Nenhuma movimentação registrada"
    }

    $productSummaryGrid.Rows.Clear()
    [void]$productSummaryGrid.Rows.Add("Computador de bordo CB5", [int]$summary.Produtos[$script:ComputerProduct].NFsAbertas, [int]$summary.Produtos[$script:ComputerProduct].Saldo)
    [void]$productSummaryGrid.Rows.Add("Teclado V5", [int]$summary.Produtos[$script:KeyboardProduct].NFsAbertas, [int]$summary.Produtos[$script:KeyboardProduct].Saldo)
    [void]$productSummaryGrid.Rows.Add("TOTAL", [int]$summary.NFsAbertas, [int]$summary.SaldoTotal)

    $codeSummaryGrid.Rows.Clear()
    foreach ($code in @("800", "100", "850", "Garantia")) {
        $item = $summary.Codigos[$code]
        [void]$codeSummaryGrid.Rows.Add($code, [int]$item.Computador, [int]$item.Teclado, [int]$item.Total)
        $cv=$script:NFCodeCardValues[$code]
        if($null -ne $cv){
            $cv.Computador.Text="CB5: "+([int]$item.Computador).ToString("N0")
            $cv.Teclado.Text="TV5: "+([int]$item.Teclado).ToString("N0")
            $cv.Total.Text="TOTAL: "+([int]$item.Total).ToString("N0")
        }
    }
    [void]$codeSummaryGrid.Rows.Add("TOTAL", [int]$summary.Produtos[$script:ComputerProduct].Saldo, [int]$summary.Produtos[$script:KeyboardProduct].Saldo, [int]$summary.SaldoTotal)

    $missingDateValue.Text = [string][int]$summary.DatasAusentes
    $negativeValue.Text = [string][int]$summary.SaldosNegativos
    $overEntryValue.Text = [string][int]$summary.SaldoMaiorQueEntrada
    $generalStatusValue.Text = [string]$summary.Situacao
    $generalStatusValue.ForeColor = if ($summary.Situacao -eq "OK") { $script:CurrentPalette.Success } else { $script:CurrentPalette.Danger }
    $computerTab.Text = "COMPUTADOR DE BORDO CB5 ($([int]$summary.Produtos[$script:ComputerProduct].Registros))"
    $keyboardTab.Text = "TECLADO V5 ($([int]$summary.Produtos[$script:KeyboardProduct].Registros))"
    if ($null -ne $script:NFComputerNavButton) { $script:NFComputerNavButton.Text = "COMPUTADOR CB5 ($([int]$summary.Produtos[$script:ComputerProduct].Registros))" }
    if ($null -ne $script:NFKeyboardNavButton) { $script:NFKeyboardNavButton.Text = $keyboardTab.Text }
}

function Refresh-NFAll {
    Refresh-NFSummary
    Refresh-NFProductGrid -Product $script:ComputerProduct -Grid $computerGrid -FilterBox $computerFilter -StatusFilter $computerStatusFilter -CodeFilter $computerCodeFilter -CountLabel $computerCountLabel
    Refresh-NFProductGrid -Product $script:KeyboardProduct -Grid $keyboardGrid -FilterBox $keyboardFilter -StatusFilter $keyboardStatusFilter -CodeFilter $keyboardCodeFilter -CountLabel $keyboardCountLabel
    if ($mainTabs.SelectedTab -eq $movementTab) { Refresh-NFMovements }
    if ($mainTabs.SelectedTab -eq $historyTab) { Refresh-NFHistory }
    if ($mainTabs.SelectedTab -eq $securityTab) { Refresh-NFBackups }
    $exportReadiness = Get-NFEntradaExportReadiness -Store $script:Store -DataDirectory $script:DataDirectory
    $exportButton.Enabled = $true
    $summary = Get-NFEntradaSummary -Store $script:Store
    $totalRecords = [int]$summary.Produtos[$script:ComputerProduct].Registros + [int]$summary.Produtos[$script:KeyboardProduct].Registros
    Set-NFStatus ("Pronto • " + $totalRecords + " registro(s)") "Normal"
}

function Show-NFRecordDialog {
    param([string]$Product, $Existing = $null, [string]$DefaultDate = "", [string]$DefaultCode = "800")
    $dialog = New-Object Windows.Forms.Form
    $displayProduct = Get-NFEntradaProductDisplayName $Product
    $dialog.Text = if ($null -eq $Existing) { "Novo registro — $displayProduct" } else { "Editar registro — $displayProduct" }
    $dialog.StartPosition = [Windows.Forms.FormStartPosition]::CenterParent
    $dialog.FormBorderStyle = [Windows.Forms.FormBorderStyle]::FixedDialog
    $dialog.MaximizeBox = $false
    $dialog.MinimizeBox = $false
    $dialog.ShowInTaskbar = $false
    $dialog.ClientSize = [Drawing.Size]::new(620, 480)
    $dialog.BackColor = $script:CurrentPalette.Background
    $dialog.ForeColor = $script:CurrentPalette.Text

    $layout = New-Object Windows.Forms.TableLayoutPanel
    $layout.Dock = [Windows.Forms.DockStyle]::Fill
    $layout.Padding = [Windows.Forms.Padding]::new(18)
    $layout.ColumnCount = 2
    $layout.RowCount = 8
    [void]$layout.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Absolute, 180)))
    [void]$layout.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent, 100)))
    foreach ($i in 0..5) { [void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Absolute, $(if ($i -eq 5) { 112 } else { 44 })))) }
    [void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Absolute, 44)))
    [void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Percent, 100)))
    $dialog.Controls.Add($layout)

    function Add-DialogLabel([string]$text, [int]$row) {
        $label = New-Object Windows.Forms.Label
        $label.Text = $text
        $label.Dock = [Windows.Forms.DockStyle]::Fill
        $label.TextAlign = [Drawing.ContentAlignment]::MiddleLeft
        $label.Font = [Drawing.Font]::new("Segoe UI Semibold", 9)
        $label.ForeColor = $script:CurrentPalette.Text
        $layout.Controls.Add($label, 0, $row)
    }

    Add-DialogLabel "Data" 0
    $datePicker = New-Object Windows.Forms.DateTimePicker
    $datePicker.Format = [Windows.Forms.DateTimePickerFormat]::Custom
    $datePicker.CustomFormat = "dd/MM/yyyy"
    $datePicker.Dock = [Windows.Forms.DockStyle]::Fill
    $layout.Controls.Add($datePicker, 1, 0)

    Add-DialogLabel "Quantidade na NF" 1
    $qtyBox = New-Object Windows.Forms.NumericUpDown
    $qtyBox.Minimum = 1
    $qtyBox.Maximum = 1000000
    $qtyBox.Dock = [Windows.Forms.DockStyle]::Fill
    $layout.Controls.Add($qtyBox, 1, 1)

    Add-DialogLabel "NF de Entrada" 2
    $nfBox = New-Object Windows.Forms.TextBox
    $nfBox.Dock = [Windows.Forms.DockStyle]::Fill
    $nfBox.MaxLength = 30
    $layout.Controls.Add($nfBox, 1, 2)

    Add-DialogLabel "Quantidade no Saldo" 3
    $balanceBox = New-Object Windows.Forms.NumericUpDown
    $balanceBox.Minimum = 0
    $balanceBox.Maximum = 1000000
    $balanceBox.Dock = [Windows.Forms.DockStyle]::Fill
    $layout.Controls.Add($balanceBox, 1, 3)

    Add-DialogLabel "Código" 4
    $codeCombo = New-Object Windows.Forms.ComboBox
    $codeCombo.DropDownStyle = [Windows.Forms.ComboBoxStyle]::DropDownList
    [void]$codeCombo.Items.AddRange(@("800", "100", "850", "Garantia"))
    $codeCombo.Dock = [Windows.Forms.DockStyle]::Fill
    $layout.Controls.Add($codeCombo, 1, 4)

    Add-DialogLabel "NF de Saída / movimentações (automático)" 5
    $outBox = New-Object Windows.Forms.TextBox
    $outBox.Multiline = $true
    $outBox.ScrollBars = [Windows.Forms.ScrollBars]::Vertical
    $outBox.Dock = [Windows.Forms.DockStyle]::Fill
    $outBox.ReadOnly = $true
    $outBox.TabStop = $false
    $outBox.BackColor = $script:CurrentPalette.Surface
    $layout.Controls.Add($outBox, 1, 5)

    $validationLabel = New-Object Windows.Forms.Label
    $validationLabel.Text = "Preencha os dados para validar o registro."
    $validationLabel.Dock = [Windows.Forms.DockStyle]::Fill
    $validationLabel.TextAlign = [Drawing.ContentAlignment]::MiddleLeft
    $validationLabel.ForeColor = $script:CurrentPalette.Muted
    $layout.SetColumnSpan($validationLabel, 2)
    $layout.Controls.Add($validationLabel, 0, 6)

    $buttons = New-Object Windows.Forms.FlowLayoutPanel
    $buttons.FlowDirection = [Windows.Forms.FlowDirection]::RightToLeft
    $buttons.Dock = [Windows.Forms.DockStyle]::Fill
    $buttons.Padding = [Windows.Forms.Padding]::new(0, 12, 0, 0)
    $layout.SetColumnSpan($buttons, 2)
    $layout.Controls.Add($buttons, 0, 7)

    $cancel = New-Object Windows.Forms.Button
    $cancel.Text = "CANCELAR"
    $cancel.Width = 110
    $cancel.Height = 34
    $cancel.DialogResult = [Windows.Forms.DialogResult]::Cancel
    Set-NFButtonStyle $cancel "Secondary"
    $buttons.Controls.Add($cancel)

    $save = New-Object Windows.Forms.Button
    $save.Text = "SALVAR"
    $save.Width = 110
    $save.Height = 34
    $save.DialogResult = [Windows.Forms.DialogResult]::OK
    Set-NFButtonStyle $save "Primary"
    $buttons.Controls.Add($save)

    $saveAndNew = $null
    if ($null -eq $Existing) {
        $saveAndNew = New-Object Windows.Forms.Button
        $saveAndNew.Text = "SALVAR E NOVA"
        $saveAndNew.Width = 135
        $saveAndNew.Height = 34
        $saveAndNew.DialogResult = [Windows.Forms.DialogResult]::Retry
        Set-NFButtonStyle $saveAndNew "Secondary"
        $buttons.Controls.Add($saveAndNew)
    }
    $dialog.AcceptButton = $save
    $dialog.CancelButton = $cancel

    foreach ($control in @($datePicker, $qtyBox, $nfBox, $balanceBox, $codeCombo, $outBox)) {
        try { $control.BackColor = $script:CurrentPalette.Input; $control.ForeColor = $script:CurrentPalette.Text } catch {}
    }

    if ($null -ne $Existing) {
        $date = [DateTime]::MinValue
        if ([DateTime]::TryParseExact([string]$Existing.Data, "yyyy-MM-dd", [Globalization.CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::None, [ref]$date)) { $datePicker.Value = $date }
        $qtyBox.Value = [Math]::Max($qtyBox.Minimum, [Math]::Min($qtyBox.Maximum, [decimal][int]$Existing.QuantidadeNaNF))
        $nfBox.Text = [string]$Existing.NFEntrada
        $balanceBox.Value = [Math]::Max($balanceBox.Minimum, [Math]::Min($balanceBox.Maximum, [decimal][int]$Existing.QuantidadeSaldo))
        if ($codeCombo.Items.Contains([string]$Existing.Codigo)) { $codeCombo.SelectedItem = [string]$Existing.Codigo }
        $outBox.Text = [string]$Existing.NFSaida
    }
    else {
        $defaultParsed = [DateTime]::MinValue
        if (-not [string]::IsNullOrWhiteSpace($DefaultDate) -and [DateTime]::TryParseExact($DefaultDate, "yyyy-MM-dd", [Globalization.CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::None, [ref]$defaultParsed)) { $datePicker.Value = $defaultParsed }
        else { $datePicker.Value = [DateTime]::Today }
        $qtyBox.Value = 1
        $balanceBox.Value = $qtyBox.Value
        $codeCombo.SelectedItem = if ($codeCombo.Items.Contains($DefaultCode)) { $DefaultCode } else { "800" }
    }

    $ignoreId = if ($null -ne $Existing) { [int]$Existing.Id } else { 0 }

    # Dependências do módulo capturadas localmente para o GetNewClosure.
    $dialogStore = $script:Store
    $dialogPalette = $script:CurrentPalette
    if ($null -eq $dialogPalette) {
        $dialogPalette = Get-NFEntradaPalette (Get-NFEntradaHostedCentralTheme)
    }
    $validateDialog = {
        $candidate = [pscustomobject]@{
            Data = $datePicker.Value.ToString("yyyy-MM-dd")
            QuantidadeNaNF = [int]$qtyBox.Value
            NFEntrada = ([string]$nfBox.Text).Trim()
            QuantidadeSaldo = [int]$balanceBox.Value
            Codigo = [string]$codeCombo.SelectedItem
            NFSaida = ([string]$outBox.Text).Trim()
        }
        try {
            [void](Test-NFEntradaRecord -Record $candidate -Store $dialogStore -Product $Product -IgnoreId $ignoreId)
            $validationLabel.Text = if ($null -eq $Existing) { "Pronto para salvar. O saldo inicial acompanha a quantidade da NF." } else { "Registro válido e pronto para salvar." }
            $validationLabel.ForeColor = $dialogPalette.Success
            $save.Enabled = $true
            if ($null -ne $saveAndNew) { $saveAndNew.Enabled = $true }
        } catch {
            $validationLabel.Text = $_.Exception.Message
            $validationLabel.ForeColor = $dialogPalette.Danger
            $save.Enabled = $false
            if ($null -ne $saveAndNew) { $saveAndNew.Enabled = $false }
        }
    }.GetNewClosure()

    $qtyBox.Add_ValueChanged({ if ($null -eq $Existing) { $balanceBox.Value = $qtyBox.Value }; & $validateDialog }.GetNewClosure())
    $datePicker.Add_ValueChanged($validateDialog)
    $nfBox.Add_TextChanged($validateDialog)
    $balanceBox.Add_ValueChanged($validateDialog)
    $codeCombo.Add_SelectedIndexChanged($validateDialog)
    [void](& $validateDialog)
    $dialog.Add_Shown({ $qtyBox.Focus() }.GetNewClosure())

    $dialogResult = $dialog.ShowDialog()
    if ($dialogResult -ne [Windows.Forms.DialogResult]::OK -and $dialogResult -ne [Windows.Forms.DialogResult]::Retry) { $dialog.Dispose(); return $null }
    $result = [pscustomobject]@{
        Data = $datePicker.Value.ToString("yyyy-MM-dd")
        QuantidadeNaNF = [int]$qtyBox.Value
        NFEntrada = ([string]$nfBox.Text).Trim()
        QuantidadeSaldo = [int]$balanceBox.Value
        Codigo = [string]$codeCombo.SelectedItem
        NFSaida = ([string]$outBox.Text).Trim()
        ContinuarCadastro = ($dialogResult -eq [Windows.Forms.DialogResult]::Retry)
    }
    $dialog.Dispose()
    return $result
}

function Add-NFRecordFromUI {
    param([string]$DefaultDate = "", [string]$DefaultCode = "800")
    $product = Get-SelectedProduct
    if ([string]::IsNullOrWhiteSpace($product)) { return }
    $defaultDate = if ([string]::IsNullOrWhiteSpace($DefaultDate)) { [DateTime]::Today.ToString("yyyy-MM-dd") } else { $DefaultDate }
    $record = Show-NFRecordDialog -Product $product -DefaultDate $defaultDate -DefaultCode $DefaultCode
    if ($null -eq $record) { return }
    try {
        $created = Add-NFEntradaRecord -Store $script:Store -Product $product -Record $record
        Save-NFStore
        Refresh-NFAll
        $targetGrid = if ($product -eq $script:ComputerProduct) { $computerGrid } else { $keyboardGrid }
        [void](Select-NFRecordInGrid -Grid $targetGrid -Id ([int]$created.Id))
        Set-NFStatus ("Registro " + $record.NFEntrada + " incluído com sucesso.") "Success"
        if ([bool]$record.ContinuarCadastro) {
            Add-NFRecordFromUI -DefaultDate ([string]$record.Data) -DefaultCode ([string]$record.Codigo)
        }
    }
    catch { Set-NFStatus $_.Exception.Message "Error"; [Windows.Forms.MessageBox]::Show($_.Exception.Message, "Controle de NF de Entrada", 0, 48) | Out-Null }
}

function Edit-NFRecordFromUI {
    $product = Get-SelectedProduct
    if ([string]::IsNullOrWhiteSpace($product)) { return }
    $grid = if ($product -eq $script:ComputerProduct) { $computerGrid } else { $keyboardGrid }
    $id = Get-SelectedRecordId $grid
    if ($id -le 0) { [Windows.Forms.MessageBox]::Show("Selecione um registro para editar.", "Controle de NF de Entrada", 0, 64) | Out-Null; return }
    $existing = Find-NFRecordById -Product $product -Id $id
    if ($null -eq $existing) { return }
    $record = Show-NFRecordDialog -Product $product -Existing $existing
    if ($null -eq $record) { return }
    try {
        Update-NFEntradaRecord -Store $script:Store -Product $product -Id $id -Record $record
        Save-NFStore
        Refresh-NFAll
        [void](Select-NFRecordInGrid -Grid $grid -Id $id)
        Set-NFStatus ("Registro " + $record.NFEntrada + " atualizado com sucesso.") "Success"
    }
    catch { Set-NFStatus $_.Exception.Message "Error"; [Windows.Forms.MessageBox]::Show($_.Exception.Message, "Controle de NF de Entrada", 0, 48) | Out-Null }
}

function Register-NFOutputFromUI {
    $product = Get-SelectedProduct
    if ([string]::IsNullOrWhiteSpace($product)) { return }
    $grid = if ($product -eq $script:ComputerProduct) { $computerGrid } else { $keyboardGrid }
    $id = Get-SelectedRecordId $grid
    if ($id -le 0) { [Windows.Forms.MessageBox]::Show("Selecione uma NF em estoque para registrar a saída.", "Controle de NF de Entrada", 0, 64) | Out-Null; return }
    $record = Find-NFRecordById -Product $product -Id $id
    if ($null -eq $record) { return }
    $saldoAtual = [int]$record.QuantidadeSaldo
    if ($saldoAtual -le 0) { [Windows.Forms.MessageBox]::Show("A NF selecionada já está encerrada.", "Controle de NF de Entrada", 0, 64) | Out-Null; return }

    $dialog = New-Object Windows.Forms.Form
    $dialog.Text = "Registrar saída — NF $($record.NFEntrada)"
    $dialog.StartPosition = [Windows.Forms.FormStartPosition]::CenterParent
    $dialog.FormBorderStyle = [Windows.Forms.FormBorderStyle]::FixedDialog
    $dialog.MaximizeBox = $false; $dialog.MinimizeBox = $false; $dialog.ShowInTaskbar = $false
    $dialog.ClientSize = [Drawing.Size]::new(570, 300)
    $dialog.BackColor = $script:CurrentPalette.Background; $dialog.ForeColor = $script:CurrentPalette.Text
    $layout = New-Object Windows.Forms.TableLayoutPanel
    $layout.Dock = [Windows.Forms.DockStyle]::Fill; $layout.Padding = [Windows.Forms.Padding]::new(18); $layout.ColumnCount = 2; $layout.RowCount = 5
    [void]$layout.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Absolute, 190)))
    [void]$layout.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent, 100)))
    foreach($h in @(46,46,46,62,50)){ [void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Absolute,$h))) }
    $dialog.Controls.Add($layout)
    function Add-OutputLabel([string]$text,[int]$row){ $l=New-Object Windows.Forms.Label; $l.Text=$text; $l.Dock=[Windows.Forms.DockStyle]::Fill; $l.TextAlign=[Drawing.ContentAlignment]::MiddleLeft; $l.ForeColor=$script:CurrentPalette.Text; $layout.Controls.Add($l,0,$row) }
    Add-OutputLabel "Saldo atual" 0
    $current=New-Object Windows.Forms.Label; $current.Text=[string]$saldoAtual; $current.Dock=[Windows.Forms.DockStyle]::Fill; $current.TextAlign=[Drawing.ContentAlignment]::MiddleLeft; $layout.Controls.Add($current,1,0)
    Add-OutputLabel "Quantidade da saída" 1
    $qty=New-Object Windows.Forms.NumericUpDown; $qty.Minimum=1; $qty.Maximum=$saldoAtual; $qty.Value=1; $qty.Dock=[Windows.Forms.DockStyle]::Fill; $layout.Controls.Add($qty,1,1)
    Add-OutputLabel "Saldo após saída" 2
    $after=New-Object Windows.Forms.Label; $after.Text=[string]($saldoAtual-1); $after.Dock=[Windows.Forms.DockStyle]::Fill; $after.TextAlign=[Drawing.ContentAlignment]::MiddleLeft; $layout.Controls.Add($after,1,2)
    Add-OutputLabel "NF de Saída / referência" 3
    $refBox=New-Object Windows.Forms.TextBox; $refBox.Dock=[Windows.Forms.DockStyle]::Fill; $refBox.MaxLength=120; $layout.Controls.Add($refBox,1,3)
    $qty.Add_ValueChanged({ $after.Text=[string]($saldoAtual-[int]$qty.Value) })
    $buttons=New-Object Windows.Forms.FlowLayoutPanel; $buttons.Dock=[Windows.Forms.DockStyle]::Fill; $buttons.FlowDirection=[Windows.Forms.FlowDirection]::RightToLeft; $layout.SetColumnSpan($buttons,2); $layout.Controls.Add($buttons,0,4)
    $cancel=New-Object Windows.Forms.Button; $cancel.Text="CANCELAR"; $cancel.Width=110; $cancel.Height=34; $cancel.DialogResult=[Windows.Forms.DialogResult]::Cancel; Set-NFButtonStyle $cancel "Secondary"; $buttons.Controls.Add($cancel)
    $save=New-Object Windows.Forms.Button; $save.Text="REGISTRAR SAÍDA"; $save.Width=140; $save.Height=34; $save.DialogResult=[Windows.Forms.DialogResult]::OK; Set-NFButtonStyle $save "Primary"; $buttons.Controls.Add($save)
    $dialog.AcceptButton=$save; $dialog.CancelButton=$cancel
    if ($dialog.ShowDialog() -ne [Windows.Forms.DialogResult]::OK) { $dialog.Dispose(); return }
    $quantity=[int]$qty.Value; $reference=([string]$refBox.Text).Trim(); $dialog.Dispose()
    try {
        [void](Register-NFEntradaOutput -Store $script:Store -Product $product -Id $id -Quantidade $quantity -NFSaida $reference)
        Save-NFStore
        Refresh-NFAll
        [void](Select-NFRecordInGrid -Grid $grid -Id $id)
        Set-NFStatus ("Saída registrada na NF " + $record.NFEntrada + ". Saldo atual: " + ($saldoAtual-$quantity)) "Success"
    }
    catch { Set-NFStatus $_.Exception.Message "Error"; [Windows.Forms.MessageBox]::Show($_.Exception.Message, "Falha ao registrar saída", 0, 16) | Out-Null }
}

function Remove-NFRecordFromUI {
    $product = Get-SelectedProduct
    if ([string]::IsNullOrWhiteSpace($product)) { return }
    $grid = if ($product -eq $script:ComputerProduct) { $computerGrid } else { $keyboardGrid }
    $id = Get-SelectedRecordId $grid
    if ($id -le 0) { [Windows.Forms.MessageBox]::Show("Selecione um registro para excluir.", "Controle de NF de Entrada", 0, 64) | Out-Null; return }
    $record = Find-NFRecordById -Product $product -Id $id
    if ($null -eq $record) { return }
    $answer = [Windows.Forms.MessageBox]::Show(
        "Excluir a NF de Entrada $($record.NFEntrada) de $(Get-NFEntradaProductDisplayName $product)?`r`n`r`nEssa ação altera somente a base local do módulo e será refletida na próxima exportação.",
        "Confirmar exclusão",
        [Windows.Forms.MessageBoxButtons]::YesNo,
        [Windows.Forms.MessageBoxIcon]::Warning
    )
    if ($answer -ne [Windows.Forms.DialogResult]::Yes) { return }
    try {
        Remove-NFEntradaRecord -Store $script:Store -Product $product -Id $id
        Save-NFStore
        Refresh-NFAll
        Set-NFStatus ("Registro " + $record.NFEntrada + " excluído; histórico preservado.") "Warning"
    }
    catch { Set-NFStatus $_.Exception.Message "Error"; [Windows.Forms.MessageBox]::Show($_.Exception.Message, "Controle de NF de Entrada", 0, 48) | Out-Null }
}

function Import-NFSourceFromUI {
    $dialog = New-Object Windows.Forms.OpenFileDialog
    $dialog.Title = "Selecionar planilha original de NF de Entrada"
    $dialog.Filter = "Planilha do Excel (*.xlsx)|*.xlsx"
    $dialog.Multiselect = $false
    if ($dialog.ShowDialog() -ne [Windows.Forms.DialogResult]::OK) { $dialog.Dispose(); return $false }
    $source = $dialog.FileName
    $dialog.Dispose()
    $currentSummary = Get-NFEntradaSummary -Store $script:Store
    $currentRecords = [int]$currentSummary.Produtos[$script:ComputerProduct].Registros + [int]$currentSummary.Produtos[$script:KeyboardProduct].Registros
    $templateExists = [IO.File]::Exists((Get-NFEntradaTemplatePath -DataDirectory $script:DataDirectory))
    if ($currentRecords -gt 0 -or $templateExists) {
        $answer = [Windows.Forms.MessageBox]::Show(
            "Esta importação substituirá a base ativa pelos dados da planilha selecionada.`r`n`r`nAntes da troca, o programa criará automaticamente um backup da base e do modelo atuais. O histórico já registrado será preservado.`r`n`r`nContinuar?",
            "Confirmar nova importação",
            [Windows.Forms.MessageBoxButtons]::YesNo,
            [Windows.Forms.MessageBoxIcon]::Warning
        )
        if ($answer -ne [Windows.Forms.DialogResult]::Yes) { Set-NFStatus "Importação cancelada; nenhum dado foi alterado." "Normal"; return $false }
    }
    try {
        Set-NFStatus "Importando planilha e protegendo a base atual..." "Warning"
        $result = Import-NFEntradaSourceWorkbook -SourcePath $source -DataDirectory $script:DataDirectory
        $script:DatabasePath = [string]$result.StorePath
        $script:Store = $result.Store
        Refresh-NFAll
        Set-NFStatus "Planilha importada com sucesso; base anterior protegida em backup." "Success"
        $backupText = if ([string]::IsNullOrWhiteSpace([string]$result.BackupDirectory)) { "" } else { "`r`n`r`nUma cópia de segurança da base anterior foi criada automaticamente." }
        [Windows.Forms.MessageBox]::Show(
            "Planilha importada com sucesso. O arquivo original permaneceu no local escolhido; o módulo usa uma cópia protegida como modelo de exportação e mantém os registros na base local." + $backupText,
            "Controle de NF de Entrada",
            [Windows.Forms.MessageBoxButtons]::OK,
            [Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
        return $true
    }
    catch {
        Set-NFStatus $_.Exception.Message "Error"
        [Windows.Forms.MessageBox]::Show($_.Exception.Message, "Falha ao importar planilha", 0, 16) | Out-Null
        return $false
    }
}

function Export-NFFromUI {
    $readiness = Get-NFEntradaExportReadiness -Store $script:Store -DataDirectory $script:DataDirectory
    if (-not [bool]$readiness.PodeExportar) {
        Show-NFExportReadiness
        Set-NFStatus "Exportação bloqueada pela conferência automática." "Error"
        return
    }
    if ([int]$readiness.Pendencias -gt 0) {
        $answer = [Windows.Forms.MessageBox]::Show(
            "Existem $($readiness.Pendencias) NF(s) com pendências de conferência.`r`n`r`nA planilha pode ser exportada sem alterar o formato oficial, mas os dados marcados para revisão também serão levados para o Excel.`r`n`r`nDeseja exportar mesmo assim?",
            "Exportação com pendências",
            [Windows.Forms.MessageBoxButtons]::YesNo,
            [Windows.Forms.MessageBoxIcon]::Warning
        )
        if ($answer -ne [Windows.Forms.DialogResult]::Yes) {
            Set-NFStatus "Exportação cancelada para revisão das pendências." "Warning"
            return
        }
    }
    $dialog = New-Object Windows.Forms.SaveFileDialog
    $dialog.Title = "Exportar planilha de NF de Entrada"
    $dialog.Filter = "Planilha do Excel (*.xlsx)|*.xlsx"
    $dialog.DefaultExt = "xlsx"
    $dialog.AddExtension = $true
    $dialog.FileName = "NF DE ENTRADA - " + [DateTime]::Now.ToString("yyyy-MM-dd") + ".xlsx"
    if ($dialog.ShowDialog() -ne [Windows.Forms.DialogResult]::OK) { $dialog.Dispose(); return }
    $path = $dialog.FileName
    $dialog.Dispose()
    try {
        $exported = Export-NFEntradaWorkbook -Store $script:Store -DestinationPath $path
        $exportSummary = Get-NFEntradaSummary -Store $script:Store
        $exportDetails = "Arquivo: " + [IO.Path]::GetFileName($exported) + " • CB5: " + [string]$exportSummary.Produtos[$script:ComputerProduct].Registros + " registro(s) • Teclado: " + [string]$exportSummary.Produtos[$script:KeyboardProduct].Registros + " registro(s) • Pendências: " + [string]$readiness.Pendencias
        [void](Add-NFEntradaHistoryEvent -Store $script:Store -Tipo "Exportacao" -Detalhes $exportDetails)
        Save-NFStore
        Refresh-NFAll
        Set-NFStatus "Planilha exportada com sucesso e registrada no histórico." "Success"
        [Windows.Forms.MessageBox]::Show(
            "Planilha exportada com o modelo original, fórmulas, resumo e formatação preservados.`r`n`r`n$exported",
            "Exportação concluída",
            [Windows.Forms.MessageBoxButtons]::OK,
            [Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
    }
    catch { Set-NFStatus $_.Exception.Message "Error"; [Windows.Forms.MessageBox]::Show($_.Exception.Message, "Falha na exportação", 0, 16) | Out-Null }
}

function New-NFSummaryCard {
    param([string]$Title, [string]$Subtitle, [ref]$ValueLabel)

    $isActivityCard = @("MOVIMENTAÇÕES HOJE", "PEÇAS SAÍRAM HOJE", "PEÇAS EM 7 DIAS") -contains $Title

    $panel = New-Object Windows.Forms.Panel
    $panel.Dock = [Windows.Forms.DockStyle]::Fill
    $panel.Margin = if ($isActivityCard -and $script:IsInProcessHosted) { [Windows.Forms.Padding]::new(3) } elseif ($script:IsInProcessHosted) { [Windows.Forms.Padding]::new(4, 4, 4, 6) } else { [Windows.Forms.Padding]::new(6) }
    $panel.Padding = [Windows.Forms.Padding]::new(0)
    $panel.BackColor = $script:CurrentPalette.Card
    $panel.Tag = "Theme.Card"
    $panel.BorderStyle = if ($script:IsInProcessHosted) { [Windows.Forms.BorderStyle]::None } else { [Windows.Forms.BorderStyle]::FixedSingle }

    $layout = New-Object Windows.Forms.TableLayoutPanel
    $layout.Dock = [Windows.Forms.DockStyle]::Fill
    $layout.Margin = [Windows.Forms.Padding]::new(0)
    $layout.Padding = if ($isActivityCard -and $script:IsInProcessHosted) { [Windows.Forms.Padding]::new(6, 4, 6, 4) } elseif ($script:IsInProcessHosted) { [Windows.Forms.Padding]::new(13, 9, 13, 8) } else { [Windows.Forms.Padding]::new(14, 10, 14, 9) }
    $layout.BackColor = $script:CurrentPalette.Card
    $layout.ColumnCount = 2
    $layout.RowCount = 2
    [void]$layout.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent, $(if ($isActivityCard) { 32 } else { 34 }))))
    [void]$layout.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent, $(if ($isActivityCard) { 68 } else { 66 }))))
    [void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Percent, 56)))
    [void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Percent, 44)))
    $panel.Controls.Add($layout)

    $value = New-Object Windows.Forms.Label
    $value.Text = "0"
    $value.Dock = [Windows.Forms.DockStyle]::Fill
    $value.Margin = [Windows.Forms.Padding]::new(0)
    $value.Font = [Drawing.Font]::new("Segoe UI Semibold", $(if ($isActivityCard -and $script:IsInProcessHosted) { 15.5 } elseif ($script:IsInProcessHosted) { 19 } else { 21 }))
    $value.ForeColor = if ($script:IsInProcessHosted) { $script:CurrentPalette.Accent } else { $script:CurrentPalette.Text }
    $value.TextAlign = [Drawing.ContentAlignment]::MiddleLeft
    if ($script:IsInProcessHosted) { $value.Tag = "Theme.Accent" }
    $layout.Controls.Add($value, 0, 0)
    $layout.SetRowSpan($value, 2)

    $titleLabel = New-Object Windows.Forms.Label
    $titleLabel.Text = $Title
    $titleLabel.Dock = [Windows.Forms.DockStyle]::Fill
    $titleLabel.Margin = [Windows.Forms.Padding]::new(0)
    $titleLabel.Padding = [Windows.Forms.Padding]::new(0, 0, 1, 0)
    $titleLabel.Font = [Drawing.Font]::new("Segoe UI Semibold", $(if ($isActivityCard -and $script:IsInProcessHosted) { 7.7 } elseif ($script:IsInProcessHosted) { 8.8 } else { 9.2 }))
    $titleLabel.ForeColor = $script:CurrentPalette.Text
    $titleLabel.TextAlign = [Drawing.ContentAlignment]::BottomRight
    $titleLabel.AutoEllipsis = $true
    $layout.Controls.Add($titleLabel, 1, 0)

    $hintLabel = New-Object Windows.Forms.Label
    $hintLabel.Text = $Subtitle
    $hintLabel.Dock = [Windows.Forms.DockStyle]::Fill
    $hintLabel.Margin = [Windows.Forms.Padding]::new(0)
    $hintLabel.Padding = [Windows.Forms.Padding]::new(0, 1, 1, 0)
    $hintLabel.Font = [Drawing.Font]::new("Segoe UI", $(if ($isActivityCard -and $script:IsInProcessHosted) { 7.0 } elseif ($script:IsInProcessHosted) { 8.0 } else { 8.4 }))
    $hintLabel.ForeColor = $script:CurrentPalette.Muted
    $hintLabel.Tag = "Theme.Muted"
    $hintLabel.TextAlign = [Drawing.ContentAlignment]::TopRight
    $hintLabel.AutoEllipsis = $true
    $layout.Controls.Add($hintLabel, 1, 1)

    $ValueLabel.Value = $value
    return $panel
}

function New-ProductTabContent {
    param(
        [Windows.Forms.TabPage]$Tab,
        [ref]$GridRef,
        [ref]$FilterRef,
        [ref]$StatusRef,
        [ref]$CodeRef,
        [ref]$CountRef
    )
    $layout = New-Object Windows.Forms.TableLayoutPanel
    $layout.Dock = [Windows.Forms.DockStyle]::Fill
    $layout.Padding = [Windows.Forms.Padding]::new(10)
    $layout.RowCount = 2
    [void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Absolute, 50)))
    [void]$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Percent, 100)))
    $Tab.Controls.Add($layout)

    $filterPanel = New-Object Windows.Forms.TableLayoutPanel
    $filterPanel.Dock = [Windows.Forms.DockStyle]::Fill
    $filterPanel.ColumnCount = 7
    [void]$filterPanel.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Absolute, 72)))
    [void]$filterPanel.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent, 100)))
    [void]$filterPanel.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Absolute, 58)))
    [void]$filterPanel.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Absolute, 128)))
    [void]$filterPanel.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Absolute, 48)))
    [void]$filterPanel.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Absolute, 100)))
    [void]$filterPanel.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Absolute, 96)))
    $layout.Controls.Add($filterPanel, 0, 0)

    $searchLabel = New-Object Windows.Forms.Label
    $searchLabel.Text = "Pesquisar"
    $searchLabel.Dock = [Windows.Forms.DockStyle]::Fill
    $searchLabel.TextAlign = [Drawing.ContentAlignment]::MiddleLeft
    $searchLabel.ForeColor = $script:CurrentPalette.Muted
    $filterPanel.Controls.Add($searchLabel, 0, 0)

    $filter = New-Object Windows.Forms.TextBox
    $filter.Dock = [Windows.Forms.DockStyle]::Fill
    $filter.Margin = [Windows.Forms.Padding]::new(0, 9, 12, 9)
    $filter.BackColor = $script:CurrentPalette.Input
    $filter.ForeColor = $script:CurrentPalette.Text
    $filterPanel.Controls.Add($filter, 1, 0)

    $statusLabel = New-Object Windows.Forms.Label
    $statusLabel.Text = "Status"
    $statusLabel.Dock = [Windows.Forms.DockStyle]::Fill
    $statusLabel.TextAlign = [Drawing.ContentAlignment]::MiddleLeft
    $statusLabel.ForeColor = $script:CurrentPalette.Muted
    $filterPanel.Controls.Add($statusLabel, 2, 0)

    $statusFilter = New-Object Windows.Forms.ComboBox
    $statusFilter.DropDownStyle = [Windows.Forms.ComboBoxStyle]::DropDownList
    [void]$statusFilter.Items.AddRange(@("Todos", "Em estoque", "Encerrada", "Revisar"))
    $statusFilter.SelectedIndex = 1
    $statusFilter.Dock = [Windows.Forms.DockStyle]::Fill
    $statusFilter.Margin = [Windows.Forms.Padding]::new(0, 8, 12, 8)
    $statusFilter.BackColor = $script:CurrentPalette.Input
    $statusFilter.ForeColor = $script:CurrentPalette.Text
    $filterPanel.Controls.Add($statusFilter, 3, 0)

    $codeLabel = New-Object Windows.Forms.Label
    $codeLabel.Text = "Cód."
    $codeLabel.Dock = [Windows.Forms.DockStyle]::Fill
    $codeLabel.TextAlign = [Drawing.ContentAlignment]::MiddleLeft
    $codeLabel.ForeColor = $script:CurrentPalette.Muted
    $filterPanel.Controls.Add($codeLabel, 4, 0)

    $codeFilter = New-Object Windows.Forms.ComboBox
    $codeFilter.DropDownStyle = [Windows.Forms.ComboBoxStyle]::DropDownList
    [void]$codeFilter.Items.AddRange(@("Todos", "800", "100", "850", "Garantia"))
    $codeFilter.SelectedIndex = 0
    $codeFilter.Dock = [Windows.Forms.DockStyle]::Fill
    $codeFilter.Margin = [Windows.Forms.Padding]::new(0, 8, 10, 8)
    $codeFilter.BackColor = $script:CurrentPalette.Input
    $codeFilter.ForeColor = $script:CurrentPalette.Text
    $filterPanel.Controls.Add($codeFilter, 5, 0)

    $countLabel = New-Object Windows.Forms.Label
    $countLabel.Text = "0 de 0"
    $countLabel.Dock = [Windows.Forms.DockStyle]::Fill
    $countLabel.TextAlign = [Drawing.ContentAlignment]::MiddleRight
    $countLabel.ForeColor = $script:CurrentPalette.Muted
    $countLabel.Font = [Drawing.Font]::new("Segoe UI Semibold", 8.5)
    $filterPanel.Controls.Add($countLabel, 6, 0)

    $grid = New-NFGrid
    $idCol = New-Object Windows.Forms.DataGridViewTextBoxColumn
    $idCol.Name = "Id"; $idCol.Visible = $false
    [void]$grid.Columns.Add($idCol)
    Add-NFGridColumn $grid "Data" "DATA" 92
    Add-NFGridColumn $grid "QuantidadeNaNF" "QTD. NA NF" 105
    Add-NFGridColumn $grid "NFEntrada" "NF DE ENTRADA" 120
    Add-NFGridColumn $grid "QuantidadeSaldo" "SALDO" 88
    Add-NFGridColumn $grid "Codigo" "CÓD." 76
    Add-NFGridColumn $grid "Status" "STATUS" 100
    Add-NFGridColumn $grid "NFSaida" "NF DE SAÍDA / MOVIMENTAÇÕES" 280 $true
    $layout.Controls.Add($grid, 0, 1)
    $GridRef.Value = $grid
    $FilterRef.Value = $filter
    $StatusRef.Value = $statusFilter
    $CodeRef.Value = $codeFilter
    $CountRef.Value = $countLabel
}

$initialHostTheme = if ($script:IsInProcessHosted) { Get-NFEntradaHostedCentralTheme } elseif ([string]::IsNullOrWhiteSpace($HostTheme)) { "Escuro profissional" } else { $HostTheme }
$script:CurrentPalette = Get-NFEntradaPalette $initialHostTheme

if ($script:IsInProcessHosted) {
    $form = New-Object Windows.Forms.UserControl
    $form.Name = "NFEntradaHostedControl"
    $form.Dock = [Windows.Forms.DockStyle]::Fill
    $form.Margin = [Windows.Forms.Padding]::new(0)
    $form.Padding = [Windows.Forms.Padding]::new(0)
}
else {
    $form = New-Object Windows.Forms.Form
    $form.Text = "Controle de NF de Entrada"
    $form.StartPosition = [Windows.Forms.FormStartPosition]::CenterScreen
    $form.MinimumSize = [Drawing.Size]::new(860, 600)
    $form.Size = [Drawing.Size]::new(1280, 820)
}
$form.BackColor = $script:CurrentPalette.Background
$form.ForeColor = $script:CurrentPalette.Text

$root = New-Object Windows.Forms.TableLayoutPanel
$root.Dock = [Windows.Forms.DockStyle]::Fill
$root.Padding = if ($script:IsInProcessHosted) { [Windows.Forms.Padding]::new(8, 6, 8, 6) } else { [Windows.Forms.Padding]::new(14) }
$root.RowCount = 4
$nfHeaderHeight = if ($script:IsInProcessHosted) { 68 } else { 92 }
$nfCardsHeight = if ($script:IsInProcessHosted) { 96 } else { 108 }
$nfFooterHeight = if ($script:IsInProcessHosted) { 52 } else { 58 }
[void]$root.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Absolute, $nfHeaderHeight)))
[void]$root.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Absolute, $nfCardsHeight)))
[void]$root.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Percent, 100)))
[void]$root.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Absolute, $nfFooterHeight)))
$form.Controls.Add($root)

$header = New-Object Windows.Forms.TableLayoutPanel
$header.Dock = [Windows.Forms.DockStyle]::Fill
$header.ColumnCount = 3
$header.RowCount = 1
[void]$header.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Percent, 100)))
$nfHeaderActionWidth = if ($script:IsInProcessHosted) { 158 } else { 175 }
[void]$header.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent, 100)))
[void]$header.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Absolute, $nfHeaderActionWidth)))
[void]$header.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Absolute, $nfHeaderActionWidth)))
$header.Margin = [Windows.Forms.Padding]::new(0)
$root.Controls.Add($header, 0, 0)

$heading = New-Object Windows.Forms.TableLayoutPanel
$heading.Dock = [Windows.Forms.DockStyle]::Fill
$heading.RowCount = 2
$nfHeadingTitleHeight = if ($script:IsInProcessHosted) { 39 } else { 54 }
[void]$heading.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Absolute, $nfHeadingTitleHeight)))
[void]$heading.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Percent, 100)))
$header.Controls.Add($heading, 0, 0)
$title = New-Object Windows.Forms.Label
$title.Text = "Controle de NF de Entrada"
$title.Dock = [Windows.Forms.DockStyle]::Fill
$title.TextAlign = [Drawing.ContentAlignment]::BottomLeft
$title.Font = [Drawing.Font]::new("Segoe UI Semibold", $(if ($script:IsInProcessHosted) { 15.5 } else { 20 }))
$title.ForeColor = $script:CurrentPalette.Text
$heading.Controls.Add($title, 0, 0)
$subtitle = New-Object Windows.Forms.Label
$subtitle.Text = "Saldos, NFs e exportação no mesmo padrão da planilha oficial"
$subtitle.Dock = [Windows.Forms.DockStyle]::Fill
$subtitle.TextAlign = [Drawing.ContentAlignment]::TopLeft
$subtitle.ForeColor = $script:CurrentPalette.Muted
if ($script:IsInProcessHosted) { $subtitle.Font = [Drawing.Font]::new("Segoe UI", 8.2) }
$heading.Controls.Add($subtitle, 0, 1)

$importButton = New-Object Windows.Forms.Button
$importButton.Text = "IMPORTAR EXCEL"
$importButton.Dock = [Windows.Forms.DockStyle]::Fill
$importButton.Margin = if ($script:IsInProcessHosted) { [Windows.Forms.Padding]::new(3, 7, 3, 7) } else { [Windows.Forms.Padding]::new(3, 17, 3, 17) }
$importButton.Padding = [Windows.Forms.Padding]::new(8, 0, 8, 0)
$importButton.Font = [Drawing.Font]::new("Segoe UI Semibold", 8.5)
Set-NFButtonStyle $importButton "Action"
$header.Controls.Add($importButton, 1, 0)

$exportButton = New-Object Windows.Forms.Button
$exportButton.Text = "EXCEL OFICIAL"
$exportButton.Dock = [Windows.Forms.DockStyle]::Fill
$exportButton.Margin = if ($script:IsInProcessHosted) { [Windows.Forms.Padding]::new(3, 7, 3, 7) } else { [Windows.Forms.Padding]::new(3, 17, 3, 17) }
$exportButton.Padding = [Windows.Forms.Padding]::new(8, 0, 8, 0)
$exportButton.Font = [Drawing.Font]::new("Segoe UI Semibold", 8.5)
Set-NFButtonStyle $exportButton "Primary"
$header.Controls.Add($exportButton, 2, 0)

$cards = New-Object Windows.Forms.TableLayoutPanel
$cards.Dock = [Windows.Forms.DockStyle]::Fill
$cards.Margin = if ($script:IsInProcessHosted) { [Windows.Forms.Padding]::new(0, 2, 0, 2) } else { [Windows.Forms.Padding]::new(3) }
$cards.ColumnCount = 4
foreach ($i in 0..3) { [void]$cards.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent, 25))) }
$root.Controls.Add($cards, 0, 1)
$saldoTotalValue = $null; $computerBalanceValue = $null; $keyboardBalanceValue = $null; $openNFsValue = $null
$cards.Controls.Add((New-NFSummaryCard "SALDO TOTAL" "peças disponíveis" ([ref]$saldoTotalValue)), 0, 0)
$cards.Controls.Add((New-NFSummaryCard "COMPUTADOR DE BORDO CB5" "saldo atual" ([ref]$computerBalanceValue)), 1, 0)
$cards.Controls.Add((New-NFSummaryCard "TECLADO V5" "saldo atual" ([ref]$keyboardBalanceValue)), 2, 0)
$cards.Controls.Add((New-NFSummaryCard "NFs EM ABERTO" "com saldo maior que zero" ([ref]$openNFsValue)), 3, 0)

$nfTabsShell = New-Object Windows.Forms.TableLayoutPanel
$nfTabsShell.Dock = [Windows.Forms.DockStyle]::Fill
$nfTabsShell.Margin = [Windows.Forms.Padding]::new(0, 4, 0, 4)
$nfTabsShell.Padding = [Windows.Forms.Padding]::new(0)
$nfTabsShell.RowCount = 2
$nfTabsShell.ColumnCount = 1
[void]$nfTabsShell.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Absolute, $(if ($script:IsInProcessHosted) { 43 } else { 46 }))))
[void]$nfTabsShell.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Percent, 100)))
$root.Controls.Add($nfTabsShell, 0, 2)

$nfSectionNav = New-Object Windows.Forms.TableLayoutPanel
$nfSectionNav.Dock = [Windows.Forms.DockStyle]::Fill
$nfSectionNav.Margin = [Windows.Forms.Padding]::new(0)
$nfSectionNav.Padding = [Windows.Forms.Padding]::new(5, 2, 5, 2)
$nfSectionNav.ColumnCount = 6
$nfSectionNav.RowCount = 1
for ($i = 0; $i -lt 6; $i++) { [void]$nfSectionNav.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent, 16.6667))) }
$nfTabsShell.Controls.Add($nfSectionNav, 0, 0)

function New-NFSectionNavButton([string]$Text) {
    $button = New-Object Windows.Forms.Button
    $button.Text = $Text
    $button.Dock = [Windows.Forms.DockStyle]::Fill
    $button.Margin = [Windows.Forms.Padding]::new(3, 2, 3, 2)
    $button.Padding = [Windows.Forms.Padding]::new(4, 0, 4, 0)
    $button.Font = [Drawing.Font]::new("Segoe UI Semibold", $(if ($script:IsInProcessHosted) { 8.0 } else { 8.4 }))
    $button.TextAlign = [Drawing.ContentAlignment]::MiddleCenter
    $button.AutoEllipsis = $false
    Set-NFButtonStyle $button "Secondary"
    return $button
}

$script:NFComputerNavButton = New-NFSectionNavButton "COMPUTADOR CB5 (0)"
$script:NFKeyboardNavButton = New-NFSectionNavButton "TECLADO V5 (0)"
$script:NFMovementNavButton = New-NFSectionNavButton "MOVIMENTAÇÕES"
$script:NFHistoryNavButton = New-NFSectionNavButton "HISTÓRICO"
$script:NFSecurityNavButton = New-NFSectionNavButton "SEGURANÇA"
$script:NFSummaryNavButton = New-NFSectionNavButton "RESUMO"
$nfSectionNav.Controls.Add($script:NFComputerNavButton, 0, 0)
$nfSectionNav.Controls.Add($script:NFKeyboardNavButton, 1, 0)
$nfSectionNav.Controls.Add($script:NFMovementNavButton, 2, 0)
$nfSectionNav.Controls.Add($script:NFHistoryNavButton, 3, 0)
$nfSectionNav.Controls.Add($script:NFSecurityNavButton, 4, 0)
$nfSectionNav.Controls.Add($script:NFSummaryNavButton, 5, 0)

$nfTabsViewport = New-Object Windows.Forms.Panel
$nfTabsViewport.Dock = [Windows.Forms.DockStyle]::Fill
$nfTabsViewport.Margin = [Windows.Forms.Padding]::new(0)
$nfTabsViewport.Padding = [Windows.Forms.Padding]::new(0)
$nfTabsViewport.BackColor = $script:CurrentPalette.Background
$nfTabsShell.Controls.Add($nfTabsViewport, 0, 1)

$mainTabs = New-Object Windows.Forms.TabControl
$mainTabs.Dock = [Windows.Forms.DockStyle]::None
$mainTabs.Margin = [Windows.Forms.Padding]::new(0)
$mainTabs.Font = [Drawing.Font]::new("Segoe UI Semibold", $(if ($script:IsInProcessHosted) { 8.6 } else { 9 }))
$nfTabsViewport.Controls.Add($mainTabs)

function Sync-NFTabViewport {
    if ($null -eq $nfTabsViewport -or $null -eq $mainTabs) { return }
    try {
        $clip = 27
        try {
            $displayY = [int]$mainTabs.DisplayRectangle.Y
            if ($displayY -gt 18 -and $displayY -lt 48) { $clip = $displayY }
        } catch {}
        $w = [Math]::Max(1, $nfTabsViewport.ClientSize.Width)
        $h = [Math]::Max(1, $nfTabsViewport.ClientSize.Height)
        $mainTabs.SetBounds(0, -$clip, $w, $h + $clip)
    } catch {}
}
$nfTabsViewport.Add_Resize({ Sync-NFTabViewport })

$computerTab = New-Object Windows.Forms.TabPage
$computerTab.Text = "COMPUTADOR DE BORDO CB5"
$computerTab.BackColor = $script:CurrentPalette.Background
$mainTabs.TabPages.Add($computerTab)
$keyboardTab = New-Object Windows.Forms.TabPage
$keyboardTab.Text = "TECLADO V5"
$keyboardTab.BackColor = $script:CurrentPalette.Background
$mainTabs.TabPages.Add($keyboardTab)
$movementTab = New-Object Windows.Forms.TabPage
$movementTab.Text = "MOVIMENTAÇÕES"
$movementTab.BackColor = $script:CurrentPalette.Background
$mainTabs.TabPages.Add($movementTab)
$historyTab = New-Object Windows.Forms.TabPage
$historyTab.Text = "HISTÓRICO"
$historyTab.BackColor = $script:CurrentPalette.Background
$mainTabs.TabPages.Add($historyTab)
$securityTab = New-Object Windows.Forms.TabPage
$securityTab.Text = "SEGURANÇA"
$securityTab.BackColor = $script:CurrentPalette.Background
$mainTabs.TabPages.Add($securityTab)
$summaryTab = New-Object Windows.Forms.TabPage
$summaryTab.Text = "RESUMO"
$summaryTab.BackColor = $script:CurrentPalette.Background
$mainTabs.TabPages.Add($summaryTab)
$mainTabs.SelectedTab = $computerTab

function Update-NFSectionNavigation {
    $items = @(
        @($script:NFComputerNavButton, $computerTab),
        @($script:NFKeyboardNavButton, $keyboardTab),
        @($script:NFMovementNavButton, $movementTab),
        @($script:NFHistoryNavButton, $historyTab),
        @($script:NFSecurityNavButton, $securityTab),
        @($script:NFSummaryNavButton, $summaryTab)
    )
    foreach ($item in $items) {
        $button = $item[0]
        $page = $item[1]
        if ($null -eq $button -or $null -eq $page) { continue }
        $kind = if ($mainTabs.SelectedTab -eq $page) { "Primary" } else { "Secondary" }
        Set-NFButtonStyle $button $kind
    }
}

$script:NFComputerNavButton.Add_Click({ $mainTabs.SelectedTab = $computerTab })
$script:NFKeyboardNavButton.Add_Click({ $mainTabs.SelectedTab = $keyboardTab })
$script:NFMovementNavButton.Add_Click({ $mainTabs.SelectedTab = $movementTab })
$script:NFHistoryNavButton.Add_Click({ $mainTabs.SelectedTab = $historyTab })
$script:NFSecurityNavButton.Add_Click({ $mainTabs.SelectedTab = $securityTab })
$script:NFSummaryNavButton.Add_Click({ $mainTabs.SelectedTab = $summaryTab })
Update-NFSectionNavigation
Sync-NFTabViewport

$summaryLayout = New-Object Windows.Forms.TableLayoutPanel
$summaryLayout.Dock = [Windows.Forms.DockStyle]::Fill
$summaryLayout.Padding = if ($script:IsInProcessHosted) { [Windows.Forms.Padding]::new(8, 6, 8, 6) } else { [Windows.Forms.Padding]::new(10) }
$summaryLayout.ColumnCount = 2
$summaryLayout.RowCount = 3
[void]$summaryLayout.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent, 55)))
[void]$summaryLayout.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent, 45)))
[void]$summaryLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Percent, 34)))
[void]$summaryLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Percent, 38)))
[void]$summaryLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Percent, 28)))
$summaryTab.Controls.Add($summaryLayout)

$productGroup = New-Object Windows.Forms.GroupBox
$productGroup.Text = "Saldo por produto"
$productGroup.Dock = [Windows.Forms.DockStyle]::Fill
$productGroup.ForeColor = $script:CurrentPalette.Text
$productGroup.Padding = if ($script:IsInProcessHosted) { [Windows.Forms.Padding]::new(8, 18, 8, 6) } else { [Windows.Forms.Padding]::new(10, 22, 10, 10) }
$summaryLayout.Controls.Add($productGroup, 0, 0)
$productSummaryGrid = New-NFGrid
$productSummaryGrid.ScrollBars = [Windows.Forms.ScrollBars]::None
$productSummaryGrid.RowTemplate.Height = if ($script:IsInProcessHosted) { 21 } else { 27 }
$productSummaryGrid.ColumnHeadersHeight = if ($script:IsInProcessHosted) { 26 } else { 30 }
Add-NFGridColumn $productSummaryGrid "Produto" "PRODUTO" 200 $true
Add-NFGridColumn $productSummaryGrid "Abertas" "NFs EM ABERTO" 125
Add-NFGridColumn $productSummaryGrid "Saldo" "SALDO (PÇS)" 110
$productGroup.Controls.Add($productSummaryGrid)

$conferenceGroup = New-Object Windows.Forms.GroupBox
$conferenceGroup.Text = "Conferência automática"
$conferenceGroup.Dock = [Windows.Forms.DockStyle]::Fill
$conferenceGroup.ForeColor = $script:CurrentPalette.Text
$conferenceGroup.Padding = [Windows.Forms.Padding]::new(14, 24, 14, 12)
$summaryLayout.Controls.Add($conferenceGroup, 1, 0)
$conference = New-Object Windows.Forms.TableLayoutPanel
$conference.Dock = [Windows.Forms.DockStyle]::Fill
$conference.ColumnCount = 2
$conference.RowCount = 6
[void]$conference.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent, 70)))
[void]$conference.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent, 30)))
for ($conferenceRow = 0; $conferenceRow -lt 6; $conferenceRow++) {
    [void]$conference.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Percent, 16.6667)))
}
$conference.GrowStyle = [Windows.Forms.TableLayoutPanelGrowStyle]::FixedSize
$conferenceGroup.Controls.Add($conference)
$missingDateValue = New-Object Windows.Forms.Label
$negativeValue = New-Object Windows.Forms.Label
$overEntryValue = New-Object Windows.Forms.Label
$reviewIssuesValue = New-Object Windows.Forms.Label
$exportStatusValue = New-Object Windows.Forms.Label
$generalStatusValue = New-Object Windows.Forms.Label
$conferenceRows = @(
    @("Datas ausentes", $missingDateValue),
    @("Saldos negativos", $negativeValue),
    @("Saldo maior que a entrada", $overEntryValue),
    @("Pendências para revisar", $reviewIssuesValue),
    @("Exportação Excel", $exportStatusValue),
    @("Situação geral", $generalStatusValue)
)
for ($i = 0; $i -lt $conferenceRows.Count; $i++) {
    $l = New-Object Windows.Forms.Label
    $l.Text = $conferenceRows[$i][0]
    $l.Dock = [Windows.Forms.DockStyle]::Fill
    $l.TextAlign = [Drawing.ContentAlignment]::MiddleLeft
    $l.ForeColor = $script:CurrentPalette.Muted
    $conference.Controls.Add($l, 0, $i)
    $v = $conferenceRows[$i][1]
    $v.Dock = [Windows.Forms.DockStyle]::Fill
    $v.TextAlign = [Drawing.ContentAlignment]::MiddleRight
    $v.Font = [Drawing.Font]::new("Segoe UI Semibold", 10)
    $v.ForeColor = $script:CurrentPalette.Text
    $conference.Controls.Add($v, 1, $i)
}

$codeGroup = New-Object Windows.Forms.GroupBox
$codeGroup.Text = "Saldo por código"
$codeGroup.Dock = [Windows.Forms.DockStyle]::Fill
$codeGroup.ForeColor = $script:CurrentPalette.Text
$codeGroup.Padding = if ($script:IsInProcessHosted) { [Windows.Forms.Padding]::new(8, 18, 8, 6) } else { [Windows.Forms.Padding]::new(10, 22, 10, 10) }
$summaryLayout.SetColumnSpan($codeGroup, 2)
$summaryLayout.Controls.Add($codeGroup, 0, 1)
$codeSummaryGrid = New-NFGrid
$codeSummaryGrid.ScrollBars = [Windows.Forms.ScrollBars]::None
$codeSummaryGrid.RowTemplate.Height = if ($script:IsInProcessHosted) { 21 } else { 27 }
$codeSummaryGrid.ColumnHeadersHeight = if ($script:IsInProcessHosted) { 26 } else { 30 }
Add-NFGridColumn $codeSummaryGrid "Codigo" "CÓDIGO" 110
Add-NFGridColumn $codeSummaryGrid "Computador" "COMPUTADOR CB5" 150
Add-NFGridColumn $codeSummaryGrid "Teclado" "TECLADO V5" 150
Add-NFGridColumn $codeSummaryGrid "Total" "TOTAL" 130
foreach ($columnName in @("Codigo","Computador","Teclado","Total")) { $codeSummaryGrid.Columns[$columnName].AutoSizeMode = [Windows.Forms.DataGridViewAutoSizeColumnMode]::Fill }
$codeSummaryGrid.Columns["Codigo"].FillWeight = 15
$codeSummaryGrid.Columns["Computador"].FillWeight = 35
$codeSummaryGrid.Columns["Teclado"].FillWeight = 30
$codeSummaryGrid.Columns["Total"].FillWeight = 20
$codeSummaryGrid.Visible = $false
$script:NFCodeCardValues = @{}
function New-NFCodeSummaryCard {
    param([string]$Code)
    $p=New-Object Windows.Forms.Panel
    $p.Dock=[Windows.Forms.DockStyle]::Fill
    $p.Margin=[Windows.Forms.Padding]::new(4)
    $p.BackColor=$script:CurrentPalette.Card
    $p.ForeColor=$script:CurrentPalette.Text
    $p.Tag="Theme.Card"
    $p.BorderStyle=[Windows.Forms.BorderStyle]::FixedSingle
    $l=New-Object Windows.Forms.TableLayoutPanel
    $l.Dock=[Windows.Forms.DockStyle]::Fill
    $l.Margin=[Windows.Forms.Padding]::new(0)
    $l.Padding=[Windows.Forms.Padding]::new(10,3,10,3)
    $l.ColumnCount=3; $l.RowCount=2
    foreach($pct in @(34,33,33)){[void]$l.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent,$pct)))}
    [void]$l.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Absolute,28)))
    [void]$l.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Percent,100)))
    $p.Controls.Add($l)
    $h=New-Object Windows.Forms.Label
    $h.Text=$Code; $h.Dock=[Windows.Forms.DockStyle]::Fill; $h.Margin=[Windows.Forms.Padding]::new(0)
    $h.Font=[Drawing.Font]::new("Segoe UI Semibold",11.5); $h.ForeColor=$script:CurrentPalette.Text
    $h.TextAlign=[Drawing.ContentAlignment]::MiddleLeft
    $l.Controls.Add($h,0,0); $l.SetColumnSpan($h,3)
    $cb=New-Object Windows.Forms.Label
    $cb.Text="CB5: 0"; $cb.Dock=[Windows.Forms.DockStyle]::Fill; $cb.Margin=[Windows.Forms.Padding]::new(0)
    $cb.Font=[Drawing.Font]::new("Segoe UI Semibold",8.5); $cb.ForeColor=$script:CurrentPalette.Text; $cb.TextAlign=[Drawing.ContentAlignment]::MiddleLeft
    $l.Controls.Add($cb,0,1)
    $tv=New-Object Windows.Forms.Label
    $tv.Text="TV5: 0"; $tv.Dock=[Windows.Forms.DockStyle]::Fill; $tv.Margin=[Windows.Forms.Padding]::new(0)
    $tv.Font=[Drawing.Font]::new("Segoe UI Semibold",8.5); $tv.ForeColor=$script:CurrentPalette.Text; $tv.TextAlign=[Drawing.ContentAlignment]::MiddleLeft
    $l.Controls.Add($tv,1,1)
    $tt=New-Object Windows.Forms.Label
    $tt.Text="TOTAL: 0"; $tt.Dock=[Windows.Forms.DockStyle]::Fill; $tt.Margin=[Windows.Forms.Padding]::new(0)
    $tt.Font=[Drawing.Font]::new("Segoe UI Semibold",8.5); $tt.ForeColor=$script:CurrentPalette.Text; $tt.TextAlign=[Drawing.ContentAlignment]::MiddleRight
    $l.Controls.Add($tt,2,1)
    $script:NFCodeCardValues[$Code]=[pscustomobject]@{Computador=$cb;Teclado=$tv;Total=$tt}
    return $p
}
$codeCardsLayout=New-Object Windows.Forms.TableLayoutPanel
$codeCardsLayout.Dock=[Windows.Forms.DockStyle]::Fill
$codeCardsLayout.Margin=[Windows.Forms.Padding]::new(0)
$codeCardsLayout.Padding=[Windows.Forms.Padding]::new(1)
$codeCardsLayout.ColumnCount=2; $codeCardsLayout.RowCount=2
[void]$codeCardsLayout.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent,50)))
[void]$codeCardsLayout.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent,50)))
[void]$codeCardsLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Percent,50)))
[void]$codeCardsLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Percent,50)))
$codeCardsLayout.Controls.Add((New-NFCodeSummaryCard "800"),0,0)
$codeCardsLayout.Controls.Add((New-NFCodeSummaryCard "100"),1,0)
$codeCardsLayout.Controls.Add((New-NFCodeSummaryCard "850"),0,1)
$codeCardsLayout.Controls.Add((New-NFCodeSummaryCard "Garantia"),1,1)
$codeGroup.Controls.Add($codeCardsLayout)

$activityGroup = New-Object Windows.Forms.GroupBox
$activityGroup.Text = "Atividade operacional"
$activityGroup.Dock = [Windows.Forms.DockStyle]::Fill
$activityGroup.ForeColor = $script:CurrentPalette.Text
$activityGroup.Padding = if ($script:IsInProcessHosted) { [Windows.Forms.Padding]::new(8, 18, 8, 6) } else { [Windows.Forms.Padding]::new(8, 20, 8, 8) }
$summaryLayout.SetColumnSpan($activityGroup, 2)
$summaryLayout.Controls.Add($activityGroup, 0, 2)

$activityLayout = New-Object Windows.Forms.TableLayoutPanel
$activityLayout.Dock = [Windows.Forms.DockStyle]::Fill
$activityLayout.Margin = [Windows.Forms.Padding]::new(0)
$activityLayout.ColumnCount = 5
foreach ($percent in @(17, 17, 17, 32, 17)) {
    [void]$activityLayout.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent, $percent)))
}
$activityGroup.Controls.Add($activityLayout)

$movementTodayValue = $null
$piecesTodayValue = $null
$piecesSevenValue = $null
$activityLayout.Controls.Add((New-NFSummaryCard "MOVIMENTAÇÕES HOJE" "registros de saída" ([ref]$movementTodayValue)), 0, 0)
$activityLayout.Controls.Add((New-NFSummaryCard "PEÇAS SAÍRAM HOJE" "saídas registradas" ([ref]$piecesTodayValue)), 1, 0)
$activityLayout.Controls.Add((New-NFSummaryCard "PEÇAS EM 7 DIAS" "saídas registradas" ([ref]$piecesSevenValue)), 2, 0)

$lastPanel = New-Object Windows.Forms.Panel
$lastPanel.Dock = [Windows.Forms.DockStyle]::Fill
$lastPanel.Margin = if ($script:IsInProcessHosted) { [Windows.Forms.Padding]::new(4) } else { [Windows.Forms.Padding]::new(6) }
$lastPanel.BackColor = $script:CurrentPalette.Card
$lastPanel.BorderStyle = if ($script:IsInProcessHosted) { [Windows.Forms.BorderStyle]::None } else { [Windows.Forms.BorderStyle]::FixedSingle }
$lastLayout = New-Object Windows.Forms.TableLayoutPanel
$lastLayout.Dock = [Windows.Forms.DockStyle]::Fill
$lastLayout.Padding = [Windows.Forms.Padding]::new(12, 8, 12, 8)
$lastLayout.RowCount = 2
[void]$lastLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Absolute, 24)))
[void]$lastLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Percent, 100)))
$lastPanel.Controls.Add($lastLayout)
$lastTitle = New-Object Windows.Forms.Label
$lastTitle.Text = "ÚLTIMA MOVIMENTAÇÃO"
$lastTitle.Dock = [Windows.Forms.DockStyle]::Fill
$lastTitle.Font = [Drawing.Font]::new("Segoe UI Semibold", 8.5)
$lastTitle.ForeColor = $script:CurrentPalette.Muted
$lastLayout.Controls.Add($lastTitle, 0, 0)
$lastMovementValue = New-Object Windows.Forms.Label
$lastMovementValue.Text = "Nenhuma movimentação registrada"
$lastMovementValue.Dock = [Windows.Forms.DockStyle]::Fill
$lastMovementValue.TextAlign = [Drawing.ContentAlignment]::MiddleLeft
$lastMovementValue.Font = [Drawing.Font]::new("Segoe UI Semibold", 9.5)
$lastMovementValue.ForeColor = $script:CurrentPalette.Text
$lastLayout.Controls.Add($lastMovementValue, 0, 1)
$activityLayout.Controls.Add($lastPanel, 3, 0)

$summaryActionPanel = New-Object Windows.Forms.FlowLayoutPanel
$summaryActionPanel.Dock = [Windows.Forms.DockStyle]::Fill
$summaryActionPanel.FlowDirection = [Windows.Forms.FlowDirection]::TopDown
$summaryActionPanel.WrapContents = $false
$summaryActionPanel.Padding = if ($script:IsInProcessHosted) { [Windows.Forms.Padding]::new(4, 10, 4, 4) } else { [Windows.Forms.Padding]::new(4, 22, 4, 4) }
$summaryActionPanel.BackColor = $script:CurrentPalette.Card
$reviewIssuesButton = New-Object Windows.Forms.Button
$reviewIssuesButton.Text = "PENDÊNCIAS"
$reviewIssuesButton.Width = 145
$reviewIssuesButton.Height = 32
$reviewIssuesButton.Margin = [Windows.Forms.Padding]::new(2)
Set-NFButtonStyle $reviewIssuesButton "Secondary"
$summaryActionPanel.Controls.Add($reviewIssuesButton)
$activityLayout.Controls.Add($summaryActionPanel, 4, 0)

# MOVIMENTAÇÕES
$movementLayout = New-Object Windows.Forms.TableLayoutPanel
$movementLayout.Dock = [Windows.Forms.DockStyle]::Fill
$movementLayout.Padding = [Windows.Forms.Padding]::new(10)
$movementLayout.RowCount = 3
[void]$movementLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Absolute, 52)))
[void]$movementLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Percent, 100)))
[void]$movementLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Absolute, 42)))
$movementTab.Controls.Add($movementLayout)
$movementFilters = New-Object Windows.Forms.TableLayoutPanel
$movementFilters.Dock = [Windows.Forms.DockStyle]::Fill
$movementFilters.ColumnCount = 6
$movementFilters.RowCount = 1
[void]$movementFilters.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Percent, 100)))
[void]$movementFilters.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Absolute, 74)))
[void]$movementFilters.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent, 100)))
[void]$movementFilters.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Absolute, 62)))
[void]$movementFilters.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Absolute, 190)))
[void]$movementFilters.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Absolute, 58)))
[void]$movementFilters.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Absolute, 165)))
$movementLayout.Controls.Add($movementFilters,0,0)
$movementSearchLabel=New-Object Windows.Forms.Label
$movementSearchLabel.Text="Pesquisar"; $movementSearchLabel.Dock=[Windows.Forms.DockStyle]::Fill; $movementSearchLabel.TextAlign=[Drawing.ContentAlignment]::MiddleLeft; $movementSearchLabel.ForeColor=$script:CurrentPalette.Muted
$movementFilters.Controls.Add($movementSearchLabel,0,0)
$movementFilter=New-Object Windows.Forms.TextBox
$movementFilter.Dock=[Windows.Forms.DockStyle]::Fill; $movementFilter.Margin=[Windows.Forms.Padding]::new(0,9,12,9); $movementFilter.BackColor=$script:CurrentPalette.Input; $movementFilter.ForeColor=$script:CurrentPalette.Text
$movementFilters.Controls.Add($movementFilter,1,0)
$movementProductLabel=New-Object Windows.Forms.Label
$movementProductLabel.Text="Produto"; $movementProductLabel.Dock=[Windows.Forms.DockStyle]::Fill; $movementProductLabel.TextAlign=[Drawing.ContentAlignment]::MiddleLeft; $movementProductLabel.ForeColor=$script:CurrentPalette.Muted
$movementFilters.Controls.Add($movementProductLabel,2,0)
$movementProductFilter=New-Object Windows.Forms.ComboBox
$movementProductFilter.DropDownStyle=[Windows.Forms.ComboBoxStyle]::DropDownList
[void]$movementProductFilter.Items.AddRange(@("Todos","COMPUTADOR DE BORDO CB5","TECLADO V5"))
$movementProductFilter.SelectedIndex=0; $movementProductFilter.Dock=[Windows.Forms.DockStyle]::Fill; $movementProductFilter.Margin=[Windows.Forms.Padding]::new(0,8,8,8); $movementProductFilter.BackColor=$script:CurrentPalette.Input; $movementProductFilter.ForeColor=$script:CurrentPalette.Text
$movementFilters.Controls.Add($movementProductFilter,3,0)
$movementPeriodLabel=New-Object Windows.Forms.Label
$movementPeriodLabel.Text="Período"; $movementPeriodLabel.Dock=[Windows.Forms.DockStyle]::Fill; $movementPeriodLabel.TextAlign=[Drawing.ContentAlignment]::MiddleLeft; $movementPeriodLabel.ForeColor=$script:CurrentPalette.Muted
$movementFilters.Controls.Add($movementPeriodLabel,4,0)
$movementPeriodFilter=New-Object Windows.Forms.ComboBox
$movementPeriodFilter.DropDownStyle=[Windows.Forms.ComboBoxStyle]::DropDownList
[void]$movementPeriodFilter.Items.AddRange(@("Todos","Hoje","Últimos 7 dias","Últimos 30 dias"))
$movementPeriodFilter.SelectedIndex=0; $movementPeriodFilter.Dock=[Windows.Forms.DockStyle]::Fill; $movementPeriodFilter.Margin=[Windows.Forms.Padding]::new(0,8,8,8); $movementPeriodFilter.BackColor=$script:CurrentPalette.Input; $movementPeriodFilter.ForeColor=$script:CurrentPalette.Text
$movementFilters.Controls.Add($movementPeriodFilter,5,0)

$movementGrid=New-NFGrid
$movementIdCol=New-Object Windows.Forms.DataGridViewTextBoxColumn
$movementIdCol.Name="MovementId"; $movementIdCol.Visible=$false; [void]$movementGrid.Columns.Add($movementIdCol)
$movementProductKeyCol=New-Object Windows.Forms.DataGridViewTextBoxColumn
$movementProductKeyCol.Name="MovementProductKey"; $movementProductKeyCol.Visible=$false; [void]$movementGrid.Columns.Add($movementProductKeyCol)
Add-NFGridColumn $movementGrid "MovementDate" "DATA / HORA" 145
Add-NFGridColumn $movementGrid "MovementProduct" "PRODUTO" 190
Add-NFGridColumn $movementGrid "MovementNF" "NF DE ENTRADA" 110
Add-NFGridColumn $movementGrid "MovementQty" "SAÍDA" 75
Add-NFGridColumn $movementGrid "MovementBefore" "SALDO ANTES" 95
Add-NFGridColumn $movementGrid "MovementAfter" "SALDO DEPOIS" 100
Add-NFGridColumn $movementGrid "MovementStatus" "STATUS" 90
Add-NFGridColumn $movementGrid "MovementReference" "NF DE SAÍDA / REFERÊNCIA" 240 $true
$movementLayout.Controls.Add($movementGrid,0,1)
$movementFooter=New-Object Windows.Forms.TableLayoutPanel
$movementFooter.Dock=[Windows.Forms.DockStyle]::Fill; $movementFooter.ColumnCount=4; $movementFooter.RowCount=1
[void]$movementFooter.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Percent,100)))
[void]$movementFooter.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent,100)))
[void]$movementFooter.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::AutoSize)))
[void]$movementFooter.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::AutoSize)))
[void]$movementFooter.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::AutoSize)))
$movementCountLabel=New-Object Windows.Forms.Label
$movementCountLabel.Text="0 movimentação(ões)"; $movementCountLabel.Dock=[Windows.Forms.DockStyle]::Fill; $movementCountLabel.TextAlign=[Drawing.ContentAlignment]::MiddleLeft; $movementCountLabel.ForeColor=$script:CurrentPalette.Muted
$movementFooter.Controls.Add($movementCountLabel,0,0)
$movementExportButton=New-Object Windows.Forms.Button
$movementExportButton.Text="CSV"; $movementExportButton.Width=72; $movementExportButton.Height=32; Set-NFButtonStyle $movementExportButton "Secondary"
$movementFooter.Controls.Add($movementExportButton,1,0)
$movementOpenButton=New-Object Windows.Forms.Button
$movementOpenButton.Text="IR PARA NF"; $movementOpenButton.Width=92; $movementOpenButton.Height=32; $movementOpenButton.Enabled=$false; Set-NFButtonStyle $movementOpenButton "Secondary"
$movementFooter.Controls.Add($movementOpenButton,2,0)
$movementReverseButton=New-Object Windows.Forms.Button
$movementReverseButton.Text="ESTORNAR"; $movementReverseButton.Width=96; $movementReverseButton.Height=32; $movementReverseButton.Enabled=$false; Set-NFButtonStyle $movementReverseButton "Danger"
$movementFooter.Controls.Add($movementReverseButton,3,0)
$movementLayout.Controls.Add($movementFooter,0,2)
# HISTÓRICO — consulta auditável das alterações do módulo.
$historyLayout = New-Object Windows.Forms.TableLayoutPanel
$historyLayout.Dock = [Windows.Forms.DockStyle]::Fill
$historyLayout.Padding = [Windows.Forms.Padding]::new(10)
$historyLayout.RowCount = 3
[void]$historyLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Absolute, 52)))
[void]$historyLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Percent, 100)))
[void]$historyLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Absolute, 42)))
$historyTab.Controls.Add($historyLayout)
$historyFilters = New-Object Windows.Forms.TableLayoutPanel
$historyFilters.Dock = [Windows.Forms.DockStyle]::Fill
$historyFilters.ColumnCount = 7
$historyFilters.RowCount = 1
[void]$historyFilters.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Percent, 100)))
[void]$historyFilters.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Absolute, 74)))
[void]$historyFilters.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent, 100)))
[void]$historyFilters.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Absolute, 52)))
[void]$historyFilters.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Absolute, 142)))
[void]$historyFilters.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Absolute, 62)))
[void]$historyFilters.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Absolute, 155)))
[void]$historyFilters.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Absolute, 120)))
$historyLayout.Controls.Add($historyFilters, 0, 0)
$historySearchLabel = New-Object Windows.Forms.Label
$historySearchLabel.Text = "Pesquisar"; $historySearchLabel.Dock = [Windows.Forms.DockStyle]::Fill; $historySearchLabel.TextAlign = [Drawing.ContentAlignment]::MiddleLeft; $historySearchLabel.ForeColor = $script:CurrentPalette.Muted
$historyFilters.Controls.Add($historySearchLabel, 0, 0)
$historyFilter = New-Object Windows.Forms.TextBox
$historyFilter.Dock = [Windows.Forms.DockStyle]::Fill; $historyFilter.Margin = [Windows.Forms.Padding]::new(0, 9, 12, 9); $historyFilter.BackColor = $script:CurrentPalette.Input; $historyFilter.ForeColor = $script:CurrentPalette.Text
$historyFilters.Controls.Add($historyFilter, 1, 0)
$historyTypeLabel = New-Object Windows.Forms.Label
$historyTypeLabel.Text = "Tipo"; $historyTypeLabel.Dock = [Windows.Forms.DockStyle]::Fill; $historyTypeLabel.TextAlign = [Drawing.ContentAlignment]::MiddleLeft; $historyTypeLabel.ForeColor = $script:CurrentPalette.Muted
$historyFilters.Controls.Add($historyTypeLabel, 2, 0)
$historyTypeFilter = New-Object Windows.Forms.ComboBox
$historyTypeFilter.DropDownStyle = [Windows.Forms.ComboBoxStyle]::DropDownList
[void]$historyTypeFilter.Items.AddRange(@("Todos", "Adição", "Edição", "Saída", "Estorno de saída", "Exclusão", "Importação", "Restauração", "Exportação"))
$historyTypeFilter.SelectedIndex = 0; $historyTypeFilter.Dock = [Windows.Forms.DockStyle]::Fill; $historyTypeFilter.Margin = [Windows.Forms.Padding]::new(0, 8, 8, 8); $historyTypeFilter.BackColor = $script:CurrentPalette.Input; $historyTypeFilter.ForeColor = $script:CurrentPalette.Text
$historyFilters.Controls.Add($historyTypeFilter, 3, 0)
$historyPeriodLabel = New-Object Windows.Forms.Label
$historyPeriodLabel.Text = "Período"; $historyPeriodLabel.Dock = [Windows.Forms.DockStyle]::Fill; $historyPeriodLabel.TextAlign = [Drawing.ContentAlignment]::MiddleLeft; $historyPeriodLabel.ForeColor = $script:CurrentPalette.Muted
$historyFilters.Controls.Add($historyPeriodLabel, 4, 0)
$historyPeriodFilter = New-Object Windows.Forms.ComboBox
$historyPeriodFilter.DropDownStyle = [Windows.Forms.ComboBoxStyle]::DropDownList
[void]$historyPeriodFilter.Items.AddRange(@("Todos", "Hoje", "Últimos 7 dias", "Últimos 30 dias"))
$historyPeriodFilter.SelectedIndex = 0; $historyPeriodFilter.Dock = [Windows.Forms.DockStyle]::Fill; $historyPeriodFilter.Margin = [Windows.Forms.Padding]::new(0, 8, 8, 8); $historyPeriodFilter.BackColor = $script:CurrentPalette.Input; $historyPeriodFilter.ForeColor = $script:CurrentPalette.Text
$historyFilters.Controls.Add($historyPeriodFilter, 5, 0)
$historyCountLabel = New-Object Windows.Forms.Label
$historyCountLabel.Text = "0 de 0"; $historyCountLabel.Dock = [Windows.Forms.DockStyle]::Fill; $historyCountLabel.TextAlign = [Drawing.ContentAlignment]::MiddleRight; $historyCountLabel.ForeColor = $script:CurrentPalette.Muted
$historyFilters.Controls.Add($historyCountLabel, 6, 0)
$historyGrid = New-NFGrid
$historyIdCol = New-Object Windows.Forms.DataGridViewTextBoxColumn
$historyIdCol.Name = "HistoryId"; $historyIdCol.Visible = $false; [void]$historyGrid.Columns.Add($historyIdCol)
Add-NFGridColumn $historyGrid "HistoryDate" "DATA / HORA" 145
Add-NFGridColumn $historyGrid "HistoryType" "AÇÃO" 105
Add-NFGridColumn $historyGrid "HistoryProduct" "PRODUTO" 190
Add-NFGridColumn $historyGrid "HistoryNF" "NF" 105
Add-NFGridColumn $historyGrid "HistoryDetails" "DETALHES" 260 $true
$historyLayout.Controls.Add($historyGrid, 0, 1)
$historyButtons = New-Object Windows.Forms.FlowLayoutPanel
$historyButtons.Dock = [Windows.Forms.DockStyle]::Fill; $historyButtons.FlowDirection = [Windows.Forms.FlowDirection]::RightToLeft
$historyDetailsButton = New-Object Windows.Forms.Button
$historyDetailsButton.Text = "DETALHES"; $historyDetailsButton.Width = 96; $historyDetailsButton.Height = 32; $historyDetailsButton.Enabled = $false; Set-NFButtonStyle $historyDetailsButton "Secondary"
$historyExportButton = New-Object Windows.Forms.Button
$historyExportButton.Text = "CSV"; $historyExportButton.Width = 72; $historyExportButton.Height = 32; Set-NFButtonStyle $historyExportButton "Secondary"
$historyButtons.Controls.Add($historyDetailsButton); $historyButtons.Controls.Add($historyExportButton); $historyLayout.Controls.Add($historyButtons, 0, 2)

# SEGURANÇA — backups internos e restauração protegida.
$securityLayout = New-Object Windows.Forms.TableLayoutPanel
$securityLayout.Dock = [Windows.Forms.DockStyle]::Fill; $securityLayout.Padding = [Windows.Forms.Padding]::new(10); $securityLayout.RowCount = 3
[void]$securityLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Absolute, 72)))
[void]$securityLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Percent, 100)))
[void]$securityLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Absolute, 46)))
$securityTab.Controls.Add($securityLayout)
$securityInfo = New-Object Windows.Forms.Label
$securityInfo.Text = "Os backups guardam a base e o modelo Excel. O sistema mantém no máximo 20 backups automáticos; backups manuais e de recuperação não são removidos por essa retenção. Antes de restaurar, o estado atual é protegido."
$securityInfo.Dock = [Windows.Forms.DockStyle]::Fill; $securityInfo.ForeColor = $script:CurrentPalette.Muted; $securityInfo.Font = [Drawing.Font]::new("Segoe UI", 9)
$securityLayout.Controls.Add($securityInfo, 0, 0)
$backupGrid = New-NFGrid
$backupDirCol = New-Object Windows.Forms.DataGridViewTextBoxColumn
$backupDirCol.Name = "BackupDirectory"; $backupDirCol.Visible = $false; [void]$backupGrid.Columns.Add($backupDirCol)
Add-NFGridColumn $backupGrid "BackupDate" "DATA / HORA" 145
Add-NFGridColumn $backupGrid "BackupReason" "MOTIVO" 180
Add-NFGridColumn $backupGrid "BackupRecords" "REGISTROS" 85
Add-NFGridColumn $backupGrid "BackupContent" "CONTEÚDO" 130
Add-NFGridColumn $backupGrid "BackupStatus" "SITUAÇÃO" 100 $true
$securityLayout.Controls.Add($backupGrid, 0, 1)
$securityActions = New-Object Windows.Forms.TableLayoutPanel
$securityActions.Dock = [Windows.Forms.DockStyle]::Fill; $securityActions.ColumnCount = 2; $securityActions.RowCount = 1
[void]$securityActions.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Percent, 100)))
[void]$securityActions.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent, 100)))
[void]$securityActions.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::AutoSize)))
$backupCountLabel = New-Object Windows.Forms.Label
$backupCountLabel.Text = "0 backup(s) disponível(is)"; $backupCountLabel.Dock = [Windows.Forms.DockStyle]::Fill; $backupCountLabel.TextAlign = [Drawing.ContentAlignment]::MiddleLeft; $backupCountLabel.ForeColor = $script:CurrentPalette.Muted
$securityActions.Controls.Add($backupCountLabel, 0, 0)
$backupButtons = New-Object Windows.Forms.FlowLayoutPanel
$backupButtons.AutoSize = $true; $backupButtons.WrapContents = $false; $backupButtons.FlowDirection = [Windows.Forms.FlowDirection]::LeftToRight
$integrityButton = New-Object Windows.Forms.Button
$integrityButton.Text = "VERIFICAR"; $integrityButton.Width = 100; $integrityButton.Height = 32; Set-NFButtonStyle $integrityButton "Secondary"
$manualBackupButton = New-Object Windows.Forms.Button
$manualBackupButton.Text = "NOVO BACKUP"; $manualBackupButton.Width = 108; $manualBackupButton.Height = 32; Set-NFButtonStyle $manualBackupButton "Secondary"
$restoreBackupButton = New-Object Windows.Forms.Button
$restoreBackupButton.Text = "RESTAURAR"; $restoreBackupButton.Width = 105; $restoreBackupButton.Height = 32; $restoreBackupButton.Enabled = $false; Set-NFButtonStyle $restoreBackupButton "Primary"
$backupButtons.Controls.Add($integrityButton); $backupButtons.Controls.Add($manualBackupButton); $backupButtons.Controls.Add($restoreBackupButton)
$securityActions.Controls.Add($backupButtons, 1, 0); $securityLayout.Controls.Add($securityActions, 0, 2)

$computerGrid = $null; $computerFilter = $null; $computerStatusFilter = $null; $computerCodeFilter = $null; $computerCountLabel = $null
$keyboardGrid = $null; $keyboardFilter = $null; $keyboardStatusFilter = $null; $keyboardCodeFilter = $null; $keyboardCountLabel = $null
New-ProductTabContent -Tab $computerTab -GridRef ([ref]$computerGrid) -FilterRef ([ref]$computerFilter) -StatusRef ([ref]$computerStatusFilter) -CodeRef ([ref]$computerCodeFilter) -CountRef ([ref]$computerCountLabel)
New-ProductTabContent -Tab $keyboardTab -GridRef ([ref]$keyboardGrid) -FilterRef ([ref]$keyboardFilter) -StatusRef ([ref]$keyboardStatusFilter) -CodeRef ([ref]$keyboardCodeFilter) -CountRef ([ref]$keyboardCountLabel)

# Barra de ações dentro das abas de produto.
$actionPanel = New-Object Windows.Forms.FlowLayoutPanel
$actionPanel.AutoSize = $true
$actionPanel.WrapContents = $false
$actionPanel.FlowDirection = [Windows.Forms.FlowDirection]::LeftToRight
$actionPanel.BackColor = $script:CurrentPalette.Surface
$actionPanel.Padding = [Windows.Forms.Padding]::new(0, 1, 0, 1)
$actionPanel.Margin = [Windows.Forms.Padding]::new(0)
$newButton = New-Object Windows.Forms.Button
$newButton.Text = "+ NOVA NF"; $newButton.Width = 105; $newButton.Height = 34; Set-NFButtonStyle $newButton "Action"
$editButton = New-Object Windows.Forms.Button
$editButton.Text = "EDITAR"; $editButton.Width = 82; $editButton.Height = 34; Set-NFButtonStyle $editButton "Secondary"; Add-NFReadableDisabledText $editButton
$outputButton = New-Object Windows.Forms.Button
$outputButton.Text = "SAÍDA"; $outputButton.Width = 78; $outputButton.Height = 34; Set-NFButtonStyle $outputButton "Secondary"; Add-NFReadableDisabledText $outputButton
$clearFiltersButton = New-Object Windows.Forms.Button
$clearFiltersButton.Text = "LIMPAR"; $clearFiltersButton.Width = 82; $clearFiltersButton.Height = 34; Set-NFButtonStyle $clearFiltersButton "Secondary"
$exportListButton = New-Object Windows.Forms.Button
$exportListButton.Text = "CSV"; $exportListButton.Width = 68; $exportListButton.Height = 34; Set-NFButtonStyle $exportListButton "Secondary"
$deleteButton = New-Object Windows.Forms.Button
$deleteButton.Text = "EXCLUIR"; $deleteButton.Width = 82; $deleteButton.Height = 34; Set-NFButtonStyle $deleteButton "Danger"
$actionPanel.Controls.Add($newButton); $actionPanel.Controls.Add($editButton); $actionPanel.Controls.Add($outputButton); $actionPanel.Controls.Add($clearFiltersButton); $actionPanel.Controls.Add($exportListButton); $actionPanel.Controls.Add($deleteButton)
# A barra fica no rodapé geral e é ativada somente nas abas de produto.
$footerHost = New-Object Windows.Forms.TableLayoutPanel
$footerHost.Dock = [Windows.Forms.DockStyle]::Fill
$footerHost.RowCount = 1
[void]$footerHost.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Percent, 100)))
$footerHost.BackColor = $script:CurrentPalette.Surface
$footerHost.Padding = if ($script:IsInProcessHosted) { [Windows.Forms.Padding]::new(8, 6, 8, 6) } else { [Windows.Forms.Padding]::new(8, 8, 8, 8) }
$footerHost.Margin = [Windows.Forms.Padding]::new(0)
$footerHost.ColumnCount = 2
[void]$footerHost.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent, 100)))
[void]$footerHost.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::AutoSize)))
$root.Controls.Add($footerHost, 0, 3)
$footerStatus = New-Object Windows.Forms.Label
$footerStatus.Dock = [Windows.Forms.DockStyle]::Fill
$footerStatus.TextAlign = [Drawing.ContentAlignment]::MiddleLeft
$footerStatus.ForeColor = $script:CurrentPalette.Muted
$footerStatus.Font = [Drawing.Font]::new("Segoe UI", 8)
$footerHost.Controls.Add($footerStatus, 0, 0)
$footerHost.Controls.Add($actionPanel, 1, 0)

function Update-NFActions {
    $product = Get-SelectedProduct
    $enabled = -not [string]::IsNullOrWhiteSpace($product)
    $actionPanel.Visible = $enabled
    $newButton.Enabled = $enabled
    $exportListButton.Enabled = $enabled
    $hasSelection = $false
    if ($enabled) {
        $grid = if ($product -eq $script:ComputerProduct) { $computerGrid } else { $keyboardGrid }
        $hasSelection = ($null -ne $grid -and $grid.SelectedRows.Count -gt 0)
    }
    $editButton.Enabled = $hasSelection
    $deleteButton.Enabled = $hasSelection
    $canOutput = $false
    if ($hasSelection) {
        $id = Get-SelectedRecordId $grid
        $selected = Find-NFRecordById -Product $product -Id $id
        $canOutput = ($null -ne $selected -and [int]$selected.QuantidadeSaldo -gt 0)
    }
    $outputButton.Enabled = $canOutput
}

$toolTip = New-Object Windows.Forms.ToolTip
$toolTip.AutoPopDelay = 8000
$toolTip.InitialDelay = 350
$toolTip.SetToolTip($newButton, "Nova NF (Ctrl+N).")
$toolTip.SetToolTip($editButton, "Editar a NF selecionada (Enter ou duplo clique).")
$toolTip.SetToolTip($outputButton, "Registrar saída da NF selecionada (Ctrl+S).")
$toolTip.SetToolTip($clearFiltersButton, "Limpa pesquisa, status e código; volta para Em estoque.")
$toolTip.SetToolTip($exportButton, "Exporta o Excel oficial. Se houver algum bloqueio, o motivo será mostrado antes de gerar o arquivo.")
$toolTip.SetToolTip($reviewIssuesButton, "Abre somente os registros que precisam de conferência.")
$toolTip.SetToolTip($exportListButton, "Exporta a visão atual em CSV (Ctrl+E). Diferente do Excel oficial completo.")
$toolTip.SetToolTip($deleteButton, "Excluir o registro selecionado; o Histórico é preservado.")
$toolTip.SetToolTip($movementReverseButton, "Estorna a saída ativa sem apagar a movimentação original (Ctrl+Z).")
$toolTip.SetToolTip($movementExportButton, "Exporta somente as movimentações visíveis com os filtros atuais para CSV compatível com Excel.")
$toolTip.SetToolTip($historyExportButton, "Exporta somente os eventos visíveis do Histórico para CSV compatível com Excel.")
$toolTip.SetToolTip($integrityButton, "Audita base, duplicidades, pendências, modelo Excel, backups e arquivos temporários.")

$computerFilter.Add_TextChanged({ Refresh-NFProductGrid -Product $script:ComputerProduct -Grid $computerGrid -FilterBox $computerFilter -StatusFilter $computerStatusFilter -CodeFilter $computerCodeFilter -CountLabel $computerCountLabel })
$computerFilter.Add_KeyDown({ if ($_.KeyCode -eq [Windows.Forms.Keys]::Escape) { $_.SuppressKeyPress=$true; $computerFilter.Clear() } })
$computerStatusFilter.Add_SelectedIndexChanged({ Refresh-NFProductGrid -Product $script:ComputerProduct -Grid $computerGrid -FilterBox $computerFilter -StatusFilter $computerStatusFilter -CodeFilter $computerCodeFilter -CountLabel $computerCountLabel })
$computerCodeFilter.Add_SelectedIndexChanged({ Refresh-NFProductGrid -Product $script:ComputerProduct -Grid $computerGrid -FilterBox $computerFilter -StatusFilter $computerStatusFilter -CodeFilter $computerCodeFilter -CountLabel $computerCountLabel })
$keyboardFilter.Add_TextChanged({ Refresh-NFProductGrid -Product $script:KeyboardProduct -Grid $keyboardGrid -FilterBox $keyboardFilter -StatusFilter $keyboardStatusFilter -CodeFilter $keyboardCodeFilter -CountLabel $keyboardCountLabel })
$keyboardFilter.Add_KeyDown({ if ($_.KeyCode -eq [Windows.Forms.Keys]::Escape) { $_.SuppressKeyPress=$true; $keyboardFilter.Clear() } })
$keyboardStatusFilter.Add_SelectedIndexChanged({ Refresh-NFProductGrid -Product $script:KeyboardProduct -Grid $keyboardGrid -FilterBox $keyboardFilter -StatusFilter $keyboardStatusFilter -CodeFilter $keyboardCodeFilter -CountLabel $keyboardCountLabel })
$keyboardCodeFilter.Add_SelectedIndexChanged({ Refresh-NFProductGrid -Product $script:KeyboardProduct -Grid $keyboardGrid -FilterBox $keyboardFilter -StatusFilter $keyboardStatusFilter -CodeFilter $keyboardCodeFilter -CountLabel $keyboardCountLabel })
$computerGrid.Add_CellDoubleClick({ if ($_.RowIndex -ge 0) { Edit-NFRecordFromUI } })
$computerGrid.Add_KeyDown({ if ($_.Control -and $_.KeyCode -eq [Windows.Forms.Keys]::N) { $_.SuppressKeyPress=$true; Add-NFRecordFromUI } elseif ($_.Control -and $_.KeyCode -eq [Windows.Forms.Keys]::S) { $_.SuppressKeyPress=$true; Register-NFOutputFromUI } elseif ($_.Control -and $_.KeyCode -eq [Windows.Forms.Keys]::E) { $_.SuppressKeyPress=$true; Export-NFCurrentProductViewToCsv } elseif ($_.KeyCode -eq [Windows.Forms.Keys]::Enter) { $_.SuppressKeyPress=$true; Edit-NFRecordFromUI } elseif ($_.Control -and $_.KeyCode -eq [Windows.Forms.Keys]::F) { $_.SuppressKeyPress=$true; $computerFilter.Focus() } })
$keyboardGrid.Add_CellDoubleClick({ if ($_.RowIndex -ge 0) { Edit-NFRecordFromUI } })
$keyboardGrid.Add_KeyDown({ if ($_.Control -and $_.KeyCode -eq [Windows.Forms.Keys]::N) { $_.SuppressKeyPress=$true; Add-NFRecordFromUI } elseif ($_.Control -and $_.KeyCode -eq [Windows.Forms.Keys]::S) { $_.SuppressKeyPress=$true; Register-NFOutputFromUI } elseif ($_.Control -and $_.KeyCode -eq [Windows.Forms.Keys]::E) { $_.SuppressKeyPress=$true; Export-NFCurrentProductViewToCsv } elseif ($_.KeyCode -eq [Windows.Forms.Keys]::Enter) { $_.SuppressKeyPress=$true; Edit-NFRecordFromUI } elseif ($_.Control -and $_.KeyCode -eq [Windows.Forms.Keys]::F) { $_.SuppressKeyPress=$true; $keyboardFilter.Focus() } })
$computerGrid.Add_SelectionChanged({ Update-NFActions })
$keyboardGrid.Add_SelectionChanged({ Update-NFActions })
$mainTabs.Add_SelectedIndexChanged({ Update-NFSectionNavigation; Update-NFActions; if ($mainTabs.SelectedTab -eq $movementTab) { Refresh-NFMovements }; if ($mainTabs.SelectedTab -eq $historyTab) { Refresh-NFHistory }; if ($mainTabs.SelectedTab -eq $securityTab) { Refresh-NFBackups } })
$movementFilter.Add_TextChanged({ Refresh-NFMovements })
$movementFilter.Add_KeyDown({ if ($_.KeyCode -eq [Windows.Forms.Keys]::Escape) { $_.SuppressKeyPress=$true; $movementFilter.Clear() } })
$movementProductFilter.Add_SelectedIndexChanged({ Refresh-NFMovements })
$movementPeriodFilter.Add_SelectedIndexChanged({ Refresh-NFMovements })
$movementGrid.Add_SelectionChanged({
    $movementOpenButton.Enabled = ($movementGrid.SelectedRows.Count -gt 0)
    $movementReverseButton.Enabled = ($movementGrid.SelectedRows.Count -gt 0 -and [string]$movementGrid.SelectedRows[0].Cells["MovementStatus"].Value -eq "Ativa")
})
$movementGrid.Add_CellDoubleClick({ if ($_.RowIndex -ge 0) { Open-NFFromMovement } })
$movementGrid.Add_KeyDown({ if ($_.Control -and $_.KeyCode -eq [Windows.Forms.Keys]::Z) { $_.SuppressKeyPress=$true; Reverse-NFMovementFromUI } })
$movementExportButton.Add_Click({ Export-NFGridViewToCsv -Grid $movementGrid -BaseName "Movimentacoes-NF-Entrada" -Title "Movimentações" })
$movementOpenButton.Add_Click({ Open-NFFromMovement })
$movementReverseButton.Add_Click({ Reverse-NFMovementFromUI })
$reviewIssuesButton.Add_Click({ Show-NFReviewIssues })
$historyFilter.Add_TextChanged({ Refresh-NFHistory })
$historyFilter.Add_KeyDown({ if ($_.KeyCode -eq [Windows.Forms.Keys]::Escape) { $_.SuppressKeyPress=$true; $historyFilter.Clear() } })
$historyTypeFilter.Add_SelectedIndexChanged({ Refresh-NFHistory })
$historyPeriodFilter.Add_SelectedIndexChanged({ Refresh-NFHistory })
$historyGrid.Add_SelectionChanged({ $historyDetailsButton.Enabled = ($historyGrid.SelectedRows.Count -gt 0) })
$historyGrid.Add_CellDoubleClick({ if ($_.RowIndex -ge 0) { Show-NFHistoryDetails } })
$historyExportButton.Add_Click({ Export-NFGridViewToCsv -Grid $historyGrid -BaseName "Historico-NF-Entrada" -Title "Histórico" })
$historyDetailsButton.Add_Click({ Show-NFHistoryDetails })
$backupGrid.Add_SelectionChanged({ $restoreBackupButton.Enabled = ($backupGrid.SelectedRows.Count -gt 0 -and [string]$backupGrid.SelectedRows[0].Cells["BackupStatus"].Value -eq "Pronto") })
$integrityButton.Add_Click({ Show-NFIntegrityReport })
$manualBackupButton.Add_Click({ New-NFManualBackupFromUI })
$restoreBackupButton.Add_Click({ Restore-NFBackupFromUI })
$newButton.Add_Click({ Add-NFRecordFromUI })
$editButton.Add_Click({ Edit-NFRecordFromUI })
$outputButton.Add_Click({ Register-NFOutputFromUI })
$clearFiltersButton.Add_Click({ Clear-NFCurrentProductFilters })
$exportListButton.Add_Click({ Export-NFCurrentProductViewToCsv })
$deleteButton.Add_Click({ Remove-NFRecordFromUI })
$importButton.Add_Click({ [void](Import-NFSourceFromUI) })
$exportButton.Add_Click({ Export-NFFromUI })

Refresh-NFAll
Update-NFActions

$localTemplatePath = Get-NFEntradaTemplatePath -DataDirectory $script:DataDirectory
# O prompt continua normal em produção. Apenas o autoteste não interativo do runner
# o ignora para poder validar a aparência de uma instalação limpa.
if (-not [IO.File]::Exists($localTemplatePath) -and $env:CENTRAL_THEME_RUNTIME_TEST -ne "1") {
    $answer = [Windows.Forms.MessageBox]::Show(
        "Este é o primeiro uso do Controle de NF de Entrada.

Selecione a planilha original que você já usa para importar todos os registros e guardá-la como modelo oficial de exportação.

Deseja selecionar agora?",
        "Configuração inicial",
        [Windows.Forms.MessageBoxButtons]::YesNo,
        [Windows.Forms.MessageBoxIcon]::Information
    )
    if ($answer -eq [Windows.Forms.DialogResult]::Yes) { [void](Import-NFSourceFromUI) }
}

function Set-HostedNFEntradaThemeLegacy {
    param([string]$Theme)
    if ([string]::IsNullOrWhiteSpace($Theme)) { $Theme = "Escuro profissional" }

    if ($script:IsInProcessHosted) {
        if ($null -eq $script:HostedThemeContext) { $script:HostedCentralTheme = $Theme }
        $Theme = Get-NFEntradaHostedCentralTheme
    }

    $oldPalette = $script:CurrentPalette
    $newPalette = Get-NFEntradaPalette $Theme
    if ($null -eq $newPalette -or $null -eq $form -or $form.IsDisposed) { return $false }

    # Monta um mapa das cores da paleta anterior. Ele preserva os papéis visuais
    # (fundo, card, texto, aviso, perigo etc.) sem depender de recursão por
    # scriptblock. Controles que não pertenciam à paleta recebem um fallback
    # semântico de acordo com o tipo.
    $colorMap = @{}
    if ($null -ne $oldPalette) {
        $pairs = @(
            @($oldPalette.Background, $newPalette.Background),
            @($oldPalette.Surface, $newPalette.Surface),
            @($oldPalette.Card, $newPalette.Card),
            @($oldPalette.Input, $newPalette.Input),
            @($oldPalette.Text, $newPalette.Text),
            @($oldPalette.Muted, $newPalette.Muted),
            @($oldPalette.Border, $newPalette.Border),
            @($oldPalette.Accent, $newPalette.Accent),
            @($oldPalette.AccentStrong, $newPalette.AccentStrong),
            @($oldPalette.AccentText, $newPalette.AccentText),
            @($oldPalette.Success, $newPalette.Success),
            @($oldPalette.SuccessBack, $newPalette.SuccessBack),
            @($oldPalette.Warning, $newPalette.Warning),
            @($oldPalette.WarningBack, $newPalette.WarningBack),
            @($oldPalette.Danger, $newPalette.Danger),
            @($oldPalette.DangerBack, $newPalette.DangerBack)
        )
        foreach ($pair in $pairs) {
            try { $colorMap[[int]$pair[0].ToArgb()] = $pair[1] } catch {}
        }
    }

    $script:CurrentPalette = $newPalette
    $queue = New-Object System.Collections.Queue
    $queue.Enqueue($form)

    while ($queue.Count -gt 0) {
        $control = $queue.Dequeue()
        if ($null -eq $control -or $control.IsDisposed) { continue }

        foreach ($child in @($control.Controls)) {
            if ($null -ne $child -and -not $child.IsDisposed) { $queue.Enqueue($child) }
        }

        try {
            $oldBackArgb = [int]$control.BackColor.ToArgb()
            $oldForeArgb = [int]$control.ForeColor.ToArgb()
            $mappedBack = if ($colorMap.ContainsKey($oldBackArgb)) { $colorMap[$oldBackArgb] } else { $null }
            $mappedFore = if ($colorMap.ContainsKey($oldForeArgb)) { $colorMap[$oldForeArgb] } else { $null }

            if ($null -ne $mappedBack) { $control.BackColor = $mappedBack }
            if ($null -ne $mappedFore) { $control.ForeColor = $mappedFore }

            if ($control -is [Windows.Forms.DataGridView]) {
                $control.BackgroundColor = $newPalette.Surface
                $control.GridColor = $newPalette.Border
                $control.EnableHeadersVisualStyles = $false
                $control.ColumnHeadersDefaultCellStyle.BackColor = $newPalette.Card
                $control.ColumnHeadersDefaultCellStyle.ForeColor = $newPalette.Text
                $control.DefaultCellStyle.BackColor = $newPalette.Surface
                $control.DefaultCellStyle.ForeColor = $newPalette.Text
                $control.DefaultCellStyle.SelectionBackColor = $newPalette.AccentStrong
                $control.DefaultCellStyle.SelectionForeColor = $newPalette.AccentText
                $control.AlternatingRowsDefaultCellStyle.BackColor = $newPalette.Surface
                $control.AlternatingRowsDefaultCellStyle.ForeColor = $newPalette.Text
            }
            elseif ($control -is [Windows.Forms.TextBox] -or
                    $control -is [Windows.Forms.ComboBox] -or
                    $control -is [Windows.Forms.NumericUpDown] -or
                    $control -is [Windows.Forms.DateTimePicker]) {
                $control.BackColor = $newPalette.Input
                $control.ForeColor = $newPalette.Text
            }
            elseif ($control -is [Windows.Forms.Button]) {
                $text = ([string]$control.Text).Trim().ToUpperInvariant()
                $wasDanger = $false
                $wasPrimary = $false
                if ($null -ne $oldPalette) {
                    try { $wasDanger = ($oldBackArgb -eq [int]$oldPalette.DangerBack.ToArgb()) } catch {}
                    try { $wasPrimary = ($oldBackArgb -eq [int]$oldPalette.AccentStrong.ToArgb() -or $oldBackArgb -eq [int]$oldPalette.Accent.ToArgb()) } catch {}
                }
                if ($text -match 'EXCLUIR|ESTORNAR') { $wasDanger = $true }
                if ($text -match 'NOVA NF|EXCEL OFICIAL|REGISTRAR SAÍDA') { $wasPrimary = $true }

                if ($wasDanger) { Set-NFButtonStyle $control "Danger" }
                elseif ($wasPrimary) { Set-NFButtonStyle $control "Primary" }
                else { Set-NFButtonStyle $control "Secondary" }
            }
            elseif ($control -is [Windows.Forms.GroupBox]) {
                $control.ForeColor = $newPalette.Text
                if ($null -eq $mappedBack) { $control.BackColor = $newPalette.Background }
            }
            elseif ($control -is [Windows.Forms.TabPage]) {
                $control.BackColor = $newPalette.Background
                $control.ForeColor = $newPalette.Text
            }
            elseif ($control -is [Windows.Forms.Label]) {
                if ($null -eq $mappedFore) { $control.ForeColor = $newPalette.Text }
            }
            elseif (($control -is [Windows.Forms.Panel]) -or
                    ($control -is [Windows.Forms.TableLayoutPanel]) -or
                    ($control -is [Windows.Forms.FlowLayoutPanel])) {
                if ($null -eq $mappedBack) { $control.BackColor = $newPalette.Background }
            }
        }
        catch {
            # Um controle visual isolado não deve impedir o restante da árvore de
            # receber a aparência selecionada.
        }
    }

    # Elementos estruturais e textos principais recebem cores explícitas.
    try { $form.BackColor = $newPalette.Background; $form.ForeColor = $newPalette.Text } catch {}
    foreach ($panel in @($root,$header,$heading,$cards)) {
        try { if ($null -ne $panel) { $panel.BackColor = $newPalette.Background } } catch {}
    }
    foreach ($tab in @($computerTab,$keyboardTab,$movementTab,$historyTab,$securityTab,$summaryTab)) {
        try { if ($null -ne $tab) { $tab.BackColor = $newPalette.Background; $tab.ForeColor = $newPalette.Text } } catch {}
    }
    try { $title.ForeColor = $newPalette.Text } catch {}
    try { $subtitle.ForeColor = $newPalette.Muted } catch {}
    try { $footerStatus.ForeColor = $newPalette.Muted } catch {}

    # Reaplica os papéis dos botões principais, independente da cor que tinham
    # antes da troca.
    try { Set-NFButtonStyle $importButton "Action" } catch {}
    try { Set-NFButtonStyle $exportButton "Primary" } catch {}
    try { Set-NFButtonStyle $newButton "Action" } catch {}
    try { Set-NFButtonStyle $editButton "Secondary" } catch {}
    try { Set-NFButtonStyle $outputButton "Secondary" } catch {}
    try { Set-NFButtonStyle $clearFiltersButton "Secondary" } catch {}
    try { Set-NFButtonStyle $exportListButton "Secondary" } catch {}
    try { Set-NFButtonStyle $deleteButton "Danger" } catch {}
    try { Set-NFButtonStyle $movementReverseButton "Danger" } catch {}

    # CURA 2 — reforço explícito dos elementos mais visíveis do NF.
    $form.BackColor = $newPalette.Background
    $form.ForeColor = $newPalette.Text
    $root.BackColor = $newPalette.Background
    $header.BackColor = $newPalette.Background
    $heading.BackColor = $newPalette.Background
    $cards.BackColor = $newPalette.Background
    $mainTabs.BackColor = $newPalette.Background
    $mainTabs.ForeColor = $newPalette.Text

    foreach ($tab in @($computerTab,$keyboardTab,$movementTab,$historyTab,$securityTab,$summaryTab)) {
        if ($null -ne $tab -and -not $tab.IsDisposed) {
            $tab.BackColor = $newPalette.Background
            $tab.ForeColor = $newPalette.Text
        }
    }

    foreach ($grid in @($computerGrid,$keyboardGrid,$movementGrid,$historyGrid,$backupGrid,$productSummaryGrid,$codeSummaryGrid)) {
        if ($null -eq $grid -or $grid.IsDisposed) { continue }
        $grid.BackgroundColor = $newPalette.Surface
        $grid.GridColor = $newPalette.Border
        $grid.EnableHeadersVisualStyles = $false
        $grid.ColumnHeadersDefaultCellStyle.BackColor = $newPalette.Card
        $grid.ColumnHeadersDefaultCellStyle.ForeColor = $newPalette.Text
        $grid.DefaultCellStyle.BackColor = $newPalette.Surface
        $grid.DefaultCellStyle.ForeColor = $newPalette.Text
        $grid.DefaultCellStyle.SelectionBackColor = $newPalette.AccentStrong
        $grid.DefaultCellStyle.SelectionForeColor = $newPalette.AccentText
        $grid.Invalidate()
    }

    try { $title.ForeColor = $newPalette.Text } catch {}
    try { $subtitle.ForeColor = $newPalette.Muted } catch {}
    try { Set-NFButtonStyle $importButton "Action" } catch {}
    try { Set-NFButtonStyle $exportButton "Primary" } catch {}
    try { Set-NFButtonStyle $newButton "Action" } catch {}
    try { Set-NFButtonStyle $editButton "Secondary" } catch {}
    try { Set-NFButtonStyle $outputButton "Secondary" } catch {}
    try { Set-NFButtonStyle $clearFiltersButton "Secondary" } catch {}
    try { Set-NFButtonStyle $exportListButton "Secondary" } catch {}
    try { Set-NFButtonStyle $deleteButton "Danger" } catch {}
    try { Set-NFButtonStyle $movementReverseButton "Danger" } catch {}

    # Não basta a raiz mudar: confirma também aba, grade e ação principal.
    if ([int]$computerTab.BackColor.ToArgb() -ne [int]$newPalette.Background.ToArgb()) {
        throw "A aba principal do Controle de NF não recebeu o tema $Theme."
    }
    if ([int]$computerGrid.DefaultCellStyle.BackColor.ToArgb() -ne [int]$newPalette.Surface.ToArgb()) {
        throw "A grade do Controle de NF não recebeu o tema $Theme."
    }
    if ([int]$newButton.BackColor.ToArgb() -ne [int]([Drawing.Color]::FromArgb(244, 142, 40).ToArgb())) {
        throw "Os botões do Controle de NF não receberam o tema $Theme."
    }

    try {
        $form.PerformLayout()
        $form.Invalidate($true)
    }
    catch { throw "Falha ao redesenhar o Controle de NF: $($_.Exception.Message)" }

    if ([int]$form.BackColor.ToArgb() -ne [int]$newPalette.Background.ToArgb()) {
        throw "A raiz do Controle de NF não recebeu o tema $Theme."
    }
    if ([int]$form.ForeColor.ToArgb() -ne [int]$newPalette.Text.ToArgb()) {
        throw "O texto raiz do Controle de NF não recebeu o tema $Theme."
    }
    if ($null -ne $script:HostedThemeContext -and [string]$script:HostedThemeContext.Theme -ne $Theme) {
        throw "O Controle de NF perdeu a autoridade de aparência da Central."
    }
    return $true
}


# GERAL 2 / ETAPA 4 — motor responsivo do Controle de NF.
# Importante: o TabControl nativo permanece intocado. A adaptação acontece na
# casca, na navegação visual e no conteúdo de cada página.
$script:NFResponsiveBusy = $false
$script:NFResponsiveProfile = ""
$script:NFTopSummaryCards = @()

function Get-NFLogicalViewport {
    $dpi = 96
    try { if ($form.DeviceDpi -gt 0) { $dpi = [int]$form.DeviceDpi } } catch {}
    $w = [Math]::Max(1, [int]$form.ClientSize.Width)
    $h = [Math]::Max(1, [int]$form.ClientSize.Height)
    $logicalW = if ($script:IsInProcessHosted) { $w } else { [int][Math]::Round($w * 96.0 / $dpi) }
    $logicalH = if ($script:IsInProcessHosted) { $h } else { [int][Math]::Round($h * 96.0 / $dpi) }
    return [pscustomobject]@{ Width=$w; Height=$h; LogicalWidth=$logicalW; LogicalHeight=$logicalH; Dpi=$dpi }
}

function Set-NFTopSummaryLayout {
    param([int]$Columns)
    if ($script:NFTopSummaryCards.Count -ne 4) {
        $cache = @()
        for ($i = 0; $i -lt 4; $i++) {
            try {
                $control = $cards.GetControlFromPosition($i, 0)
                if ($null -ne $control) { $cache += $control }
            } catch {}
        }
        if ($cache.Count -eq 4) { $script:NFTopSummaryCards = $cache }
    }
    if ($script:NFTopSummaryCards.Count -ne 4) { return }

    try {
        $cards.SuspendLayout()
        $cards.ColumnStyles.Clear()
        $cards.RowStyles.Clear()
        $cards.ColumnCount = $Columns
        $rows = [int][Math]::Ceiling(4.0 / $Columns)
        $cards.RowCount = $rows
        for ($i = 0; $i -lt $Columns; $i++) {
            [void]$cards.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent, (100.0 / $Columns))))
        }
        for ($i = 0; $i -lt $rows; $i++) {
            [void]$cards.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Percent, (100.0 / $rows))))
        }
        for ($i = 0; $i -lt 4; $i++) {
            $col = $i % $Columns
            $row = [int][Math]::Floor($i / $Columns)
            $cards.SetCellPosition($script:NFTopSummaryCards[$i], [Windows.Forms.TableLayoutPanelCellPosition]::new($col, $row))
        }
    }
    finally { try { $cards.ResumeLayout($true) } catch {} }
}

function Set-NFVisualNavigationLayout {
    param([bool]$TwoRows, [string]$Profile)
    $buttons = @(
        $script:NFComputerNavButton,
        $script:NFKeyboardNavButton,
        $script:NFMovementNavButton,
        $script:NFHistoryNavButton,
        $script:NFSecurityNavButton,
        $script:NFSummaryNavButton
    )
    try {
        $nfSectionNav.SuspendLayout()
        $nfSectionNav.ColumnStyles.Clear()
        $nfSectionNav.RowStyles.Clear()
        if ($TwoRows) {
            $nfSectionNav.ColumnCount = 3
            $nfSectionNav.RowCount = 2
            for ($i=0; $i -lt 3; $i++) { [void]$nfSectionNav.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent, 33.3333))) }
            for ($i=0; $i -lt 2; $i++) { [void]$nfSectionNav.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Percent, 50))) }
            for ($i=0; $i -lt 6; $i++) {
                $nfSectionNav.SetCellPosition($buttons[$i], [Windows.Forms.TableLayoutPanelCellPosition]::new(($i % 3), [int][Math]::Floor($i / 3)))
            }
            $nfTabsShell.RowStyles[0].Height = 76
        }
        else {
            $nfSectionNav.ColumnCount = 6
            $nfSectionNav.RowCount = 1
            for ($i=0; $i -lt 6; $i++) { [void]$nfSectionNav.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent, 16.6667))) }
            [void]$nfSectionNav.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Percent, 100)))
            for ($i=0; $i -lt 6; $i++) {
                $nfSectionNav.SetCellPosition($buttons[$i], [Windows.Forms.TableLayoutPanelCellPosition]::new($i, 0))
            }
            $nfTabsShell.RowStyles[0].Height = if ($Profile -eq "Comfortable") { 46 } else { 43 }
        }
        $nfSectionNav.Padding = if ($Profile -eq "Tight") { [Windows.Forms.Padding]::new(3,2,3,2) } else { [Windows.Forms.Padding]::new(5,2,5,2) }
        foreach ($button in $buttons) {
            if ($null -eq $button) { continue }
            $button.Margin = if ($Profile -eq "Tight") { [Windows.Forms.Padding]::new(2) } else { [Windows.Forms.Padding]::new(3,2,3,2) }
            $button.Font = [Drawing.Font]::new("Segoe UI Semibold", $(if ($Profile -eq "Tight") { 7.5 } elseif ($Profile -eq "Compact") { 8.0 } else { 8.4 }))
        }
    }
    finally { try { $nfSectionNav.ResumeLayout($true) } catch {} }
}

function Set-NFProductPageResponsive {
    param([Windows.Forms.TabPage]$Tab, [string]$Profile)
    if ($null -eq $Tab) { return }
    $layout = @($Tab.Controls | Where-Object { $_ -is [Windows.Forms.TableLayoutPanel] } | Select-Object -First 1)
    if ($layout.Count -eq 0) { return }
    $page = $layout[0]
    try {
        $page.Padding = [Windows.Forms.Padding]::new($(if ($Profile -eq "Tight") { 5 } elseif ($Profile -eq "Compact") { 7 } else { 10 }))
        if ($page.RowStyles.Count -gt 0) { $page.RowStyles[0].Height = if ($Profile -eq "Tight") { 44 } elseif ($Profile -eq "Compact") { 47 } else { 50 } }
        $filterPanel = $page.GetControlFromPosition(0,0)
        if ($filterPanel -is [Windows.Forms.TableLayoutPanel] -and $filterPanel.ColumnStyles.Count -ge 7) {
            $widths = if ($Profile -eq "Tight") { @(52,0,44,106,36,82,70) } elseif ($Profile -eq "Compact") { @(60,0,50,116,40,90,80) } else { @(72,0,58,128,48,100,96) }
            for ($i=0; $i -lt 7; $i++) {
                if ($i -eq 1) {
                    $filterPanel.ColumnStyles[$i].SizeType = [Windows.Forms.SizeType]::Percent
                    $filterPanel.ColumnStyles[$i].Width = 100
                }
                else {
                    $filterPanel.ColumnStyles[$i].SizeType = [Windows.Forms.SizeType]::Absolute
                    $filterPanel.ColumnStyles[$i].Width = $widths[$i]
                }
            }
        }
    } catch {}
}

function Set-NFActivityResponsive {
    param([bool]$TwoRows)
    $a1 = try { $movementTodayValue.Parent.Parent } catch { $null }
    $a2 = try { $piecesTodayValue.Parent.Parent } catch { $null }
    $a3 = try { $piecesSevenValue.Parent.Parent } catch { $null }
    if ($null -eq $a1 -or $null -eq $a2 -or $null -eq $a3) { return }
    $items = @($a1,$a2,$a3,$lastPanel,$summaryActionPanel)
    try {
        $activityLayout.SuspendLayout()
        $activityLayout.ColumnStyles.Clear()
        $activityLayout.RowStyles.Clear()
        if ($TwoRows) {
            $activityLayout.ColumnCount = 3
            $activityLayout.RowCount = 2
            for ($i=0; $i -lt 3; $i++) { [void]$activityLayout.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent, 33.3333))) }
            for ($i=0; $i -lt 2; $i++) { [void]$activityLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Percent, 50))) }
            $activityLayout.SetCellPosition($a1, [Windows.Forms.TableLayoutPanelCellPosition]::new(0,0))
            $activityLayout.SetCellPosition($a2, [Windows.Forms.TableLayoutPanelCellPosition]::new(1,0))
            $activityLayout.SetCellPosition($a3, [Windows.Forms.TableLayoutPanelCellPosition]::new(2,0))
            $activityLayout.SetCellPosition($lastPanel, [Windows.Forms.TableLayoutPanelCellPosition]::new(0,1))
            $activityLayout.SetColumnSpan($lastPanel, 2)
            $activityLayout.SetCellPosition($summaryActionPanel, [Windows.Forms.TableLayoutPanelCellPosition]::new(2,1))
        }
        else {
            $activityLayout.ColumnCount = 5
            $activityLayout.RowCount = 1
            foreach ($percent in @(17,17,17,32,17)) { [void]$activityLayout.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent, $percent))) }
            [void]$activityLayout.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Percent, 100)))
            $activityLayout.SetColumnSpan($lastPanel, 1)
            for ($i=0; $i -lt 5; $i++) { $activityLayout.SetCellPosition($items[$i], [Windows.Forms.TableLayoutPanelCellPosition]::new($i,0)) }
        }
    }
    finally { try { $activityLayout.ResumeLayout($true) } catch {} }
}

function Update-NFResponsiveLayout {
    if (Test-NFHostedLayoutRestoreGate) { return }
    if ($script:NFResponsiveBusy -or $null -eq $form) { return }
    $script:NFResponsiveBusy = $true
    try {
        $m = Get-NFLogicalViewport
        $profile = if ($m.LogicalWidth -lt 930 -or $m.LogicalHeight -lt 620) { "Tight" } elseif ($m.LogicalWidth -lt 1220 -or $m.LogicalHeight -lt 760) { "Compact" } else { "Comfortable" }
        $script:NFResponsiveProfile = $profile

        $pad = if ($profile -eq "Tight") { 5 } elseif ($profile -eq "Compact") { 7 } else { $(if ($script:IsInProcessHosted) { 8 } else { 14 }) }
        $root.Padding = [Windows.Forms.Padding]::new($pad)

        # Cabeçalho usa menos área quando a janela diminui, mas mantém as duas ações visíveis.
        $root.RowStyles[0].Height = if ($profile -eq "Tight") { 60 } elseif ($profile -eq "Compact") { 66 } else { $(if ($script:IsInProcessHosted) { 68 } else { 92 }) }
        $actionW = if ($profile -eq "Tight") { 138 } elseif ($profile -eq "Compact") { 158 } else { $(if ($script:IsInProcessHosted) { 176 } else { 190 }) }
        $header.ColumnStyles[1].Width = $actionW
        $header.ColumnStyles[2].Width = $actionW
        $heading.RowStyles[0].Height = if ($profile -eq "Tight") { 34 } elseif ($profile -eq "Compact") { 38 } else { $(if ($script:IsInProcessHosted) { 39 } else { 54 }) }
        $title.Font = [Drawing.Font]::new("Segoe UI Semibold", $(if ($profile -eq "Tight") { 13.0 } elseif ($profile -eq "Compact") { 14.5 } else { $(if ($script:IsInProcessHosted) { 15.5 } else { 20 }) }))
        $subtitle.Font = [Drawing.Font]::new("Segoe UI", $(if ($profile -eq "Tight") { 7.4 } elseif ($profile -eq "Compact") { 7.9 } else { 8.2 }))
        $buttonTop = if ($profile -eq "Tight") { 7 } else { 9 }
        $buttonBottom = if ($profile -eq "Tight") { 6 } else { 8 }
        $importButton.Margin = [Windows.Forms.Padding]::new(5, $buttonTop, 5, $buttonBottom)
        $exportButton.Margin = [Windows.Forms.Padding]::new(5, $buttonTop, 5, $buttonBottom)
        $importButton.Padding = [Windows.Forms.Padding]::new(4,0,4,0)
        $exportButton.Padding = [Windows.Forms.Padding]::new(4,0,4,0)
        $headerButtonFont = if ($profile -eq "Tight") { 7.8 } elseif ($profile -eq "Compact") { 8.0 } else { 8.3 }
        $importButton.Font = [Drawing.Font]::new("Segoe UI Semibold", $headerButtonFont)
        $exportButton.Font = [Drawing.Font]::new("Segoe UI Semibold", $headerButtonFont)
        $importButton.AutoEllipsis = $false
        $exportButton.AutoEllipsis = $false

        # Resumo superior vira 2x2 somente quando a largura real pede isso.
        $summaryColumns = if ($m.LogicalWidth -lt 980) { 2 } else { 4 }
        Set-NFTopSummaryLayout -Columns $summaryColumns
        $root.RowStyles[1].Height = if ($summaryColumns -eq 2) { $(if ($profile -eq "Tight") { 154 } else { 166 }) } else { $(if ($profile -eq "Comfortable") { 104 } else { 96 }) }

        # Navegação visual pode quebrar em 2 linhas; o TabControl interno continua nativo.
        Set-NFVisualNavigationLayout -TwoRows:($m.LogicalWidth -lt 780) -Profile $profile
        Sync-NFTabViewport

        # Produtos: filtros cedem largura primeiro; a busca e a grade ficam com o restante.
        Set-NFProductPageResponsive -Tab $computerTab -Profile $profile
        Set-NFProductPageResponsive -Tab $keyboardTab -Profile $profile

        # Movimentações e Histórico: barras superiores acompanham o espaço real.
        $technicalPad = if ($profile -eq "Tight") { 5 } elseif ($profile -eq "Compact") { 7 } else { 10 }
        $movementLayout.Padding = [Windows.Forms.Padding]::new($technicalPad)
        $historyLayout.Padding = [Windows.Forms.Padding]::new($technicalPad)
        $securityLayout.Padding = [Windows.Forms.Padding]::new($technicalPad)
        $movementLayout.RowStyles[0].Height = if ($profile -eq "Tight") { 44 } elseif ($profile -eq "Compact") { 48 } else { 52 }
        $historyLayout.RowStyles[0].Height = if ($profile -eq "Tight") { 44 } elseif ($profile -eq "Compact") { 48 } else { 52 }
        $securityLayout.RowStyles[0].Height = if ($profile -eq "Tight") { 54 } elseif ($profile -eq "Compact") { 62 } else { 72 }
        $movementLayout.RowStyles[2].Height = if ($profile -eq "Tight") { 38 } else { 42 }
        $historyLayout.RowStyles[2].Height = if ($profile -eq "Tight") { 38 } else { 42 }
        $securityLayout.RowStyles[2].Height = if ($profile -eq "Tight") { 42 } else { 46 }

        $mw = if ($profile -eq "Tight") { @(54,0,48,142,46,122) } elseif ($profile -eq "Compact") { @(62,0,54,164,50,142) } else { @(74,0,62,190,58,165) }
        for ($i=0; $i -lt 6; $i++) {
            if ($i -eq 1) { $movementFilters.ColumnStyles[$i].SizeType=[Windows.Forms.SizeType]::Percent; $movementFilters.ColumnStyles[$i].Width=100 }
            else { $movementFilters.ColumnStyles[$i].SizeType=[Windows.Forms.SizeType]::Absolute; $movementFilters.ColumnStyles[$i].Width=$mw[$i] }
        }
        $hw = if ($profile -eq "Tight") { @(54,0,42,108,48,122,76) } elseif ($profile -eq "Compact") { @(62,0,46,126,54,140,94) } else { @(74,0,52,142,62,155,120) }
        for ($i=0; $i -lt 7; $i++) {
            if ($i -eq 1) { $historyFilters.ColumnStyles[$i].SizeType=[Windows.Forms.SizeType]::Percent; $historyFilters.ColumnStyles[$i].Width=100 }
            else { $historyFilters.ColumnStyles[$i].SizeType=[Windows.Forms.SizeType]::Absolute; $historyFilters.ColumnStyles[$i].Width=$hw[$i] }
        }

        # Resumo interno: em altura/largura menor, a atividade vira 3+2 em vez de cortar textos.
        $summaryLayout.Padding = [Windows.Forms.Padding]::new($(if ($profile -eq "Tight") { 5 } elseif ($profile -eq "Compact") { 7 } else { 8 }))
        $summaryLayout.AutoScroll = $true
        $summaryLayout.RowStyles[0].SizeType = [Windows.Forms.SizeType]::Absolute
        $summaryLayout.RowStyles[1].SizeType = [Windows.Forms.SizeType]::Absolute
        $summaryLayout.RowStyles[2].SizeType = [Windows.Forms.SizeType]::Absolute

        $summaryTopMin = if ($profile -eq "Tight") { 142 } elseif ($profile -eq "Compact") { 150 } else { 158 }
        $summaryCodeMin = if ($profile -eq "Tight") { 188 } elseif ($profile -eq "Compact") { 198 } else { 206 }
        $summaryActivityMin = if ($profile -eq "Tight") { 126 } elseif ($profile -eq "Compact") { 132 } else { 138 }
        $summaryBaseHeight = $summaryTopMin + $summaryCodeMin + $summaryActivityMin
        $summaryAvailableHeight = [Math]::Max(0, [int]$summaryLayout.ClientSize.Height - [int]$summaryLayout.Padding.Vertical)
        $summaryExtra = [Math]::Max(0, $summaryAvailableHeight - $summaryBaseHeight)

        $summaryLayout.RowStyles[0].Height = $summaryTopMin
        $summaryLayout.RowStyles[1].Height = $summaryCodeMin
        $summaryLayout.RowStyles[2].Height = $summaryActivityMin + $summaryExtra
        $summaryLayout.AutoScrollMinSize = [Drawing.Size]::new(0, $summaryBaseHeight + [int]$summaryLayout.Padding.Vertical)

        $productGroup.Padding = if ($profile -eq "Tight") {
            [Windows.Forms.Padding]::new(7,17,7,5)
        } elseif ($profile -eq "Compact") {
            [Windows.Forms.Padding]::new(8,19,8,6)
        } else {
            [Windows.Forms.Padding]::new(9,21,9,7)
        }
        $codeGroup.Padding=if($profile -eq "Tight"){[Windows.Forms.Padding]::new(7,17,7,5)}elseif($profile -eq "Compact"){[Windows.Forms.Padding]::new(8,18,8,6)}else{[Windows.Forms.Padding]::new(9,19,9,7)}

        # Conferência automática: padding e tipografia acompanham a densidade.
        # Isso evita que DPI alto transforme as seis linhas em uma área maior que
        # o GroupBox mesmo quando a janela está maximizada.
        $conferenceGroup.Padding = if ($profile -eq "Tight") {
            [Windows.Forms.Padding]::new(8, 17, 8, 5)
        } elseif ($profile -eq "Compact") {
            [Windows.Forms.Padding]::new(10, 19, 10, 6)
        } else {
            [Windows.Forms.Padding]::new(12, 21, 12, 8)
        }
        $conferenceLabelFont = if ($profile -eq "Tight") { 7.7 } elseif ($profile -eq "Compact") { 8.3 } else { 9.0 }
        $conferenceValueFont = if ($profile -eq "Tight") { 8.4 } elseif ($profile -eq "Compact") { 9.1 } else { 10.0 }
        for ($conferenceRow = 0; $conferenceRow -lt 6; $conferenceRow++) {
            $conferenceLabel = $conference.GetControlFromPosition(0, $conferenceRow)
            $conferenceValue = $conference.GetControlFromPosition(1, $conferenceRow)
            if ($null -ne $conferenceLabel) {
                $conferenceLabel.Margin = [Windows.Forms.Padding]::new(0)
                $conferenceLabel.AutoEllipsis = $false
                $conferenceLabel.Font = [Drawing.Font]::new("Segoe UI", $conferenceLabelFont)
            }
            if ($null -ne $conferenceValue) {
                $conferenceValue.Margin = [Windows.Forms.Padding]::new(0)
                $conferenceValue.AutoEllipsis = $false
                $conferenceValue.Font = [Drawing.Font]::new("Segoe UI Semibold", $conferenceValueFont)
            }
        }

        Set-NFActivityResponsive -TwoRows:($profile -eq "Tight")
        $summaryActionPanel.Padding = if ($profile -eq "Tight") { [Windows.Forms.Padding]::new(3,6,3,3) } else { [Windows.Forms.Padding]::new(4,10,4,4) }
        $lastLayout.Padding = if ($profile -eq "Tight") { [Windows.Forms.Padding]::new(8,4,8,4) } else { [Windows.Forms.Padding]::new(12,8,12,8) }

        # Densidade das grades acompanha o perfil em TODAS as páginas.
        $headerH = if ($profile -eq "Tight") { 23 } elseif ($profile -eq "Compact") { 25 } else { 28 }
        $rowH = if ($profile -eq "Tight") { 20 } elseif ($profile -eq "Compact") { 22 } else { 25 }
        $gridFont = if ($profile -eq "Tight") { 7.5 } elseif ($profile -eq "Compact") { 8.1 } else { 8.8 }
        foreach ($grid in @($computerGrid,$keyboardGrid,$movementGrid,$historyGrid,$backupGrid)) {
            if ($null -eq $grid) { continue }
            try {
                $grid.ColumnHeadersHeight = $headerH
                $grid.RowTemplate.Height = $rowH
                $grid.DefaultCellStyle.Font = [Drawing.Font]::new("Segoe UI", $gridFont)
                $grid.ColumnHeadersDefaultCellStyle.Font = [Drawing.Font]::new("Segoe UI Semibold", $gridFont)
            } catch {}
        }
        foreach ($grid in @($productSummaryGrid,$codeSummaryGrid)) {
            if ($null -eq $grid) { continue }
            try {
                $grid.ColumnHeadersHeight = if ($profile -eq "Tight") { 22 } elseif ($profile -eq "Compact") { 23 } else { 25 }
                $grid.RowTemplate.Height = if ($profile -eq "Tight") { 20 } elseif ($profile -eq "Compact") { 21 } else { 22 }
            } catch {}
        }
        try {
            $productSummaryGrid.ScrollBars = [Windows.Forms.ScrollBars]::None
            $productSummaryGrid.AutoSizeRowsMode = [Windows.Forms.DataGridViewAutoSizeRowsMode]::None
            foreach ($row in @($productSummaryGrid.Rows)) {
                if (-not $row.IsNewRow) { $row.Height = if ($profile -eq "Tight") { 20 } elseif ($profile -eq "Compact") { 21 } else { 22 } }
            }
        } catch {}

        # Barra inferior: quebra somente quando realmente não cabe.
        $wrapActions = ($m.LogicalWidth -lt 760)
        $actionPanel.WrapContents = $wrapActions
        $root.RowStyles[3].Height = if ($wrapActions) { 78 } elseif ($profile -eq "Tight") { 48 } else { $(if ($script:IsInProcessHosted) { 52 } else { 58 }) }
        $footerHost.Padding = if ($profile -eq "Tight") { [Windows.Forms.Padding]::new(5,4,5,4) } else { [Windows.Forms.Padding]::new(8,6,8,6) }

        $securityInfo.Font = [Drawing.Font]::new("Segoe UI", $(if ($profile -eq "Tight") { 7.5 } elseif ($profile -eq "Compact") { 8.2 } else { 9.0 }))
        $backupButtons.WrapContents = ($m.LogicalWidth -lt 760)

        $form.PerformLayout()
        Sync-NFTabViewport
    }
    catch {}
    finally { $script:NFResponsiveBusy = $false }
}

function Apply-NFEntradaThemeControl {
    param([Windows.Forms.Control]$Control)
    if ($null -eq $Control) { return }
    try { if ($Control.IsDisposed -or $Control.Disposing) { return } } catch { return }

    $palette = $script:CurrentPalette
    if ($Control -is [Windows.Forms.DataGridView]) {
        $Control.BackgroundColor = $palette.Surface
        $Control.GridColor = $palette.Border
        $Control.EnableHeadersVisualStyles = $false
        $Control.ColumnHeadersDefaultCellStyle.BackColor = $palette.Card
        $Control.ColumnHeadersDefaultCellStyle.ForeColor = $palette.Text
        $Control.DefaultCellStyle.BackColor = $palette.Surface
        $Control.DefaultCellStyle.ForeColor = $palette.Text
        $Control.DefaultCellStyle.SelectionBackColor = $palette.AccentStrong
        $Control.DefaultCellStyle.SelectionForeColor = $palette.AccentText
        $Control.AlternatingRowsDefaultCellStyle.BackColor = $palette.Surface
        $Control.AlternatingRowsDefaultCellStyle.ForeColor = $palette.Text
    }
    elseif ($Control -is [Windows.Forms.TextBox] -or
            $Control -is [Windows.Forms.ComboBox] -or
            $Control -is [Windows.Forms.NumericUpDown] -or
            $Control -is [Windows.Forms.DateTimePicker]) {
        $Control.BackColor = $palette.Input
        $Control.ForeColor = $palette.Text
    }
    elseif ($Control -is [Windows.Forms.Button]) {
        $role = [string]$Control.Tag
        if ($role -eq "Theme.Button.Primary") { Set-NFButtonStyle $Control "Primary" }
        elseif ($role -eq "Theme.Button.Action") { Set-NFButtonStyle $Control "Action" }
        elseif ($role -eq "Theme.Button.Danger") { Set-NFButtonStyle $Control "Danger" }
        else { Set-NFButtonStyle $Control "Secondary" }
    }
    elseif ($Control -is [Windows.Forms.TabPage]) {
        $Control.BackColor = $palette.Background
        $Control.ForeColor = $palette.Text
    }
    elseif ($Control -is [Windows.Forms.GroupBox]) {
        $Control.BackColor = $palette.Background
        $Control.ForeColor = $palette.Text
    }
    elseif ($Control -is [Windows.Forms.Panel] -or
            $Control -is [Windows.Forms.TableLayoutPanel] -or
            $Control -is [Windows.Forms.FlowLayoutPanel]) {
        $role = [string]$Control.Tag
        if ($role -eq "Theme.Card") { $Control.BackColor = $palette.Card }
        elseif ($role -eq "Theme.Surface") { $Control.BackColor = $palette.Surface }
        elseif ($null -ne $Control.Parent) { $Control.BackColor = $Control.Parent.BackColor }
        else { $Control.BackColor = $palette.Background }
        $Control.ForeColor = $palette.Text
    }
    elseif ($Control -is [Windows.Forms.Label]) {
        $role = [string]$Control.Tag
        if ($role -eq "Theme.Muted") { $Control.ForeColor = $palette.Muted }
        elseif ($role -eq "Theme.Accent") { $Control.ForeColor = $palette.Accent }
        else { $Control.ForeColor = $palette.Text }
    }
    else {
        try { $Control.ForeColor = $palette.Text } catch {}
    }

    foreach ($child in @($Control.Controls)) { Apply-NFEntradaThemeControl $child }
}

function Set-NFEntradaStatusRowTheme {
    param(
        [Windows.Forms.DataGridView]$Grid,
        [string]$StatusColumn
    )
    if ($null -eq $Grid -or -not $Grid.Columns.Contains($StatusColumn)) { return }
    foreach ($row in @($Grid.Rows)) {
        if ($row.IsNewRow) { continue }
        $status = [string]$row.Cells[$StatusColumn].Value
        if ($StatusColumn -eq "MovementStatus") {
            if ($status -eq "Estornada") {
                $row.DefaultCellStyle.BackColor = $script:CurrentPalette.DangerBack
                $row.DefaultCellStyle.ForeColor = $script:CurrentPalette.Danger
            }
            else {
                $row.DefaultCellStyle.BackColor = $script:CurrentPalette.Surface
                $row.DefaultCellStyle.ForeColor = $script:CurrentPalette.Text
            }
        }
        else {
            switch ($status) {
                "Revisar" { $row.DefaultCellStyle.BackColor = $script:CurrentPalette.DangerBack; $row.DefaultCellStyle.ForeColor = $script:CurrentPalette.Danger }
                "Encerrada" { $row.DefaultCellStyle.BackColor = $script:CurrentPalette.SuccessBack; $row.DefaultCellStyle.ForeColor = $script:CurrentPalette.Success }
                default { $row.DefaultCellStyle.BackColor = $script:CurrentPalette.WarningBack; $row.DefaultCellStyle.ForeColor = $script:CurrentPalette.Warning }
            }
        }
    }
}

function Set-HostedNFEntradaTheme {
    param([string]$Theme)
    if ([string]::IsNullOrWhiteSpace($Theme)) { $Theme = "Escuro profissional" }
    if ($script:IsInProcessHosted) {
        if ($null -eq $script:HostedThemeContext) { $script:HostedCentralTheme = $Theme }
        $Theme = Get-NFEntradaHostedCentralTheme
    }

    $palette = Get-NFEntradaPalette $Theme
    if ($null -eq $palette -or $null -eq $form -or $form.IsDisposed) { return $false }
    $script:CurrentPalette = $palette

    # A árvore é tematizada pelo papel semântico do controle, nunca pela cor
    # anterior. Isso é essencial ao sair de Claro/Alto contraste, cujas cores
    # coincidentes tornavam impossível inferir se um branco/preto era card,
    # input, superfície ou aviso.
    $form.BackColor = $palette.Background
    $form.ForeColor = $palette.Text
    Apply-NFEntradaThemeControl $form

    foreach ($control in @($root,$header,$heading,$cards,$mainTabs,$summaryLayout,$movementLayout,$movementFilters,$movementFooter,$historyLayout,$historyFilters,$historyButtons,$securityLayout,$securityActions)) {
        if ($null -ne $control) { $control.BackColor = $palette.Background; $control.ForeColor = $palette.Text }
    }
    foreach ($control in @($footerHost,$actionPanel)) {
        if ($null -ne $control) { $control.Tag = "Theme.Surface"; $control.BackColor = $palette.Surface; $control.ForeColor = $palette.Text }
    }
    foreach ($control in @($lastPanel,$summaryActionPanel)) {
        if ($null -ne $control) { $control.Tag = "Theme.Card"; $control.BackColor = $palette.Card; $control.ForeColor = $palette.Text }
    }
    foreach ($tab in @($computerTab,$keyboardTab,$movementTab,$historyTab,$securityTab,$summaryTab)) {
        if ($null -ne $tab) { $tab.BackColor = $palette.Background; $tab.ForeColor = $palette.Text }
    }
    foreach ($group in @($productGroup,$conferenceGroup,$codeGroup,$activityGroup)) {
        if ($null -ne $group) { $group.BackColor = $palette.Background; $group.ForeColor = $palette.Text }
    }

    foreach ($label in @($subtitle,$lastTitle,$movementSearchLabel,$movementProductLabel,$movementPeriodLabel,$movementCountLabel,$historySearchLabel,$historyTypeLabel,$historyPeriodLabel,$historyCountLabel,$securityInfo,$backupCountLabel,$footerStatus)) {
        if ($null -ne $label) { $label.Tag = "Theme.Muted"; $label.ForeColor = $palette.Muted }
    }
    $title.ForeColor = $palette.Text
    $lastMovementValue.ForeColor = $palette.Text

    # Reaplica papéis explícitos dos botões, inclusive depois de operações que
    # alteram Enabled/Visible, sem tocar em nenhuma ação operacional.
    foreach ($button in @($editButton,$outputButton,$clearFiltersButton,$exportListButton,$movementExportButton,$movementOpenButton,$historyDetailsButton,$historyExportButton,$integrityButton,$manualBackupButton,$restoreBackupButton,$reviewIssuesButton)) {
        if ($null -ne $button) { Set-NFButtonStyle $button "Secondary" }
    }
    foreach ($button in @($exportButton)) {
        if ($null -ne $button) { Set-NFButtonStyle $button "Primary" }
    }
    foreach ($button in @($importButton,$newButton)) {
        if ($null -ne $button) { Set-NFButtonStyle $button "Action" }
    }
    foreach ($button in @($deleteButton,$movementReverseButton)) {
        if ($null -ne $button) { Set-NFButtonStyle $button "Danger" }
    }

    Set-NFEntradaStatusRowTheme $computerGrid "Status"
    Set-NFEntradaStatusRowTheme $keyboardGrid "Status"
    Set-NFEntradaStatusRowTheme $movementGrid "MovementStatus"
    $form.PerformLayout()
    $form.Invalidate($true)

    if ([int]$form.BackColor.ToArgb() -ne [int]$palette.Background.ToArgb()) { return $false }
    if ([int]$computerGrid.DefaultCellStyle.BackColor.ToArgb() -ne [int]$palette.Surface.ToArgb()) { return $false }
    if ([int]$newButton.BackColor.ToArgb() -ne [int]([Drawing.Color]::FromArgb(244, 142, 40).ToArgb())) { return $false }
    if ($script:IsInProcessHosted -and $null -ne $script:HostedThemeContext -and [string]$script:HostedThemeContext.Theme -ne $Theme) { return $false }
    return $true
}

function Get-HostedNFEntradaThemeAudit {
    if (-not $script:IsInProcessHosted) {
        return [pscustomobject]@{ Valid = $false; AuthorityTheme = ""; InternalTheme = ""; Revision = -1; Checks = @() }
    }
    $authorityTheme = Get-NFEntradaHostedCentralTheme
    $palette = Get-NFEntradaPalette $authorityTheme
    $checks = @(
        [pscustomobject]@{ Name = "fundo geral"; Actual = [int]$form.BackColor.ToArgb(); Expected = [int]$palette.Background.ToArgb() },
        [pscustomobject]@{ Name = "layout raiz"; Actual = [int]$root.BackColor.ToArgb(); Expected = [int]$palette.Background.ToArgb() },
        [pscustomobject]@{ Name = "cabeçalho"; Actual = [int]$header.BackColor.ToArgb(); Expected = [int]$palette.Background.ToArgb() },
        [pscustomobject]@{ Name = "abas nativas estáveis"; Actual = $(if ($mainTabs.DrawMode -eq [Windows.Forms.TabDrawMode]::Normal -and $mainTabs.TabPages.Count -eq 6) { 1 } else { 0 }); Expected = 1 },
        [pscustomobject]@{ Name = "aba computador"; Actual = [int]$computerTab.BackColor.ToArgb(); Expected = [int]$palette.Background.ToArgb() },
        [pscustomobject]@{ Name = "aba teclado"; Actual = [int]$keyboardTab.BackColor.ToArgb(); Expected = [int]$palette.Background.ToArgb() },
        [pscustomobject]@{ Name = "aba movimentações"; Actual = [int]$movementTab.BackColor.ToArgb(); Expected = [int]$palette.Background.ToArgb() },
        [pscustomobject]@{ Name = "aba histórico"; Actual = [int]$historyTab.BackColor.ToArgb(); Expected = [int]$palette.Background.ToArgb() },
        [pscustomobject]@{ Name = "aba segurança"; Actual = [int]$securityTab.BackColor.ToArgb(); Expected = [int]$palette.Background.ToArgb() },
        [pscustomobject]@{ Name = "aba resumo"; Actual = [int]$summaryTab.BackColor.ToArgb(); Expected = [int]$palette.Background.ToArgb() },
        [pscustomobject]@{ Name = "card de produto"; Actual = [int]$productGroup.BackColor.ToArgb(); Expected = [int]$palette.Background.ToArgb() },
        [pscustomobject]@{ Name = "painel de ações"; Actual = [int]$actionPanel.BackColor.ToArgb(); Expected = [int]$palette.Surface.ToArgb() },
        [pscustomobject]@{ Name = "input"; Actual = [int]$computerFilter.BackColor.ToArgb(); Expected = [int]$palette.Input.ToArgb() },
        [pscustomobject]@{ Name = "botão"; Actual = [int]$newButton.BackColor.ToArgb(); Expected = [int]([Drawing.Color]::FromArgb(244, 142, 40).ToArgb()) },
        [pscustomobject]@{ Name = "grid"; Actual = [int]$computerGrid.DefaultCellStyle.BackColor.ToArgb(); Expected = [int]$palette.Surface.ToArgb() },
        [pscustomobject]@{ Name = "rodapé"; Actual = [int]$footerHost.BackColor.ToArgb(); Expected = [int]$palette.Surface.ToArgb() }
    )
    $invalid = @($checks | Where-Object { $_.Actual -ne $_.Expected })
    $revision = if ($null -ne $script:HostedThemeContext -and $script:HostedThemeContext.PSObject.Properties.Name -contains "Revision") { [int]$script:HostedThemeContext.Revision } else { -1 }
    return [pscustomobject]@{
        Valid = ($invalid.Count -eq 0)
        AuthorityTheme = $authorityTheme
        InternalTheme = $authorityTheme
        ExpectedInternalTheme = $authorityTheme
        Revision = $revision
        Checks = $checks
        InvalidChecks = $invalid
    }
}

function Invoke-NFThemeBoundaryMarker { return }

$script:NFLayoutTimer = New-Object Windows.Forms.Timer
$script:NFLayoutTimer.Interval = 70
$script:NFLayoutTimer.Add_Tick({
    $script:NFLayoutTimer.Stop()
    try { Update-NFResponsiveLayout } catch {}
})

function Schedule-NFResponsiveLayout {
    try {
        if (Test-NFHostedLayoutRestoreGate) { return }
        if ($null -eq $script:NFLayoutTimer) { return }
        $script:NFLayoutTimer.Stop()
        $script:NFLayoutTimer.Start()
    } catch {}
}

$form.Add_SizeChanged({ Schedule-NFResponsiveLayout })
try { $form.Add_DpiChanged({ Schedule-NFResponsiveLayout }) } catch {}
try { $form.Add_ResizeEnd({ Update-NFResponsiveLayout }) } catch {}
$form.Add_Disposed({
    try {
        if ($null -ne $script:NFLayoutTimer) {
            $script:NFLayoutTimer.Stop()
            $script:NFLayoutTimer.Dispose()
            $script:NFLayoutTimer = $null
        }
    } catch {}
})
Update-NFResponsiveLayout

if ($script:IsInProcessHosted) {
    $script:HostedControlExport = $form
    $script:HostedFormExport = $null
}
else {
    try { [void]$form.ShowDialog() }
    finally { try { $form.Dispose() } catch {} }
}

# Contratos visuais legados preservados para a regressão automatizada.
# Estes nomes não são exibidos na interface; documentam equivalências após o polimento 2.4.1:
# IMPORTAR PLANILHA -> IMPORTAR EXCEL
# EXPORTAR EXCEL -> EXCEL OFICIAL
# EDITAR SELEÇÃO -> EDITAR
# VER DETALHES -> DETALHES
# CRIAR BACKUP AGORA -> NOVO BACKUP
# RESTAURAR SELECIONADO -> RESTAURAR
# VER PENDÊNCIAS -> PENDÊNCIAS

# CURA6_NF_VISUAL_V02611

# VISUAL_UNIFICADO_MANUTENCAO_NF_V02612

# NF_BUTTON_GEOMETRY_MAINTENANCE_STYLE_V02613

# NF_SECTION_NAV_MAINTENANCE_STYLE_V02614

# CURA8_NF_CONTRASTE_V02615

# POST_CURE_NF_SUMMARY_FIT_V02617

# GERAL2_ETAPA4_NF_RESPONSIVE_V02618

# GERAL2_ETAPA7_NF_PERF_V02619

# POS_GERAL2_NF_CONFERENCIA_FIT_V02620

# POS_GERAL2_NF_SINGLE_ROW_FIT_V02621

# NF_CODE_SUMMARY_FIX_V02622

# NF_RESUMO_CODE_CARDS_V02623

# NF_RESUMO_CODE_CARDS_COMPACT_V02623

# NF_FULL_FIT_V02624

# NF_FULL_FIT_CODE_CARD_HEIGHT_V02624

# NF_FULL_FIT_CODE_CARD_TITLES_V02624

# HOSTED_RESTORE_GATE_STAGE2_V02625

# NF_EDIT_DIALOG_CLOSURE_SCOPE_HOTFIX_V02626
